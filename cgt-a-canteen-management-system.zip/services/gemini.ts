
import { GoogleGenAI, Type } from "@google/genai";

const getAI = () => new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function getMealInsights(query: string) {
  const ai = getAI();
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: query,
      config: {
        tools: [{ googleSearch: {} }],
        systemInstruction: "You are a canteen management assistant. Provide insights on food trends, nutrition, and operational efficiency based on recent data."
      },
    });
    
    const text = response.text || "No response from AI.";
    const sources = response.candidates?.[0]?.groundingMetadata?.groundingChunks?.map(chunk => chunk.web?.uri).filter(Boolean) || [];
    
    return { text, sources };
  } catch (error) {
    console.error("Gemini Error:", error);
    return { text: "Error fetching AI insights.", sources: [] };
  }
}

export async function analyzeSystemHealth(systemState: any) {
  const ai = getAI();
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `System State: ${JSON.stringify(systemState)}`,
      config: {
        systemInstruction: `You are the "CGT System Sentinel". 
        Analyze the provided canteen system state (Employee counts, transaction volumes, config health).
        1. Identify potential operational risks.
        2. Suggest optimizations for meal windows.
        3. Rate the system's "Self-Healing" readiness.
        Provide a concise, technical diagnosis and specific repair suggestions.`
      },
    });
    return response.text || "Diagnostic scan timed out.";
  } catch (error) {
    console.error("Sentinel AI Error:", error);
    return "Neural uplink failed. Proceeding with local diagnostic protocols.";
  }
}

export async function getMaintenanceAdvice(request: string, currentSchema: any) {
  const ai = getAI();
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `User Request: ${request}\n\nCurrent Data Schema: ${JSON.stringify(currentSchema)}`,
      config: {
        systemInstruction: `You are the "Registry Architect AI" for CGT Canteen. 
        Your job is to analyze requests for app changes and provide a technical migration plan.
        1. Identify if new fields are needed.
        2. Ensure existing data is not deleted (non-destructive).
        3. Provide a clear explanation of how you will map old records to the new format.
        Keep your response professional and technical.`
      },
    });
    return response.text || "Analysis failed.";
  } catch (error) {
    console.error("Maintenance AI Error:", error);
    return "The Neural Bridge is currently unstable. Please try manual migration.";
  }
}

export async function generateMenuDesign(prompt: string, base64Image?: string) {
  const ai = getAI();
  try {
    const contents: any[] = [{ text: prompt }];
    if (base64Image) {
      contents.push({
        inlineData: {
          mimeType: 'image/png',
          data: base64Image,
        }
      });
    }

    const response: any = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: { parts: contents },
    });

    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
    return null;
  } catch (error) {
    console.error("Image Gen Error:", error);
    return null;
  }
}
