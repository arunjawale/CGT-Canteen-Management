
import React, { useState, useEffect, useMemo } from 'react';
import { 
  Employee, 
  MealConfig, 
  Transaction, 
  AppSettings, 
  EmployeeStatus, 
  MealType,
  User,
  UserRole,
  PasswordResetRequest
} from './types';
import { 
  INITIAL_EMPLOYEES, 
  INITIAL_MEAL_CONFIGS, 
  DEFAULT_SETTINGS,
  MENU_ITEMS,
  INITIAL_USERS,
  CURRENT_SCHEMA_VERSION
} from './constants';
import AdminDashboard from './components/AdminDashboard';
import PunchStation from './components/PunchStation';
import EmployeeMaster from './components/EmployeeMaster';
import MealManagement from './components/MealManagement';
import Reports from './components/Reports';
import SettingsView from './components/SettingsView';
import Login from './components/Login';
import AdminManagement from './components/AdminManagement';
import MyRecords from './components/MyRecords';
import UserRegistryView from './components/UserRegistryView';
import { 
  LogOut, 
  Menu, 
  X, 
  User as UserIcon, 
  Lock, 
  ShieldAlert, 
  UserCog, 
  Briefcase, 
  Zap, 
  Activity,
  Globe,
  Database,
  MonitorSmartphone,
  ShieldCheck
} from 'lucide-react';

const App: React.FC = () => {
  const getStored = (key: string, defaultValue: any) => {
    const saved = localStorage.getItem(key);
    if (saved === null) return defaultValue;
    try {
      return JSON.parse(saved);
    } catch {
      return defaultValue;
    }
  };

  const [currentUser, setCurrentUser] = useState<User | null>(() => getStored('cgt_auth', null));
  const [activeTab, setActiveTab] = useState<string>(() => getStored('cgt_active_tab', 'dashboard'));
  const [users, setUsers] = useState<User[]>(() => getStored('cgt_users', INITIAL_USERS));
  const [employees, setEmployees] = useState<Employee[]>(() => getStored('cgt_employees', INITIAL_EMPLOYEES));
  const [mealConfigs, setMealConfigs] = useState<MealConfig[]>(() => getStored('cgt_meals', INITIAL_MEAL_CONFIGS));
  const [transactions, setTransactions] = useState<Transaction[]>(() => getStored('cgt_transactions', []));
  const [resetRequests, setResetRequests] = useState<PasswordResetRequest[]>(() => getStored('cgt_reset_requests', []));
  const [settings, setSettings] = useState<AppSettings>(() => getStored('cgt_settings', DEFAULT_SETTINGS));
  const [schemaVersion, setSchemaVersion] = useState<number>(() => getStored('cgt_schema_version', 1));
  
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [isLogoutModalOpen, setIsLogoutModalOpen] = useState(false);

  useEffect(() => { localStorage.setItem('cgt_auth', JSON.stringify(currentUser)); }, [currentUser]);
  useEffect(() => { localStorage.setItem('cgt_active_tab', JSON.stringify(activeTab)); }, [activeTab]);
  useEffect(() => { localStorage.setItem('cgt_users', JSON.stringify(users)); }, [users]);
  useEffect(() => { localStorage.setItem('cgt_employees', JSON.stringify(employees)); }, [employees]);
  useEffect(() => { localStorage.setItem('cgt_meals', JSON.stringify(mealConfigs)); }, [mealConfigs]);
  useEffect(() => { localStorage.setItem('cgt_transactions', JSON.stringify(transactions)); }, [transactions]);
  useEffect(() => { localStorage.setItem('cgt_reset_requests', JSON.stringify(resetRequests)); }, [resetRequests]);
  useEffect(() => { localStorage.setItem('cgt_settings', JSON.stringify(settings)); }, [settings]);
  useEffect(() => { localStorage.setItem('cgt_schema_version', JSON.stringify(schemaVersion)); }, [schemaVersion]);

  const registryIntegrity = useMemo(() => {
    if (employees.length === 0) return 100;
    const validCount = employees.filter(e => {
      const id = e.id.toUpperCase();
      return /^[A-Z0-9]+$/.test(id) && id.length >= 3 && id.length <= 12;
    }).length;
    return Math.round((validCount / employees.length) * 100);
  }, [employees]);

  const handleLogin = (user: User) => {
    setCurrentUser(user);
    // Auto-navigate to appropriate initial tab
    if (user.role === UserRole.IT_SUPER_USER) {
      setActiveTab('users');
    } else {
      setActiveTab('dashboard');
    }
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setIsLogoutModalOpen(false);
    setActiveTab('dashboard');
  };

  const handleAddTransaction = (tx: Transaction) => {
    setTransactions(prev => [tx, ...prev]);
  };

  const renderContent = () => {
    if (!currentUser) return null;
    switch (activeTab) {
      case 'dashboard': return <AdminDashboard employees={employees} transactions={transactions} meals={mealConfigs} integrityScore={registryIntegrity} />;
      case 'employees': return <EmployeeMaster currentUser={currentUser} employees={employees} setEmployees={setEmployees} />;
      case 'super-admins': return <UserRegistryView title="Super Admin Registry" description="Manage platform administrators." icon={<ShieldAlert />} themeColor="indigo" filterRoles={[UserRole.SUPER_ADMIN]} currentUser={currentUser} users={users} setUsers={setUsers} />;
      case 'hr-admins': return <UserRegistryView title="HR Admin Registry" description="Manage HR administrative access." icon={<UserCog />} themeColor="emerald" filterRoles={[UserRole.HR_ADMIN]} currentUser={currentUser} users={users} setUsers={setUsers} />;
      case 'staff-registry': return <UserRegistryView title="Staff Registry" description="Manage personnel portal access." icon={<Briefcase />} themeColor="amber" filterRoles={[UserRole.CANTEEN_STAFF, UserRole.EMPLOYEE]} currentUser={currentUser} users={users} setUsers={setUsers} employees={employees} />;
      case 'meals': return <MealManagement currentUser={currentUser} meals={mealConfigs} setMeals={setMealConfigs} />;
      case 'reports': return <Reports transactions={transactions} currentUser={currentUser} settings={settings} setSettings={setSettings} />;
      case 'users': return <AdminManagement users={users} setUsers={setUsers} currentUser={currentUser} resetRequests={resetRequests} setResetRequests={setResetRequests} employees={employees} />;
      case 'settings': return (
        <SettingsView 
          currentUser={currentUser} 
          settings={settings} 
          setSettings={setSettings} 
          schemaVersion={schemaVersion}
          setSchemaVersion={setSchemaVersion}
          appVersion={CURRENT_SCHEMA_VERSION}
          masterData={{ employees, transactions, mealConfigs, users }}
          setEmployees={setEmployees}
          setTransactions={setTransactions}
          setMealConfigs={setMealConfigs}
          setUsers={setUsers}
          onResetApp={() => { localStorage.clear(); window.location.reload(); }} 
        />
      );
      case 'punch': return <PunchStation employees={employees} meals={mealConfigs} onPunch={handleAddTransaction} transactions={transactions} settings={settings} onClose={() => setActiveTab('dashboard')} />;
      default: return <AdminDashboard employees={employees} transactions={transactions} meals={mealConfigs} integrityScore={registryIntegrity} />;
    }
  };

  if (!currentUser) {
    return <Login 
      onLogin={handleLogin} 
      users={users} 
      appName={settings.appName} 
      onRequestReset={(username) => {
        const newRequest: PasswordResetRequest = { id: 'REQ-' + Math.random().toString(36).substr(2, 5).toUpperCase(), username, requestedAt: new Date().toISOString(), status: 'PENDING' };
        setResetRequests(prev => [newRequest, ...prev]);
      }} 
      onRegisterIT={(u) => { setUsers(prev => [...prev, u]); }} 
    />;
  }

  const filteredMenuItems = MENU_ITEMS.filter(item => currentUser && item.roles.includes(currentUser.role));

  return (
    <div className="flex h-[100dvh] bg-slate-50 overflow-hidden select-none">
      {/* Responsive Sidebar */}
      <aside className={`fixed inset-y-0 left-0 z-50 w-72 bg-white border-r border-slate-200 transition-transform duration-300 ease-in-out lg:relative lg:translate-x-0 ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="flex flex-col h-full">
          <div className="p-8 flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className={`p-2.5 rounded-2xl text-white shadow-lg ${currentUser.role === UserRole.IT_SUPER_USER ? 'bg-slate-900' : 'bg-indigo-600'}`}><Zap size={24} /></div>
              <h1 className="text-lg font-black text-slate-900 leading-none tracking-tighter uppercase">{settings.appName}</h1>
            </div>
            <button className="lg:hidden p-2 text-slate-500 rounded-xl" onClick={() => setSidebarOpen(false)}><X size={20} /></button>
          </div>

          <nav className="flex-1 px-4 space-y-1.5 overflow-y-auto custom-scrollbar">
            {filteredMenuItems.map((item) => (
              <button
                key={item.id}
                onClick={() => { setActiveTab(item.id); if (window.innerWidth < 1024) setSidebarOpen(false); }}
                className={`w-full flex items-center gap-3 px-5 py-3.5 rounded-2xl text-sm font-bold transition-all ${activeTab === item.id ? 'bg-indigo-50 text-indigo-700' : 'text-slate-500 hover:bg-slate-50'}`}
              >
                <span className={`${activeTab === item.id ? 'text-indigo-600' : 'text-slate-400'}`}>{item.icon}</span>
                {item.label}
              </button>
            ))}
          </nav>

          <div className="p-6 border-t border-slate-100 bg-slate-50/30">
            <div className={`p-3 bg-white rounded-2xl border border-slate-200 shadow-sm ${currentUser.role === UserRole.IT_SUPER_USER ? 'border-indigo-200' : ''}`}>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center font-black text-sm uppercase">{currentUser.name.charAt(0)}</div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-black text-slate-900 truncate">{currentUser.name}</p>
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{currentUser.role}</p>
                </div>
              </div>
              <div className="flex items-center gap-2 mt-2 pt-2 border-t border-slate-50">
                <button onClick={() => setIsLogoutModalOpen(true)} className="w-full p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors flex items-center justify-center gap-2 text-[10px] font-black uppercase">
                  <LogOut size={14} /> Exit System
                </button>
              </div>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Container */}
      <div className="flex-1 flex flex-col min-w-0 relative">
        <header className="h-16 md:h-20 bg-white border-b border-slate-200 flex items-center justify-between px-6 md:px-10 shrink-0 sticky top-0 z-30">
          <button className="lg:hidden p-2 text-slate-600 hover:bg-slate-50 rounded-xl" onClick={() => setSidebarOpen(true)}><Menu size={24} /></button>
          <div className="flex items-center gap-3">
            <div className={`w-2 h-2 rounded-full animate-pulse ${currentUser.role === UserRole.IT_SUPER_USER ? 'bg-indigo-500' : 'bg-emerald-500'}`}></div>
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">{activeTab.replace('-', ' ')} Node Active</p>
          </div>
          <div className="flex items-center gap-6">
             <div className="text-right hidden sm:block">
                <p className="text-sm font-black text-slate-900 leading-none">{new Date().toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}</p>
                <p className="text-[10px] font-bold text-slate-400 uppercase mt-1">{new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</p>
             </div>
          </div>
        </header>

        <main className="flex-1 overflow-y-auto scroll-smooth custom-scrollbar bg-slate-50/50">
          <div className="max-w-[1440px] mx-auto p-4 md:p-8 lg:p-12 pb-32">
            {renderContent()}
          </div>
        </main>
      </div>

      {sidebarOpen && <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-40 lg:hidden" onClick={() => setSidebarOpen(false)} />}

      {isLogoutModalOpen && (
        <div className="fixed inset-0 z-[150] flex items-center justify-center p-6 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-300">
          <div className="bg-white w-full max-w-md rounded-[2.5rem] shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200 border-2 border-rose-100">
            <div className="p-10 text-center flex flex-col items-center">
              <div className="w-20 h-20 bg-rose-50 rounded-[2rem] flex items-center justify-center mb-8 shadow-inner"><LogOut className="w-10 h-10 text-rose-500 animate-pulse" /></div>
              <h3 className="text-2xl font-black text-slate-900 tracking-tighter mb-2 uppercase">Terminate Session?</h3>
              <p className="text-slate-500 font-medium text-sm px-4 leading-relaxed">Disconnecting from the <span className="font-black text-rose-600">Secure Network</span>.</p>
            </div>
            <div className="bg-rose-50/50 p-8 flex flex-col gap-3">
              <button onClick={handleLogout} className="w-full py-4 bg-rose-600 text-white rounded-2xl font-black uppercase tracking-widest text-xs shadow-xl hover:bg-rose-700 transition-all flex items-center justify-center gap-3"><ShieldAlert size={18} /> Confirm Logout</button>
              <button onClick={() => setIsLogoutModalOpen(false)} className="w-full py-4 bg-white border border-rose-100 text-rose-600 rounded-2xl font-black uppercase tracking-widest text-xs hover:bg-rose-50 transition-all">Cancel</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default App;
