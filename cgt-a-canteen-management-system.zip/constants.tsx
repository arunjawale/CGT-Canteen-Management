
import React from 'react';
import { MealType, EmployeeStatus, Employee, MealConfig, AppSettings, User, UserRole } from './types';
import { 
  LayoutDashboard, 
  Users, 
  UtensilsCrossed, 
  History, 
  Settings, 
  ScanLine,
  UserPlus,
  ClipboardList,
  LifeBuoy,
  ShieldAlert,
  UserCog, 
  Briefcase,
  Monitor
} from 'lucide-react';

// Centralized schema versioning
export const CURRENT_SCHEMA_VERSION = 3;

export const INITIAL_USERS: User[] = [
  { id: 'U000', username: 'it_support', password: 'root_password', role: UserRole.IT_SUPER_USER, name: 'IT Support Team' },
  { id: 'U001', username: 'admin', password: 'password123', role: UserRole.SUPER_ADMIN, name: 'Main Admin' },
  { id: 'U002', username: 'hr_user', password: 'hr_password', role: UserRole.HR_ADMIN, name: 'HR Manager' },
];

export const INITIAL_EMPLOYEES: Employee[] = [];

export const INITIAL_MEAL_CONFIGS: MealConfig[] = [
  { id: MealType.BREAKFAST, name: 'Breakfast', startTime: '08:00', endTime: '10:00', price: 0, isFree: true, isActive: true, gracePeriod: 30, flexibleForRotating: true },
  { id: MealType.LUNCH, name: 'Lunch', startTime: '12:30', endTime: '14:30', price: 0, isFree: true, isActive: true, gracePeriod: 30, flexibleForRotating: true },
  { id: MealType.SNACKS, name: 'Evening Snacks', startTime: '16:30', endTime: '17:30', price: 0, isFree: true, isActive: true, gracePeriod: 15, flexibleForRotating: false },
  { id: MealType.DINNER, name: 'Dinner', startTime: '19:30', endTime: '21:30', price: 0, isFree: true, isActive: true, gracePeriod: 45, flexibleForRotating: true },
];

export const DEFAULT_SETTINGS: AppSettings = {
  appName: 'CGT Management System',
  themeColor: '#4f46e5',
  language: 'English',
  notices: 'System initialized. Free meal distribution protocol active for all authorized personnel.',
  currencySymbol: '₹',
  reportFrequency: 'Daily',
  reportEmail: 'finance@cgt.com',
  enableAutoEmail: false,
  autoLockTimeout: 30,
  enableSoundEffects: true,
  terminalVolume: 80,
  backupSchedule: 'Never',
  supportEmail: 'cgt.it-support@company.com',
  punchScreenTimeout: 3,
  manualPunchReset: false,
  manualResetTimeoutHours: 24,
  enablePrinting: true,
  keepScreenAwake: true
};

export const MENU_ITEMS = [
  { id: 'punch', label: 'STATION MODE', icon: <ScanLine size={20} />, roles: [UserRole.IT_SUPER_USER, UserRole.CANTEEN_STAFF, UserRole.SUPER_ADMIN] },
  { id: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard size={20} />, roles: [UserRole.IT_SUPER_USER, UserRole.SUPER_ADMIN, UserRole.HR_ADMIN] },
  { id: 'employees', label: 'Employee Master', icon: <Users size={20} />, roles: [UserRole.SUPER_ADMIN, UserRole.HR_ADMIN, UserRole.IT_SUPER_USER] },
  { id: 'reports', label: 'Reports & Audit', icon: <History size={20} />, roles: [UserRole.SUPER_ADMIN, UserRole.HR_ADMIN, UserRole.CANTEEN_STAFF, UserRole.IT_SUPER_USER] },
  
  // Security & Staff Management
  { id: 'super-admins', label: 'Super Admin Registry', icon: <ShieldAlert size={20} />, roles: [UserRole.SUPER_ADMIN, UserRole.IT_SUPER_USER] },
  { id: 'hr-admins', label: 'HR Admin Registry', icon: <UserCog size={20} />, roles: [UserRole.HR_ADMIN, UserRole.SUPER_ADMIN, UserRole.IT_SUPER_USER] },
  { id: 'staff-registry', label: 'Staff Accounts', icon: <Briefcase size={20} />, roles: [UserRole.HR_ADMIN, UserRole.SUPER_ADMIN, UserRole.IT_SUPER_USER] },
  
  { id: 'meals', label: 'Meal Config', icon: <UtensilsCrossed size={20} />, roles: [UserRole.IT_SUPER_USER, UserRole.SUPER_ADMIN] },
  { id: 'users', label: 'Security Center', icon: <UserPlus size={20} />, roles: [UserRole.IT_SUPER_USER] },
  { id: 'settings', label: 'System Settings', icon: <Settings size={20} />, roles: [UserRole.IT_SUPER_USER, UserRole.SUPER_ADMIN] },
  { id: 'my-records', label: 'My Records', icon: <ClipboardList size={20} />, roles: [UserRole.EMPLOYEE] },
];