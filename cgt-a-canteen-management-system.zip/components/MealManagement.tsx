
import React, { useState, useEffect } from 'react';
import { MealConfig, MealType, User, UserRole } from '../types';
import { 
  Clock, 
  Settings2, 
  Sparkles,
  RefreshCw,
  Image as ImageIcon,
  Timer,
  Lock,
  Zap,
  CalendarDays,
  CheckCircle2,
  XCircle,
  History,
  Activity,
  Power
} from 'lucide-react';
import { generateMenuDesign } from '../services/gemini';

interface Props {
  meals: MealConfig[];
  setMeals: (meals: MealConfig[]) => void;
  currentUser: User;
}

const MealManagement: React.FC<Props> = ({ meals, setMeals, currentUser }) => {
  const getStored = (key: string, defaultValue: any) => {
    const saved = localStorage.getItem(key);
    if (saved === null) return defaultValue;
    try {
      return JSON.parse(saved);
    } catch {
      return defaultValue;
    }
  };

  const [loadingAi, setLoadingAi] = useState(false);
  const [aiResultImage, setAiResultImage] = useState<string | null>(() => getStored('cgt_meals_ai_result', null));
  const [aiPrompt, setAiPrompt] = useState(() => getStored('cgt_meals_ai_prompt', 'Create a modern, clean lunch menu design for an office canteen'));
  const [now, setNow] = useState(new Date());

  // Persistence
  useEffect(() => {
    localStorage.setItem('cgt_meals_ai_prompt', JSON.stringify(aiPrompt));
  }, [aiPrompt]);

  useEffect(() => {
    localStorage.setItem('cgt_meals_ai_result', JSON.stringify(aiResultImage));
  }, [aiResultImage]);

  useEffect(() => {
    const timer = setInterval(() => setNow(new Date()), 60000);
    return () => clearInterval(timer);
  }, []);

  const isIT = currentUser.role === UserRole.IT_SUPER_USER;

  const handleUpdate = (id: MealType, updates: Partial<MealConfig>) => {
    if (!isIT) {
      alert("Unauthorized: Only IT Support can modify meal configurations.");
      return;
    }
    setMeals(meals.map(m => m.id === id ? { ...m, ...updates } : m));
  };

  const handleGenerateMenu = async () => {
    setLoadingAi(true);
    const res = await generateMenuDesign(aiPrompt);
    if (res) setAiResultImage(res);
    setLoadingAi(false);
  };

  const formatToFriendlyTime = (time: string) => {
    if (!time) return '--:-- --';
    const [hours, minutes] = time.split(':').map(Number);
    const ampm = hours >= 12 ? 'PM' : 'AM';
    const h = hours % 12 || 12;
    const m = minutes.toString().padStart(2, '0');
    return `${h}:${m} ${ampm}`;
  };

  const getMealStatus = (meal: MealConfig) => {
    if (!meal.isActive) return { label: 'OFFLINE', color: 'bg-slate-100 text-slate-400', icon: <XCircle size={12} /> };
    
    const currentMinutes = now.getHours() * 60 + now.getMinutes();
    const [startH, startM] = meal.startTime.split(':').map(Number);
    const [endH, endM] = meal.endTime.split(':').map(Number);
    
    const startTotal = startH * 60 + startM;
    const endTotal = endH * 60 + endM;

    if (currentMinutes >= startTotal && currentMinutes <= endTotal) {
      return { label: 'ACTIVE NOW', color: 'bg-emerald-500 text-white shadow-emerald-200 shadow-lg', icon: <CheckCircle2 size={12} /> };
    } else if (currentMinutes > endTotal) {
      return { label: 'WINDOW CLOSED', color: 'bg-rose-100 text-rose-600 border border-rose-200', icon: <History size={12} /> };
    } else {
      return { label: 'UPCOMING', color: 'bg-indigo-50 text-indigo-600 border border-indigo-100', icon: <Clock size={12} /> };
    }
  };

  const TimeSelector = ({ value, onChange, disabled }: { value: string, onChange: (val: string) => void, disabled: boolean }) => {
    const [h24, m24] = value.split(':').map(Number);
    const period = h24 >= 12 ? 'PM' : 'AM';
    const h12 = h24 % 12 || 12;

    const updateTime = (newH12: number, newM: number, newPeriod: string) => {
      let validatedH12 = Math.max(1, Math.min(12, newH12));
      let validatedM = Math.max(0, Math.min(59, newM));
      
      let h = validatedH12;
      if (newPeriod === 'PM' && validatedH12 < 12) h += 12;
      if (newPeriod === 'AM' && validatedH12 === 12) h = 0;
      onChange(`${h.toString().padStart(2, '0')}:${validatedM.toString().padStart(2, '0')}`);
    };

    return (
      <div className="flex items-center gap-2 bg-gray-50 p-2 rounded-2xl border border-gray-100 group-focus-within:border-indigo-500/30 transition-all">
        <div className="flex flex-col items-center">
          <input 
            type="number" 
            min="1" 
            max="12"
            disabled={disabled}
            value={h12}
            onChange={(e) => updateTime(Number(e.target.value), m24, period)}
            className="w-12 text-center bg-transparent font-black text-slate-900 outline-none"
          />
          <span className="text-[8px] font-black text-slate-400 uppercase tracking-tighter">HH</span>
        </div>
        <span className="font-black text-slate-300 mb-2">:</span>
        <div className="flex flex-col items-center">
          <input 
            type="number" 
            min="0" 
            max="59"
            disabled={disabled}
            value={m24}
            onChange={(e) => updateTime(h12, Number(e.target.value), period)}
            className="w-12 text-center bg-transparent font-black text-slate-900 outline-none"
          />
          <span className="text-[8px] font-black text-slate-400 uppercase tracking-tighter">MM</span>
        </div>
        <div className="flex flex-col gap-1 ml-1">
          <button 
            type="button"
            disabled={disabled}
            onClick={() => updateTime(h12, m24, 'AM')}
            className={`px-2 py-0.5 rounded text-[8px] font-black transition-all ${period === 'AM' ? 'bg-indigo-600 text-white shadow-md' : 'bg-white text-slate-400 border border-slate-100'}`}
          >
            AM
          </button>
          <button 
            type="button"
            disabled={disabled}
            onClick={() => updateTime(h12, m24, 'PM')}
            className={`px-2 py-0.5 rounded text-[8px] font-black transition-all ${period === 'PM' ? 'bg-indigo-600 text-white shadow-md' : 'bg-white text-slate-400 border border-slate-100'}`}
          >
            PM
          </button>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-8 pb-10">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-black text-gray-900 tracking-tight">Meal Node Control</h2>
          <p className="text-gray-500 font-medium">Configure timings and operational status of free service nodes.</p>
        </div>
        {!isIT && (
          <div className="flex items-center gap-2 px-6 py-3 bg-amber-50 text-amber-600 text-[10px] font-black uppercase tracking-widest rounded-2xl border border-amber-100 shadow-sm">
            <Lock size={14} /> IT Support Restricted View
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
        <div className="xl:col-span-2 space-y-6">
          {meals.map((meal) => {
            const status = getMealStatus(meal);
            return (
              <div key={meal.id} className={`bg-white rounded-[2.5rem] border ${meal.isActive ? 'border-gray-200 shadow-sm' : 'border-slate-100 bg-slate-50/30 grayscale-[0.5]'} overflow-hidden relative transition-all hover:shadow-xl group`}>
                {!isIT && <div className="absolute inset-0 z-10 bg-white/0 cursor-not-allowed" title="Access Denied: Requires IT Support privileges"></div>}
                
                <div className="p-8 flex flex-col md:flex-row gap-8">
                  <div className="flex flex-col items-center gap-4">
                    <div className={`p-6 rounded-[2rem] transition-all shadow-inner border ${meal.isActive ? 'bg-indigo-50 text-indigo-600 border-indigo-100' : 'bg-slate-100 text-slate-400 border-slate-200'}`}>
                      <Clock size={48} />
                    </div>
                    
                    <div className="flex flex-col items-center gap-2">
                       <label className="text-[8px] font-black text-slate-400 uppercase tracking-widest leading-none">Punching Node</label>
                       <button 
                        onClick={() => handleUpdate(meal.id, { isActive: !meal.isActive })}
                        disabled={!isIT}
                        className={`relative inline-flex h-8 w-16 items-center rounded-full transition-all focus:outline-none focus:ring-4 focus:ring-indigo-500/10 shadow-inner ${
                          meal.isActive ? 'bg-indigo-600' : 'bg-slate-200'
                        } ${!isIT ? 'cursor-not-allowed' : 'cursor-pointer'}`}
                       >
                         <span
                           className={`inline-block h-6 w-6 transform rounded-full bg-white transition-all shadow-md ${
                             meal.isActive ? 'translate-x-9' : 'translate-x-1'
                           } flex items-center justify-center`}
                         >
                           {meal.isActive ? <Power size={12} className="text-indigo-600" /> : <XCircle size={12} className="text-slate-300" />}
                         </span>
                       </button>
                       <span className={`text-[9px] font-black uppercase tracking-widest ${meal.isActive ? 'text-indigo-600' : 'text-slate-400'}`}>
                         {meal.isActive ? 'ONLINE' : 'OFFLINE'}
                       </span>
                    </div>
                  </div>
                  
                  <div className="flex-1 space-y-6">
                    <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
                      <div>
                        <div className="flex items-center gap-4">
                          <h3 className="text-2xl font-black text-gray-900 tracking-tight">{meal.name}</h3>
                          <div className={`flex items-center gap-2 px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest ${status.color}`}>
                            {status.icon}
                            {status.label}
                          </div>
                        </div>
                        <div className="flex items-center gap-2 mt-2">
                          <CalendarDays size={16} className="text-indigo-400" />
                          <p className="text-base font-black text-indigo-600">
                            {formatToFriendlyTime(meal.startTime)} <span className="text-slate-300 mx-2">—</span> {formatToFriendlyTime(meal.endTime)}
                          </p>
                        </div>
                      </div>
                      
                      <div className="flex flex-wrap gap-2">
                        <button 
                          onClick={() => handleUpdate(meal.id, { flexibleForRotating: !meal.flexibleForRotating })}
                          disabled={!isIT}
                          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-[10px] font-black transition-all uppercase tracking-widest border ${
                            meal.flexibleForRotating 
                            ? 'bg-white text-indigo-600 border-indigo-200 shadow-lg shadow-indigo-50' 
                            : 'bg-slate-50 text-slate-400 border-slate-100'
                          } ${!isIT ? 'cursor-not-allowed opacity-50' : 'hover:scale-105 active:scale-95'}`}
                          title="Allow rotating shift workers to punch outside standard hours"
                        >
                          <Zap size={14} />
                          {meal.flexibleForRotating ? 'Flex Timing Active' : 'Strict Timing'}
                        </button>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 gap-6 items-end">
                      <div className="space-y-3">
                        <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest px-1">Session Broadcast Window</label>
                        <div className="flex flex-wrap items-center gap-6 p-4 bg-slate-50/50 rounded-[2rem] border border-slate-100 group-hover:bg-white transition-colors">
                          <div className="flex items-center gap-8">
                             <div className="flex flex-col gap-1">
                               <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest ml-1">Open At</span>
                               <TimeSelector 
                                value={meal.startTime} 
                                disabled={!isIT} 
                                onChange={(val) => handleUpdate(meal.id, { startTime: val })} 
                               />
                             </div>
                             <div className="h-10 w-px bg-slate-200 mt-4"></div>
                             <div className="flex flex-col gap-1">
                               <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest ml-1">Close At</span>
                               <TimeSelector 
                                value={meal.endTime} 
                                disabled={!isIT} 
                                onChange={(val) => handleUpdate(meal.id, { endTime: val })} 
                               />
                             </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex flex-col sm:flex-row justify-between items-center pt-4 border-t border-slate-50 gap-4">
                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                        <Activity size={12} className="text-indigo-400 animate-pulse" />
                        Node Health: Secure & Synchronized
                      </p>
                      <div className="flex gap-4 items-center">
                        <span className="px-6 py-3 bg-emerald-50 text-emerald-700 rounded-2xl text-[10px] font-black uppercase tracking-widest border border-emerald-100">
                          Free Service Only
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        <div className="space-y-6">
          <div className="bg-white rounded-[3rem] border border-gray-200 overflow-hidden shadow-2xl flex flex-col sticky top-8">
            <div className="p-10 border-b border-gray-100 bg-gradient-to-br from-indigo-600 to-indigo-900 text-white relative overflow-hidden">
              <div className="absolute top-0 right-0 w-48 h-48 bg-white/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2"></div>
              <div className="flex items-center gap-4 mb-4 relative z-10">
                <div className="p-3 bg-white/10 rounded-2xl backdrop-blur-md border border-white/10">
                  <Sparkles size={28} className="text-amber-400" />
                </div>
                <h3 className="font-black text-2xl uppercase tracking-tighter">AI Node Designer</h3>
              </div>
              <p className="text-indigo-100 text-sm font-medium opacity-80 relative z-10">Generate promotional digital signage for your free meal nodes.</p>
            </div>
            
            <div className="p-10 space-y-8">
              <div className="space-y-4">
                <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-1">Generation Context</label>
                <textarea 
                  value={aiPrompt}
                  onChange={(e) => setAiPrompt(e.target.value)}
                  className="w-full h-40 p-6 text-sm font-medium bg-gray-50 border border-gray-200 rounded-[2rem] resize-none focus:ring-4 focus:ring-indigo-500/10 focus:bg-white outline-none transition-all placeholder:text-gray-300 shadow-inner"
                  placeholder="e.g. Modern minimalist design for Monday Breakfast highlighting complimentary status..."
                />
              </div>

              <button 
                onClick={handleGenerateMenu}
                disabled={loadingAi}
                className="w-full flex items-center justify-center gap-4 bg-indigo-600 text-white py-6 rounded-[2rem] font-black uppercase tracking-widest text-xs hover:bg-indigo-700 disabled:opacity-50 transition-all shadow-2xl shadow-indigo-100 group"
              >
                {loadingAi ? <RefreshCw className="animate-spin" size={20} /> : <Zap size={20} className="group-hover:scale-110 transition-transform" />}
                {loadingAi ? 'Synthesizing...' : 'Generate Node Signage'}
              </button>

              {aiResultImage && (
                <div className="mt-4 animate-in fade-in zoom-in duration-700">
                  <div className="relative group rounded-[2.5rem] overflow-hidden border-8 border-slate-50 shadow-2xl ring-1 ring-slate-200">
                    <img src={aiResultImage} alt="AI Menu" className="w-full aspect-square object-cover" />
                    <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center gap-4 backdrop-blur-md">
                      <p className="text-white font-black text-xs uppercase tracking-widest">Signage Rendered</p>
                      <a 
                        href={aiResultImage} 
                        download="meal-node-signage.png" 
                        className="px-8 py-4 bg-white text-gray-900 rounded-[1.5rem] font-black text-[10px] flex items-center gap-3 shadow-2xl hover:scale-105 transition-transform uppercase tracking-widest"
                      >
                        <ImageIcon size={18} /> Export as Asset
                      </a>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MealManagement;
