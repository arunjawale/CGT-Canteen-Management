
import React, { useState } from 'react';
import { User, UserRole, PasswordResetRequest, Employee } from '../types';
import { 
  Plus, 
  Trash2, 
  Edit2, 
  Shield, 
  X, 
  UserCheck, 
  AlertTriangle, 
  Key, 
  Clock, 
  UserCog,
  ShieldAlert,
  ShieldCheck,
  XCircle,
  Fingerprint,
  Lock,
  Unlock,
  Activity,
  Link as LinkIcon,
  Users,
  LifeBuoy,
  Zap
} from 'lucide-react';

interface Props {
  users: User[];
  setUsers: (users: User[]) => void;
  currentUser: User;
  resetRequests: PasswordResetRequest[];
  setResetRequests: (requests: PasswordResetRequest[]) => void;
  employees: Employee[];
}

const AdminManagement: React.FC<Props> = ({ users, setUsers, currentUser, resetRequests, setResetRequests, employees }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [approvalModal, setApprovalModal] = useState<PasswordResetRequest | null>(null);
  const [tempPassword, setTempPassword] = useState('');

  const isIT = currentUser.role === UserRole.IT_SUPER_USER;

  const canManageUser = (targetUser: User) => {
    // 1. IT Super User can manage EVERYTHING
    if (isIT) return true;
    
    // 2. Prevent self-lockout
    if (targetUser.id === currentUser.id) return false;
    
    // 3. Super Admins can manage anyone EXCEPT IT Super Users and other Super Admins
    if (targetUser.role === UserRole.IT_SUPER_USER) return false;
    
    if (targetUser.role === UserRole.SUPER_ADMIN) {
      return currentUser.role === UserRole.SUPER_ADMIN;
    }
    
    if (currentUser.role === UserRole.SUPER_ADMIN) return true;
    return false;
  };

  const handleDelete = (id: string) => {
    const target = users.find(u => u.id === id);
    if (!target) return;

    if (!canManageUser(target)) {
      alert("Unauthorized: Security hierarchy prevents modification of this tier.");
      return;
    }

    if (confirm(`SECURITY ALERT: You are about to permanently revoke access for ${target.name}. Continue?`)) {
      setUsers(users.filter(u => u.id !== id));
    }
  };

  const handleApproveReset = (e: React.FormEvent) => {
    e.preventDefault();
    if (!approvalModal || !tempPassword) return;

    const updatedUsers = users.map(u => 
      u.username === approvalModal.username ? { ...u, password: tempPassword } : u
    );
    setUsers(updatedUsers);

    const updatedRequests = resetRequests.map(r => 
      r.id === approvalModal.id ? { ...r, status: 'APPROVED' as const } : r
    );
    setResetRequests(updatedRequests);

    setApprovalModal(null);
    setTempPassword('');
  };

  const handleRejectReset = (id: string) => {
    const updatedRequests = resetRequests.map(r => 
      r.id === id ? { ...r, status: 'REJECTED' as const } : r
    );
    setResetRequests(updatedRequests);
  };

  const pendingRequests = resetRequests.filter(r => r.status === 'PENDING');

  return (
    <div className="space-y-10 animate-in fade-in duration-700 pb-20">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <div className="flex items-center gap-2 mb-2">
            {isIT ? <LifeBuoy className="text-indigo-600" size={20} /> : <ShieldCheck className="text-indigo-600" size={20} />}
            <span className="text-[10px] font-black uppercase tracking-[0.2em] text-indigo-600">
              {isIT ? 'IT Command Hub' : 'Identity Control Center'}
            </span>
          </div>
          <h2 className="text-4xl font-black text-gray-900 tracking-tight leading-none">Security Center</h2>
          <p className="text-gray-500 font-medium mt-2 max-w-md italic">
            {isIT ? 'Universal credential management and node override console.' : 'Manage credential tiers and authorize system identities.'}
          </p>
        </div>
        <div className="flex gap-4">
          <div className="bg-white px-6 py-4 rounded-[1.5rem] border border-gray-100 shadow-sm flex items-center gap-4">
            <div className="p-2 bg-slate-50 rounded-xl">
              <Activity size={18} className="text-slate-400" />
            </div>
            <div>
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest leading-none mb-1">Total Identities</p>
              <p className="text-xl font-black text-slate-900 leading-none">{users.length}</p>
            </div>
          </div>
          <button 
            onClick={() => { setEditingUser(null); setIsModalOpen(true); }}
            className="flex items-center gap-3 bg-indigo-600 text-white px-10 py-5 rounded-[2rem] hover:bg-indigo-700 transition-all font-black uppercase tracking-widest text-xs shadow-2xl shadow-indigo-200"
          >
            <Plus size={20} />
            Authorize New Tier
          </button>
        </div>
      </div>

      {pendingRequests.length > 0 && (
        <div className={`${isIT ? 'bg-slate-950' : 'bg-indigo-900'} rounded-[3rem] p-10 space-y-8 shadow-2xl relative overflow-hidden transition-colors duration-500`}>
          <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full -translate-y-1/2 translate-x-1/2 blur-3xl"></div>
          <div className="flex items-center justify-between relative z-10">
            <div className="flex items-center gap-5">
              <div className={`w-14 h-14 backdrop-blur-md rounded-2xl flex items-center justify-center border border-white/5 ${isIT ? 'bg-indigo-500/20 text-indigo-400' : 'bg-white/10 text-indigo-300'}`}>
                <Key size={28} />
              </div>
              <div>
                <h3 className="text-2xl font-black text-white">Support Queue</h3>
                <p className="text-sm font-bold text-indigo-300/80 uppercase tracking-widest">Awaiting Security Key Reset</p>
              </div>
            </div>
            <div className="px-5 py-2 bg-indigo-500 text-white text-xs font-black rounded-full shadow-lg">
              {pendingRequests.length} Pending Tasks
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 relative z-10">
            {pendingRequests.map(req => (
              <div key={req.id} className="bg-white/5 backdrop-blur-xl p-8 rounded-[2rem] border border-white/5 shadow-xl flex flex-col justify-between gap-6 hover:bg-white/10 transition-colors">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-lg font-black text-white">ID: @{req.username}</p>
                    <div className="flex items-center gap-2 text-[10px] font-bold text-indigo-400 uppercase tracking-widest mt-1">
                      <Clock size={12} /> Logged {new Date(req.requestedAt).toLocaleTimeString()}
                    </div>
                  </div>
                  {isIT && <Zap size={18} className="text-indigo-400 animate-pulse" />}
                </div>
                <div className="flex gap-3">
                  <button onClick={() => setApprovalModal(req)} className="flex-1 bg-white text-indigo-900 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-indigo-50 transition-colors shadow-lg">
                    Approve Reset
                  </button>
                  <button onClick={() => handleRejectReset(req.id)} className="p-3 bg-white/5 text-white/40 hover:text-red-400 hover:bg-red-500/10 rounded-xl transition-all">
                    <XCircle size={20} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {users.map(user => {
          const manageable = canManageUser(user);
          const isSuper = user.role === UserRole.SUPER_ADMIN;
          const isITUser = user.role === UserRole.IT_SUPER_USER;
          
          return (
            <div key={user.id} className={`bg-white p-10 rounded-[3rem] border shadow-sm hover:shadow-2xl transition-all relative overflow-hidden group ${isITUser ? 'border-slate-900 ring-2 ring-indigo-50' : isSuper ? 'border-indigo-100 ring-1 ring-indigo-50' : 'border-gray-100'}`}>
              <div className={`absolute top-0 left-0 w-full h-2 ${isITUser ? 'bg-slate-900' : isSuper ? 'bg-indigo-600' : 'bg-slate-200'}`}></div>
              {manageable && (
                <div className="absolute top-6 right-6 opacity-0 group-hover:opacity-100 transition-all duration-300 flex gap-2">
                  <button onClick={() => { setEditingUser(user); setIsModalOpen(true); }} className="p-3 bg-slate-50 text-slate-400 rounded-2xl hover:bg-indigo-600 hover:text-white transition-all">
                    <Edit2 size={16} />
                  </button>
                  <button onClick={() => handleDelete(user.id)} className="p-3 bg-slate-50 text-slate-400 rounded-2xl hover:bg-red-600 hover:text-white transition-all">
                    <Trash2 size={16} />
                  </button>
                </div>
              )}
              <div className="flex flex-col items-center text-center mb-8">
                <div className={`w-24 h-24 rounded-[2rem] flex items-center justify-center shadow-xl mb-6 relative group/avatar transition-transform duration-500 group-hover:scale-105 ${
                  isITUser ? 'bg-slate-900 text-white shadow-indigo-100' :
                  isSuper ? 'bg-indigo-600 text-white shadow-indigo-200' : 
                  user.role === UserRole.HR_ADMIN ? 'bg-emerald-500 text-white shadow-emerald-100' : 
                  user.role === UserRole.EMPLOYEE ? 'bg-indigo-400 text-white shadow-indigo-100' :
                  'bg-slate-800 text-white shadow-slate-100'
                }`}>
                  {isITUser ? <LifeBuoy size={44} /> : isSuper ? <ShieldCheck size={44} /> : user.role === UserRole.HR_ADMIN ? <UserCheck size={44} /> : user.role === UserRole.EMPLOYEE ? <Users size={44} /> : <UserCog size={44} />}
                </div>
                <div className="max-w-full">
                  <h3 className="font-black text-2xl text-gray-900 truncate px-2">{user.name}</h3>
                  <p className="text-sm text-indigo-600/50 font-black uppercase tracking-[0.2em] mt-1">@{user.username}</p>
                </div>
              </div>
              <div className="space-y-6">
                <div className="flex items-center justify-center">
                  <span className={`px-6 py-2 rounded-full text-[10px] font-black uppercase tracking-[0.2em] shadow-sm ${
                    isITUser ? 'bg-slate-900 text-white' :
                    isSuper ? 'bg-indigo-600 text-white shadow-indigo-200' : 
                    user.role === UserRole.HR_ADMIN ? 'bg-emerald-50 text-emerald-700 border border-emerald-100' : 
                    user.role === UserRole.EMPLOYEE ? 'bg-indigo-50 text-indigo-700 border border-indigo-100' :
                    'bg-slate-100 text-slate-700'
                  }`}>
                    {user.role}
                  </span>
                </div>
                {user.employeeId && (
                  <div className="flex items-center justify-center gap-2 text-[10px] font-black text-indigo-400 uppercase tracking-widest">
                    <LinkIcon size={12} /> Employee Linked: {user.employeeId}
                  </div>
                )}
                <div className="pt-6 border-t border-slate-50 flex items-center justify-between">
                  <div className="flex items-center gap-1.5 text-[10px] font-black text-slate-300 uppercase tracking-widest">
                    <Activity size={12} /> REF: {user.id.substr(-4)}
                  </div>
                  {user.id === currentUser.id && <span className="text-[10px] font-black text-indigo-400 uppercase bg-indigo-50 px-3 py-1 rounded-lg">Current Session</span>}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-6 bg-slate-900/80 backdrop-blur-xl animate-in fade-in duration-300">
          <div className="bg-white w-full max-w-lg rounded-[3.5rem] shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200">
            <div className="px-12 py-10 border-b border-slate-50 flex items-center justify-between bg-slate-50/30">
              <div>
                <h3 className="text-3xl font-black text-slate-900 tracking-tighter">{editingUser ? 'Update Authorization' : 'New Tier Provisioning'}</h3>
                <p className="text-[11px] font-black text-slate-400 uppercase tracking-widest mt-2 flex items-center gap-2">
                  <Shield size={14} className="text-indigo-500" /> Identity Matrix Assignment
                </p>
              </div>
              <button onClick={() => setIsModalOpen(false)} className="text-slate-300 hover:text-slate-900 transition-colors p-3 hover:bg-slate-100 rounded-2xl">
                <X size={32} />
              </button>
            </div>
            
            <form className="p-12 space-y-8" onSubmit={(e) => {
              e.preventDefault();
              const formData = new FormData(e.currentTarget);
              const username = (formData.get('username') as string).toLowerCase();
              
              if (!editingUser && users.some(u => u.username.toLowerCase() === username)) {
                alert("Conflict: Identity Identifier already exists in database.");
                return;
              }

              const newUser: User = {
                id: editingUser?.id || 'U' + Math.random().toString(36).substr(2, 5).toUpperCase(),
                name: formData.get('name') as string,
                username: username,
                password: (formData.get('password') as string) || editingUser?.password || 'password123',
                role: formData.get('role') as UserRole,
                employeeId: formData.get('employeeId') as string || undefined
              };

              // Security Rules
              if (newUser.role === UserRole.IT_SUPER_USER && !isIT) {
                alert("Unauthorized: IT-level provisioning requires support clearance.");
                return;
              }
              
              if (newUser.role === UserRole.SUPER_ADMIN && !isIT && currentUser.role !== UserRole.SUPER_ADMIN) {
                alert("Unauthorized: Insufficient tier level to provision a Super Admin.");
                return;
              }

              if (editingUser) {
                setUsers(users.map(u => u.id === editingUser.id ? newUser : u));
              } else {
                setUsers([...users, newUser]);
              }
              setIsModalOpen(false);
            }}>
              <div className="space-y-3">
                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] px-1">Display Name</label>
                <input name="name" defaultValue={editingUser?.name} required placeholder="Full Name" className="w-full px-6 py-4 bg-slate-50 border border-slate-200 rounded-[1.5rem] focus:ring-4 focus:ring-indigo-500/10 outline-none font-bold" />
              </div>
              <div className="grid grid-cols-2 gap-8">
                <div className="space-y-3">
                  <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] px-1">Identity Identifier</label>
                  <input name="username" defaultValue={editingUser?.username} required placeholder="Identity Identifier" className="w-full px-6 py-4 bg-slate-50 border border-slate-200 rounded-[1.5rem] focus:ring-4 focus:ring-indigo-500/10 outline-none font-bold" />
                </div>
                <div className="space-y-3">
                  <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] px-1">Access Tier</label>
                  <select name="role" defaultValue={editingUser?.role || UserRole.CANTEEN_STAFF} className="w-full px-6 py-4 bg-slate-50 border border-slate-200 rounded-[1.5rem] focus:ring-4 focus:ring-indigo-500/10 outline-none font-bold appearance-none cursor-pointer">
                    {Object.values(UserRole).map(role => (
                      <option 
                        key={role} 
                        value={role} 
                        disabled={
                          (role === UserRole.IT_SUPER_USER && !isIT) ||
                          (role === UserRole.SUPER_ADMIN && !isIT && currentUser.role !== UserRole.SUPER_ADMIN)
                        }
                      >
                        {role}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
              <div className="space-y-3">
                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] px-1">Employee Linkage (Optional)</label>
                <select name="employeeId" defaultValue={editingUser?.employeeId} className="w-full px-6 py-4 bg-slate-50 border border-slate-200 rounded-[1.5rem] focus:ring-4 focus:ring-indigo-500/10 outline-none font-bold appearance-none cursor-pointer">
                  <option value="">No Physical Node Link</option>
                  {employees.map(emp => (
                    <option key={emp.id} value={emp.id}>{emp.name} ({emp.id})</option>
                  ))}
                </select>
              </div>
              <div className="space-y-3">
                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] px-1">Provision Security Key</label>
                <input type="password" name="password" className="w-full px-6 py-4 bg-slate-900 border border-slate-800 rounded-[2rem] text-white text-center font-mono tracking-widest placeholder:tracking-normal" placeholder={editingUser ? "MAINTAIN CURRENT KEY" : "SET INITIAL KEY"} />
              </div>
              <div className="pt-6 flex gap-4">
                <button type="button" onClick={() => setIsModalOpen(false)} className="flex-1 px-8 py-5 bg-slate-100 text-slate-600 font-black uppercase rounded-[1.5rem] hover:bg-slate-200 transition-all text-xs">Abort</button>
                <button type="submit" className="flex-1 px-8 py-5 bg-indigo-600 text-white font-black uppercase rounded-[1.5rem] hover:bg-indigo-700 transition-all text-xs shadow-xl">Apply Identity</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {approvalModal && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-6 bg-slate-950/90 backdrop-blur-2xl animate-in fade-in duration-300">
          <div className="bg-white w-full max-w-md rounded-[3rem] shadow-2xl overflow-hidden">
            <div className="px-10 py-8 border-b border-slate-50 flex items-center justify-between">
              <div>
                <h3 className="text-2xl font-black text-slate-900 tracking-tight">Support Override</h3>
                <p className="text-[10px] font-black text-amber-600 uppercase tracking-widest mt-1">Emergency Key Reset: @{approvalModal.username}</p>
              </div>
              <button onClick={() => setApprovalModal(null)} className="text-slate-300 hover:text-slate-900 p-2"><X size={24} /></button>
            </div>
            <form onSubmit={handleApproveReset} className="p-10 space-y-8">
              <div className="space-y-3">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] px-1">New Manual Security Key</label>
                <input autoFocus required value={tempPassword} onChange={(e) => setTempPassword(e.target.value)} placeholder="0000" className="w-full px-6 py-5 bg-slate-50 border border-slate-200 rounded-[1.5rem] focus:ring-4 focus:ring-amber-500/10 outline-none font-bold text-center text-xl tracking-[0.3em]" />
              </div>
              <button type="submit" className="w-full bg-amber-500 text-white py-5 rounded-[1.5rem] font-black uppercase tracking-widest shadow-xl hover:bg-amber-600 transition-all">Override and Authorize</button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminManagement;
