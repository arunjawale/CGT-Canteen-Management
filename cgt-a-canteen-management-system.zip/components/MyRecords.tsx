
import React from 'react';
import { Transaction, User, Employee, MealType } from '../types';
import { 
  History, 
  CreditCard, 
  User as UserIcon, 
  ArrowRight, 
  CheckCircle2, 
  AlertCircle,
  Utensils
} from 'lucide-react';

interface Props {
  currentUser: User;
  transactions: Transaction[];
  employees: Employee[];
}

const MyRecords: React.FC<Props> = ({ currentUser, transactions, employees }) => {
  const employeeDetails = employees.find(e => e.id === currentUser.employeeId);
  const myTransactions = transactions.filter(t => t.employeeId === currentUser.employeeId);

  if (!currentUser.employeeId || !employeeDetails) {
    return (
      <div className="flex flex-col items-center justify-center h-[60vh] space-y-4 text-center">
        <AlertCircle size={48} className="text-amber-500" />
        <h2 className="text-2xl font-black text-gray-900">No Linked Profile</h2>
        <p className="text-gray-500 max-w-sm">Your login is not currently linked to a physical employee record. Please contact HR to link your Employee ID.</p>
      </div>
    );
  }

  const totalDeductions = myTransactions
    .filter(t => t.isPaid)
    .reduce((sum, t) => sum + t.amount, 0);

  return (
    <div className="space-y-8 animate-in fade-in duration-700">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <h2 className="text-3xl font-black text-gray-900 tracking-tight">Welcome, {employeeDetails.name}</h2>
          <p className="text-gray-500 font-medium mt-1">Personal meal records and canteen account overview.</p>
        </div>
        <div className="flex gap-4">
          <div className="bg-white px-6 py-4 rounded-2xl border border-gray-100 shadow-sm flex items-center gap-4">
            <div className="p-2 bg-indigo-50 rounded-xl text-indigo-600">
              <CreditCard size={18} />
            </div>
            <div>
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest leading-none mb-1">Monthly Cost</p>
              <p className="text-xl font-black text-slate-900 leading-none">₹{totalDeductions}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Profile Card */}
        <div className="bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-sm h-fit space-y-8">
          <div className="flex flex-col items-center text-center">
            <div className="w-24 h-24 rounded-3xl bg-indigo-600 text-white flex items-center justify-center shadow-xl shadow-indigo-100 mb-6">
              <UserIcon size={40} />
            </div>
            <h3 className="text-xl font-black text-gray-900">{employeeDetails.name}</h3>
            <p className="text-xs font-bold text-indigo-400 uppercase tracking-widest mt-1">ID: {employeeDetails.id}</p>
          </div>

          <div className="space-y-4">
            <div className="flex justify-between items-center text-sm p-4 bg-slate-50 rounded-2xl">
              <span className="text-gray-500 font-bold uppercase text-[10px] tracking-widest">Department</span>
              <span className="text-gray-900 font-black">{employeeDetails.department}</span>
            </div>
            <div className="flex justify-between items-center text-sm p-4 bg-slate-50 rounded-2xl">
              <span className="text-gray-500 font-bold uppercase text-[10px] tracking-widest">Shift Type</span>
              <span className="text-gray-900 font-black">{employeeDetails.shift}</span>
            </div>
            <div className="flex justify-between items-center text-sm p-4 bg-slate-50 rounded-2xl">
              <span className="text-gray-500 font-bold uppercase text-[10px] tracking-widest">Access Key</span>
              <span className="text-gray-900 font-black font-mono">{employeeDetails.cardId}</span>
            </div>
          </div>

          <div>
            <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-3 px-2">Meal Eligibility</p>
            <div className="flex flex-wrap gap-2">
              {Object.values(MealType).map(meal => {
                const isEligible = employeeDetails.eligibility.includes(meal);
                return (
                  <span key={meal} className={`px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest ${
                    isEligible ? 'bg-emerald-50 text-emerald-600 border border-emerald-100' : 'bg-gray-50 text-gray-300 line-through opacity-50'
                  }`}>
                    {meal}
                  </span>
                );
              })}
            </div>
          </div>
        </div>

        {/* Recent History Table */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white rounded-[2.5rem] border border-gray-100 shadow-sm overflow-hidden">
            <div className="px-8 py-6 border-b border-slate-50 flex items-center justify-between">
              <h3 className="font-black text-lg text-slate-900">Recent Transactions</h3>
              <div className="p-2 bg-indigo-50 text-indigo-600 rounded-xl">
                <History size={18} />
              </div>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead className="bg-slate-50/50 text-slate-400 text-[10px] font-black uppercase tracking-[0.2em]">
                  <tr>
                    <th className="px-8 py-4">Token</th>
                    <th className="px-8 py-4">Meal</th>
                    <th className="px-8 py-4">Timestamp</th>
                    <th className="px-8 py-4">Payment</th>
                    <th className="px-8 py-4 text-right">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                  {myTransactions.length > 0 ? myTransactions.map((tx) => (
                    <tr key={tx.id} className="hover:bg-slate-50/50 transition-colors">
                      <td className="px-8 py-6">
                        <span className="font-mono text-xs font-black text-slate-900">
                          {tx.id}
                        </span>
                      </td>
                      <td className="px-8 py-6">
                        <div className="flex items-center gap-2">
                          <Utensils size={14} className="text-indigo-400" />
                          <span className="text-sm font-bold text-slate-900">{tx.mealType}</span>
                        </div>
                      </td>
                      <td className="px-8 py-6">
                        <div className="text-xs">
                          <p className="text-slate-900 font-bold">{new Date(tx.timestamp).toLocaleDateString()}</p>
                          <p className="text-slate-400 font-medium">{new Date(tx.timestamp).toLocaleTimeString()}</p>
                        </div>
                      </td>
                      <td className="px-8 py-6">
                        {tx.isPaid ? (
                          <span className="text-xs font-black text-amber-600">₹{tx.amount}</span>
                        ) : (
                          <span className="text-[10px] font-black text-emerald-500 uppercase">Paid</span>
                        )}
                      </td>
                      <td className="px-8 py-6 text-right">
                        <span className="inline-flex items-center gap-1.5 text-[10px] font-black text-emerald-500 uppercase">
                          <CheckCircle2 size={12} /> Approved
                        </span>
                      </td>
                    </tr>
                  )) : (
                    <tr>
                      <td colSpan={5} className="px-8 py-20 text-center">
                        <div className="flex flex-col items-center gap-4 opacity-20">
                          <History size={48} />
                          <p className="font-black text-slate-900 uppercase tracking-widest text-xs">No records found</p>
                        </div>
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MyRecords;
