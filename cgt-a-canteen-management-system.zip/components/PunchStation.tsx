import React, { useState, useEffect, useRef, useMemo } from 'react';
import { Employee, MealConfig, Transaction, MealType, EmployeeStatus, AppSettings } from '../types';
import { 
  X, 
  Shield,
  Lock as LockIcon,
  RefreshCw,
  Ticket,
  ArrowRight,
  Check,
  Fingerprint,
  History,
  ShieldAlert,
  Timer,
  LayoutPanelLeft,
  Users,
  Sun,
  Zap,
  Utensils,
  Printer,
  Monitor
} from 'lucide-react';

interface Props {
  employees: Employee[];
  meals: MealConfig[];
  onPunch: (tx: Transaction) => void;
  transactions: Transaction[];
  settings: AppSettings;
  onClose: () => void;
}

const PunchStation: React.FC<Props> = ({ employees, meals, onPunch, transactions, settings, onClose }) => {
  const [currentMeal, setCurrentMeal] = useState<MealConfig | null>(null);
  const [status, setStatus] = useState<'idle' | 'processing' | 'success' | 'error' | 'syncing'>('idle');
  const [lastTx, setLastTx] = useState<Transaction | null>(null);
  const [errorMsg, setErrorMsg] = useState('');
  const [inputVal, setInputVal] = useState('');
  
  const [isAutoResetEnabled, setIsAutoResetEnabled] = useState(!settings.manualPunchReset);
  const [returnProgress, setReturnProgress] = useState(100);

  const inputRef = useRef<HTMLInputElement>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const wakeLockRef = useRef<any>(null);

  // Manage screen wake lock based on user preference
  useEffect(() => {
    const requestWakeLock = async () => {
      if (settings.keepScreenAwake && 'wakeLock' in navigator) {
        try {
          wakeLockRef.current = await (navigator as any).wakeLock.request('screen');
        } catch (err) {
          console.debug('Wake lock request denied or not supported');
        }
      }
    };
    requestWakeLock();
    return () => {
      if (wakeLockRef.current) {
        wakeLockRef.current.release();
        wakeLockRef.current = null;
      }
    };
  }, [settings.keepScreenAwake]);

  const todayTransactions = useMemo(() => {
    const now = new Date();
    return transactions.filter(t => {
      const d = new Date(t.timestamp);
      return d.getDate() === now.getDate() && d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
    }).sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }, [transactions]);

  const sessionStats = useMemo(() => {
    if (!currentMeal) return { current: 0, total: todayTransactions.length };
    const currentCount = todayTransactions.filter(t => t.mealType === currentMeal.id).length;
    return { current: currentCount, total: todayTransactions.length };
  }, [todayTransactions, currentMeal]);

  const handleReset = () => {
    setStatus('idle');
    setLastTx(null);
    setInputVal('');
    setReturnProgress(100);
    setTimeout(() => {
      if (inputRef.current) {
        inputRef.current.value = '';
        inputRef.current.focus();
      }
    }, 10);
  };

  useEffect(() => {
    let progressInterval: any;

    if ((status === 'success' || status === 'error') && isAutoResetEnabled) {
      const duration = (settings.punchScreenTimeout || 3) * 1000;
      const step = 30; 
      let elapsed = 0;

      progressInterval = setInterval(() => {
        elapsed += step;
        const newProgress = Math.max(0, 100 - (elapsed / duration) * 100);
        setReturnProgress(newProgress);
        
        if (newProgress <= 0) {
          clearInterval(progressInterval);
          handleReset();
        }
      }, step);

      if (status === 'success' && settings.enablePrinting) {
        try { window.print(); } catch (e) {}
      }
    }

    return () => {
      if (progressInterval) clearInterval(progressInterval);
    };
  }, [status, isAutoResetEnabled, settings.punchScreenTimeout, settings.enablePrinting]);

  const playFeedbackSound = (type: 'success' | 'error') => {
    if (!settings.enableSoundEffects) return;
    try {
      if (!audioContextRef.current) audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      const ctx = audioContextRef.current;
      if (ctx.state === 'suspended') ctx.resume();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      gain.gain.setValueAtTime(settings.terminalVolume / 100, ctx.currentTime);
      if (type === 'success') {
        osc.frequency.setValueAtTime(880, ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(1320, ctx.currentTime + 0.1);
      } else {
        osc.type = 'square';
        osc.frequency.setValueAtTime(220, ctx.currentTime);
      }
      osc.start(); osc.stop(ctx.currentTime + 0.4);
    } catch (e) {}
  };

  useEffect(() => {
    const checkMeal = () => {
      const now = new Date();
      const currentMinutes = now.getHours() * 60 + now.getMinutes();
      let active: MealConfig | null = null;
      const sorted = [...meals].filter(m => m.isActive).sort((a, b) => {
        const [ah, am] = a.startTime.split(':').map(Number);
        const [bh, bm] = b.startTime.split(':').map(Number);
        return (ah * 60 + am) - (bh * 60 + bm);
      });
      for (const meal of sorted) {
        const [startH, startM] = meal.startTime.split(':').map(Number);
        const [endH, endM] = meal.endTime.split(':').map(Number);
        const startT = startH * 60 + startM;
        const endT = endH * 60 + endM;
        const startWithGrace = (startT - meal.gracePeriod + 1440) % 1440;
        const endWithGrace = (endT + meal.gracePeriod) % 1440;
        let isNow = startWithGrace <= endWithGrace ? currentMinutes >= startWithGrace && currentMinutes <= endWithGrace : currentMinutes >= startWithGrace || currentMinutes <= endWithGrace;
        if (isNow) { active = meal; break; }
      }
      setCurrentMeal(active);
    };
    checkMeal();
    const t = setInterval(checkMeal, 5000);
    return () => clearInterval(t);
  }, [meals]);

  const handlePunch = (identityId: string) => {
    const id = identityId.trim().toUpperCase();
    if (!id) return;
    setStatus('processing');
    
    setTimeout(() => {
      const emp = employees.find(e => e.cardId === id || e.id === id);
      if (!emp) { triggerError("IDENTITY NOT RECOGNIZED"); return; }
      if (emp.status === EmployeeStatus.BLOCKED) { triggerError("ACCESS DENIED: ACCOUNT LOCKED"); return; }
      if (!currentMeal) { triggerError("STATION OFFLINE: CANTEEN CLOSED"); return; }
      if (!emp.eligibility.includes(currentMeal.id)) { triggerError(`NOT ELIGIBLE FOR ${currentMeal.name.toUpperCase()}`); return; }
      
      const todayStr = new Date().toISOString().split('T')[0];
      if (transactions.some(t => new Date(t.timestamp).toISOString().split('T')[0] === todayStr && t.employeeId === emp.id && t.mealType === currentMeal.id)) {
        triggerError("REDUNDANT ENTRY LOGGED TODAY"); return;
      }

      const newTx: Transaction = {
        id: 'TKN-' + Math.floor(1000 + Math.random() * 9000).toString(),
        employeeId: emp.id,
        employeeName: emp.name,
        mealType: currentMeal.id,
        timestamp: new Date().toISOString(),
        isPaid: true, 
        amount: currentMeal.price,
        status: 'SUCCESS'
      };
      
      onPunch(newTx);
      playFeedbackSound('success');
      setLastTx(newTx);
      setStatus('success');
      setInputVal('');
    }, 400);
  };

  const triggerError = (msg: string) => {
    playFeedbackSound('error');
    setErrorMsg(msg);
    setStatus('error');
    setInputVal('');
  };

  useEffect(() => {
    const focusTimer = setInterval(() => { 
      if (status === 'idle' && document.activeElement !== inputRef.current) {
        inputRef.current?.focus();
      }
    }, 300);
    return () => clearInterval(focusTimer);
  }, [status]);

  return (
    <div className="fixed inset-0 flex flex-col h-screen w-screen bg-[#03060d] text-white font-sans overflow-hidden select-none z-[100]">
      <div className="absolute inset-0 z-0 pointer-events-none no-print">
        <div className={`absolute inset-0 transition-all duration-1000 ${status === 'error' ? 'bg-rose-950/40' : status === 'success' ? 'bg-emerald-950/20' : 'bg-[#0a2e24]'}`}></div>
        <div className="absolute inset-0 bg-gradient-to-tr from-emerald-950/40 via-[#0a1612] to-[#03060d]"></div>
      </div>

      <div className="relative z-10 flex flex-col w-full h-full p-4 md:p-8 space-y-6">
        <header className="flex items-center justify-between px-6 py-4 md:px-8 md:py-5 bg-white/[0.03] backdrop-blur-3xl border border-white/10 rounded-[2rem] md:rounded-[2.5rem] shadow-2xl shrink-0 no-print">
          <div className="flex items-center gap-4 md:gap-6">
            <div className="p-2.5 md:p-3.5 bg-emerald-600 rounded-xl md:rounded-2xl shadow-xl shadow-emerald-500/20"><Shield size={20} /></div>
            <div>
              <h1 className="text-sm md:text-xl font-black tracking-tighter uppercase leading-none">{settings.appName}</h1>
              <div className="flex flex-wrap items-center gap-2 md:gap-4 mt-2">
                <div className={`flex items-center gap-2 px-2 py-0.5 rounded-full text-[7px] md:text-[8px] font-black uppercase border transition-all ${isAutoResetEnabled ? 'bg-emerald-500/20 text-emerald-400 border-emerald-400/30' : 'bg-white/5 text-slate-400 border-white/10'}`}>
                  <Zap size={10} className={isAutoResetEnabled ? 'animate-pulse' : ''} />
                  Auto-Return: {isAutoResetEnabled ? 'On' : 'Off'}
                </div>
                {settings.enablePrinting && (
                  <div className="flex items-center gap-2 px-2 py-0.5 rounded-full text-[7px] md:text-[8px] font-black uppercase border bg-indigo-500/20 text-indigo-400 border-indigo-500/30">
                    <Printer size={10} />
                    Auto-Print: On
                  </div>
                )}
                {settings.keepScreenAwake && (
                  <div className="flex items-center gap-2 px-2 py-0.5 rounded-full text-[7px] md:text-[8px] font-black uppercase border bg-amber-500/20 text-amber-400 border-amber-500/30">
                    <Monitor size={10} />
                    Always On
                  </div>
                )}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-4 md:gap-10">
            <div className="text-right hidden sm:block border-r border-white/10 pr-6 md:pr-10">
              <p className="text-2xl md:text-3xl font-black font-mono tracking-tighter text-white leading-none">{new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</p>
              <p className="text-emerald-400 font-black uppercase text-[8px] md:text-[9px] tracking-widest mt-1">{new Date().toLocaleDateString(undefined, { weekday: 'long', day: 'numeric', month: 'short' })}</p>
            </div>
            <button onClick={onClose} className="p-3 md:p-4 bg-white/5 hover:bg-rose-500/20 border border-white/10 rounded-xl md:rounded-2xl transition-all"><X size={20} /></button>
          </div>
        </header>

        <main className="flex-1 flex flex-col items-center justify-center relative w-full overflow-hidden">
          <div className="w-full h-full flex flex-col items-center justify-center bg-white/[0.01] border border-white/[0.05] rounded-[2rem] md:rounded-[4rem] relative overflow-hidden p-4 md:p-8 animate-terminal-entry">
            
            {status === 'idle' && (
              !currentMeal ? (
                <div className="text-center space-y-12 animate-in zoom-in-95 duration-700 no-print">
                   <div className="relative inline-block">
                      <div className="absolute -inset-16 bg-rose-500/10 blur-[100px] rounded-full"></div>
                      <div className="relative w-24 h-24 md:w-32 md:h-32 bg-slate-900/80 border border-white/10 rounded-[2rem] md:rounded-[2.5rem] flex items-center justify-center shadow-inner"><LockIcon className="w-12 h-12 md:w-16 md:h-16 text-slate-700" /></div>
                   </div>
                   <h2 className="text-4xl md:text-6xl font-black uppercase tracking-tighter text-white/80 italic leading-none">CANTEEN CLOSED</h2>
                   <p className="text-slate-500 font-black uppercase tracking-[0.5em] text-[10px] md:text-xs">Uplink Stable • Waiting for active meal session</p>
                </div>
              ) : (
                <div className="w-full flex flex-col items-center justify-between h-full py-6 md:py-12 animate-in fade-in duration-700 no-print">
                  <div className="w-full flex flex-col md:flex-row justify-between items-center px-4 md:px-12 gap-6">
                    <div className="bg-white/[0.03] p-4 md:p-8 rounded-[1.5rem] md:rounded-[3rem] border border-white/10 flex items-center gap-4 md:gap-8 shadow-inner">
                       <div className="w-12 h-12 md:w-24 md:h-24 bg-white/5 rounded-[1rem] md:rounded-[2rem] flex items-center justify-center border border-white/5">
                          {currentMeal.id === MealType.BREAKFAST ? <Sun size={32} className="text-amber-400" /> : <Utensils size={32} className="text-indigo-400" />}
                       </div>
                       <div className="text-left">
                          <p className="text-[8px] md:text-xs font-black text-white/30 uppercase tracking-[0.3em] mb-1 leading-none">Scanning Port Active</p>
                          <h2 className="text-2xl md:text-5xl font-black uppercase tracking-tighter italic leading-none">{currentMeal.name}</h2>
                       </div>
                    </div>
                    <div className="text-center md:text-right flex flex-col items-center md:items-end">
                       <p className="text-[8px] font-black text-slate-500 uppercase tracking-widest mb-1">Session Window</p>
                       <div className="flex items-center gap-4 text-xl md:text-4xl font-mono font-black text-white/60 leading-none">
                         {currentMeal.startTime} — {currentMeal.endTime}
                       </div>
                    </div>
                  </div>

                  <div className="w-full max-w-[95%] md:max-w-4xl relative">
                    <form onSubmit={(e) => { e.preventDefault(); handlePunch(inputVal); }} className="group">
                      <input 
                        ref={inputRef} 
                        autoFocus 
                        type="text" 
                        autoComplete="off" 
                        value={inputVal} 
                        onChange={(e) => setInputVal(e.target.value)} 
                        placeholder="SCAN IDENTITY"
                        className="relative w-full bg-white/[0.01] border border-white/10 rounded-[1.5rem] md:rounded-[4rem] py-10 md:py-28 text-3xl md:text-8xl font-black text-center tracking-[0.2em] md:tracking-[0.5em] placeholder:text-white/[0.03] outline-none focus:border-white/20 focus:ring-[20px] md:focus:ring-[60px] focus:ring-white/[0.005] transition-all text-white uppercase shadow-inner"
                      />
                    </form>
                    <div className="mt-6 md:mt-16 flex items-center justify-center gap-4 md:gap-5 opacity-20 group-focus-within:opacity-60 transition-opacity">
                      {/* Fixed: Replaced invalid md:size prop with Tailwind classes */}
                      <Fingerprint className="w-6 h-6 md:w-8 md:h-8" />
                      <p className="text-[8px] md:text-sm font-black uppercase tracking-[0.8em]">Secure Identity Uplink</p>
                    </div>
                  </div>

                  <div className="w-full flex items-center justify-center px-12">
                     <div className="bg-white/5 px-6 py-2 rounded-full border border-white/10 shadow-xl flex items-center gap-3">
                        <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
                        <p className="text-[8px] md:text-[9px] font-black uppercase tracking-widest text-white/50 italic">NODE_SYNC_STATUS: <span className="text-emerald-400">STABLE</span></p>
                     </div>
                  </div>
                </div>
              )
            )}

            {status === 'processing' && (
              <div className="absolute inset-0 z-[100] bg-[#03060d]/80 backdrop-blur-xl flex flex-col items-center justify-center gap-8 md:gap-12 animate-fade-in no-print">
                <div className="relative w-32 h-32 md:w-48 md:h-48">
                  <div className="absolute inset-0 border-[8px] md:border-[16px] border-white/5 rounded-full"></div>
                  <div className="absolute inset-0 border-[8px] md:border-[16px] border-emerald-600 border-t-transparent rounded-full animate-spin"></div>
                  <div className="absolute inset-0 flex items-center justify-center"><RefreshCw className="w-12 h-12 md:w-16 md:h-16 text-emerald-400 animate-pulse" /></div>
                </div>
                <h3 className="text-xl md:text-3xl font-black uppercase tracking-[1.2em] animate-pulse italic">VERIFYING</h3>
              </div>
            )}

            {/* Success Token Overlay - Fixed Alignment and Origin Center */}
            {status === 'success' && lastTx && (
              <div className="absolute inset-0 z-[110] bg-[#03060d]/90 backdrop-blur-2xl flex items-center justify-center p-4 animate-success-entry print:bg-white print:p-0">
                <div className="w-full flex flex-col items-center justify-center origin-center scale-[0.5] transition-transform duration-500 print:scale-100">
                  <div className="mb-12 relative animate-in slide-in-from-top-4 duration-500">
                    <div className="absolute -inset-8 bg-emerald-500/30 rounded-full blur-3xl"></div>
                    <div className="relative px-12 py-5 bg-gradient-to-r from-emerald-500 to-emerald-600 border border-white/20 rounded-full flex items-center gap-4 shadow-[0_0_80px_rgba(16,185,129,0.3)]">
                       <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center text-white">
                         <Check size={24} strokeWidth={4} />
                       </div>
                       <span className="text-4xl font-black uppercase tracking-[0.2em] text-white">ACCESS GRANTED</span>
                    </div>
                  </div>

                  <div className="w-full max-w-2xl rounded-[4rem] overflow-hidden border-[4px] border-emerald-400/30 flex flex-col relative bg-white/5 backdrop-blur-3xl animate-in zoom-in-95 duration-700 delay-100 shadow-[0_40px_100px_rgba(0,0,0,0.8)]">
                    <div className="bg-[#10b981] p-10 flex items-center gap-8 relative overflow-hidden">
                       <div className="w-20 h-20 bg-white/20 backdrop-blur-md rounded-[1.8rem] border border-white/30 flex items-center justify-center">
                          <Ticket size={48} className="text-white" />
                       </div>
                       <h3 className="text-6xl font-black tracking-widest text-white uppercase italic leading-none">MEAL VOUCHER</h3>
                       <div className="absolute -left-8 bottom-[-32px] w-16 h-16 bg-[#03060d] rounded-full z-20 shadow-inner"></div>
                       <div className="absolute -right-8 bottom-[-32px] w-16 h-16 bg-[#03060d] rounded-full z-20 shadow-inner"></div>
                    </div>

                    <div className="bg-[#e0fef2] p-16 relative flex flex-col">
                       <div className="absolute top-0 right-14 -translate-y-1/2 px-10 py-4 bg-[#10b981] text-white rounded-full font-black uppercase tracking-widest text-xl shadow-xl flex items-center gap-3 border-[6px] border-[#e0fef2]">
                          <Check size={24} strokeWidth={4} /> PAID
                       </div>

                       <div className="w-full space-y-10 text-[#0a4d3a]">
                          <div className="flex items-baseline gap-6 border-b border-[#0a4d3a]/10 pb-8">
                             <span className="text-4xl font-bold opacity-60 uppercase">Meal:</span>
                             <span className="text-7xl font-black uppercase tracking-tighter italic">{lastTx.mealType}</span>
                          </div>
                          
                          <div className="flex items-center gap-12">
                             <div className="flex flex-col gap-1">
                                <span className="text-2xl font-bold opacity-60 uppercase tracking-widest">Date</span>
                                <span className="text-3xl font-black whitespace-nowrap tracking-tight">{new Date(lastTx.timestamp).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })}</span>
                             </div>
                             <div className="h-16 w-px bg-[#0a4d3a]/20"></div>
                             <div className="flex flex-col gap-1">
                                <span className="text-2xl font-bold opacity-60 uppercase tracking-widest">Timestamp</span>
                                <span className="text-3xl font-black whitespace-nowrap tracking-tight uppercase">{new Date(lastTx.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: true })}</span>
                             </div>
                          </div>

                          <div className="flex items-baseline gap-6 pt-6">
                             <span className="text-4xl font-bold opacity-60 uppercase">Token No:</span>
                             <span className="text-9xl font-black tracking-tighter text-[#10b981] drop-shadow-sm leading-none">{lastTx.id.split('-')[1]}</span>
                          </div>
                       </div>
                    </div>
                    
                    {isAutoResetEnabled && (
                      <div className="h-3 bg-[#e0fef2] w-full relative">
                         <div className="h-full bg-[#10b981] transition-all duration-75 ease-linear" style={{ width: `${returnProgress}%` }} />
                      </div>
                    )}
                  </div>

                  <div className="mt-16 w-full max-w-2xl space-y-8 animate-in slide-in-from-bottom-4 duration-500 delay-300">
                    <button onClick={handleReset} className="w-full py-10 bg-emerald-600 text-white rounded-[2.5rem] font-black uppercase tracking-[0.1em] text-3xl shadow-[0_40px_80px_-15px_rgba(16,185,129,0.5)] hover:bg-emerald-500 active:scale-95 transition-all flex items-center justify-center gap-6 group">
                      READY FOR NEXT SCAN
                      <ArrowRight size={32} className="group-hover:translate-x-2 transition-transform" />
                    </button>
                    <div className="flex items-center justify-center gap-4 text-slate-500">
                       <Timer size={20} className="text-emerald-500 animate-pulse" />
                       <p className="text-sm font-black uppercase tracking-[0.4em] italic opacity-60">STATION_AUTO_RESET: ACTIVE</p>
                    </div>
                  </div>
                </div>

                <div id="printable-token" className="hidden print:block print:w-[80mm] print:bg-white print:text-black print:p-8">
                  <div className="text-center border-b-4 border-black pb-4 mb-6">
                    <h2 className="text-3xl font-black uppercase tracking-widest leading-none">{settings.appName}</h2>
                    <p className="text-sm font-bold mt-2 italic">Authorized Service Receipt</p>
                  </div>
                  <div className="text-center py-8 border-b-2 border-dashed border-black">
                    <p className="text-[12px] font-black uppercase tracking-[0.3em] mb-1">TOKEN NUMBER</p>
                    <h1 className="text-8xl font-black leading-none">{lastTx.id.split('-')[1]}</h1>
                  </div>
                  <div className="space-y-4 py-8 text-left font-black">
                    <p>MEAL: {lastTx.mealType.toUpperCase()}</p>
                    <p>DATE: {new Date(lastTx.timestamp).toLocaleDateString()}</p>
                    <p>TIME: {new Date(lastTx.timestamp).toLocaleTimeString()}</p>
                  </div>
                  <div className="mt-8 pt-4 border-t-4 border-black text-center font-black uppercase">PAID - CGT CANTEEN</div>
                </div>
              </div>
            )}

            {/* Error Rejection Overlay - Fixed Alignment and Origin Center */}
            {status === 'error' && (
              <div className="absolute inset-0 z-[120] bg-[#03060d]/90 backdrop-blur-3xl flex items-center justify-center p-6 animate-pop-in no-print">
                <div className="w-full max-w-xl origin-center scale-[0.75] transition-transform duration-500">
                  <div className="bg-[#1a0a0d] border-[3px] border-[#4a1a21] rounded-[4rem] p-16 flex flex-col items-center text-center shadow-[0_0_150px_rgba(244,63,94,0.15)] animate-shake-heavy">
                    <div className="relative mb-12">
                      <div className="absolute -inset-10 bg-rose-600/10 blur-[60px] rounded-full animate-pulse"></div>
                      <div className="relative w-32 h-32 bg-[#e11d48] text-white rounded-[2.8rem] flex items-center justify-center shadow-[0_20px_60px_rgba(225,29,72,0.4)] border-[10px] border-white/10">
                        <ShieldAlert size={64} strokeWidth={2.5} />
                      </div>
                    </div>
                    <h2 className="text-8xl font-black uppercase tracking-tighter text-white italic mb-6 leading-none">REJECTED</h2>
                    <div className="px-10 py-3.5 bg-black/40 border border-rose-500/30 rounded-full mb-12">
                      <p className="text-rose-400 text-xs font-black uppercase tracking-[0.4em]">SECURITY ALERT LOGGED</p>
                    </div>
                    <p className="text-rose-100 text-4xl font-black uppercase italic leading-tight mb-16 px-6">
                      "{errorMsg}"
                    </p>
                    <div className="w-full space-y-8">
                      <button onClick={handleReset} className="w-full py-9 bg-white text-[#e11d48] text-3xl font-black uppercase rounded-full hover:scale-[1.02] active:scale-95 transition-all shadow-2xl shadow-rose-950 flex items-center justify-center gap-6 group">
                        DISMISS ERROR
                      </button>
                      <div className="h-2 bg-white/5 w-full rounded-full overflow-hidden">
                         <div className="h-full bg-rose-600 transition-all duration-75 ease-linear" style={{ width: `${returnProgress}%` }} />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </main>

        <footer className="h-20 px-6 md:px-12 flex items-center justify-between bg-white/[0.04] backdrop-blur-[100px] border border-white/10 rounded-[1.5rem] md:rounded-[2.5rem] shrink-0 no-print">
          <div className="flex items-center gap-6 md:gap-10">
            <div className="flex items-center gap-4 group">
              <div className="p-2.5 md:p-3 bg-white/5 rounded-lg md:rounded-xl border border-white/10 group-hover:bg-white/10 transition-colors">
                {/* Fixed: Replaced invalid md:size prop with Tailwind classes */}
                <LayoutPanelLeft className="w-4 h-4 md:w-[18px] md:h-[18px] text-indigo-400" />
              </div>
              <div>
                <p className="text-[7px] md:text-[9px] font-black text-slate-500 uppercase tracking-widest leading-none mb-1">Station Volume</p>
                <p className="text-xs md:text-sm font-black text-indigo-400 leading-none">SESSION: {sessionStats.current}</p>
              </div>
            </div>
            <div className="h-10 w-px bg-white/10 hidden sm:block"></div>
            <div className="hidden sm:flex items-center gap-4">
              <Users size={18} className="text-emerald-500" />
              <p className="text-sm font-black text-white/60 uppercase tracking-widest leading-none">
                Node Activity: <span className="text-white">{todayTransactions.length}</span>
              </p>
            </div>
          </div>
          <div className="flex items-center gap-3 md:gap-5 px-4 md:px-8 py-2 md:py-3 bg-white/5 rounded-xl md:rounded-2xl border border-white/10 shadow-xl">
             <div className="w-2 h-2 md:w-3 md:h-3 rounded-full bg-emerald-500 animate-pulse shadow-[0_0_15px_#10b981]"></div>
             <span className="text-[8px] md:text-[10px] font-black uppercase tracking-[0.4em] text-emerald-400 italic">SYSTEM_UPLINK: <span className="text-white">OPTIMIZED</span></span>
          </div>
        </footer>
      </div>

      <style>{`
        @media print {
          @page { margin: 0; size: auto; }
          body * { visibility: hidden; }
          .no-print { display: none !important; }
          #printable-token, #printable-token * { visibility: visible; }
          #printable-token { position: absolute; left: 0; top: 0; width: 100%; }
        }
        @keyframes terminal-entry { from { opacity: 0; transform: translateY(40px); } to { opacity: 1; transform: translateY(0); } }
        @keyframes success-entry { from { opacity: 0; background-color: rgba(16, 185, 129, 0); } to { opacity: 1; background-color: rgba(3, 6, 13, 0.9); } }
        @keyframes pop-in { from { opacity: 0; transform: scale(0.6); } to { opacity: 1; transform: scale(0.75); } }
        @keyframes shake-heavy { 0%, 100% { transform: translateX(0); } 10%, 30%, 50%, 70%, 90% { transform: translateX(-8px); } 20%, 40%, 60%, 80% { transform: translateX(8px); } }
        .animate-terminal-entry { animation: terminal-entry 1s cubic-bezier(0.23, 1, 0.32, 1); }
        .animate-success-entry { animation: success-entry 0.6s cubic-bezier(0.16, 1, 0.3, 1); }
        .animate-pop-in { animation: pop-in 0.4s cubic-bezier(0.34, 1.56, 0.64, 1); }
        .animate-shake-heavy { animation: shake-heavy 0.6s cubic-bezier(.36,.07,.19,.97) both; }
        .shadow-terminal { box-shadow: 0 80px 200px -40px rgba(0, 0, 0, 0.95); }
      `}</style>
    </div>
  );
};

export default PunchStation;