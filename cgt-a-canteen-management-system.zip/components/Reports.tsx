
import React, { useState, useEffect } from 'react';
import { Transaction, User, UserRole, AppSettings } from '../types';
import { 
  Download, 
  Search, 
  Calendar, 
  Filter, 
  CheckCircle2, 
  FileText,
  User as UserIcon,
  ArrowRight,
  Info,
  Lock,
  Mail,
  Clock,
  Settings2,
  Zap,
  RefreshCw,
  History as HistoryIcon,
  Send,
  PieChart,
  ShieldCheck,
  BellRing,
  FileSpreadsheet,
  MailCheck,
  CalendarCheck,
  ChevronRight,
  FileCode,
  FileStack,
  MailPlus,
  ArrowUpRight,
  ShieldAlert,
  Save,
  Activity
} from 'lucide-react';

interface Props {
  transactions: Transaction[];
  currentUser: User;
  settings: AppSettings;
  setSettings: (s: AppSettings) => void;
}

const Reports: React.FC<Props> = ({ transactions, currentUser, settings, setSettings }) => {
  const getStored = (key: string, defaultValue: any) => {
    const saved = localStorage.getItem(key);
    if (saved === null) return defaultValue;
    try {
      return JSON.parse(saved);
    } catch {
      return defaultValue;
    }
  };

  const [activeSubTab, setActiveSubTab] = useState<'HISTORY' | 'EMAIL_REPORTS' | 'AUTOMATION'>(() => getStored('cgt_reports_tab', 'HISTORY'));
  const [searchTerm, setSearchTerm] = useState(() => getStored('cgt_reports_search', ''));
  const [isSyncing, setIsSyncing] = useState(false);
  const [isSendingInstant, setIsSendingInstant] = useState(false);
  
  const [reportSubject, setReportSubject] = useState(() => getStored('cgt_reports_subject', `CGT Service Audit - ${new Date().toLocaleDateString()}`));
  const [instantEmail, setInstantEmail] = useState(() => getStored('cgt_reports_instant_email', settings.reportEmail || ''));
  const [fileFormat, setFileFormat] = useState<'CSV' | 'PDF' | 'JSON'>(() => getStored('cgt_reports_format', 'CSV'));
  const [selectedAttachments, setSelectedAttachments] = useState<string[]>(() => getStored('cgt_reports_attachments', ['LOGS']));
  
  const [lastSentAt, setLastSentAt] = useState<string>(() => {
    return localStorage.getItem('cgt_last_report_sent') || 'Never Dispatched';
  });

  const today = new Date().toISOString().split('T')[0];
  const firstDayOfMonth = new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().split('T')[0];
  
  const [startDate, setStartDate] = useState(() => getStored('cgt_reports_start_date', firstDayOfMonth));
  const [endDate, setEndDate] = useState(() => getStored('cgt_reports_end_date', today));

  useEffect(() => { localStorage.setItem('cgt_reports_tab', JSON.stringify(activeSubTab)); }, [activeSubTab]);
  useEffect(() => { localStorage.setItem('cgt_reports_search', JSON.stringify(searchTerm)); }, [searchTerm]);
  useEffect(() => { localStorage.setItem('cgt_reports_subject', JSON.stringify(reportSubject)); }, [reportSubject]);
  useEffect(() => { localStorage.setItem('cgt_reports_instant_email', JSON.stringify(instantEmail)); }, [instantEmail]);
  useEffect(() => { localStorage.setItem('cgt_reports_format', JSON.stringify(fileFormat)); }, [fileFormat]);
  useEffect(() => { localStorage.setItem('cgt_reports_attachments', JSON.stringify(selectedAttachments)); }, [selectedAttachments]);
  useEffect(() => { localStorage.setItem('cgt_reports_start_date', JSON.stringify(startDate)); }, [startDate]);
  useEffect(() => { localStorage.setItem('cgt_reports_end_date', JSON.stringify(endDate)); }, [endDate]);

  const canManageReports = currentUser.role === UserRole.IT_SUPER_USER || 
                           currentUser.role === UserRole.SUPER_ADMIN || 
                           currentUser.role === UserRole.HR_ADMIN;

  const filtered = transactions.filter(t => {
    const tDate = new Date(t.timestamp).toISOString().split('T')[0];
    const matchesSearch = t.employeeName.toLowerCase().includes(searchTerm.toLowerCase()) || 
                         t.employeeId.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         t.id.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesDate = tDate >= startDate && tDate <= endDate;
    
    return matchesSearch && matchesDate;
  });

  const getNextRunDate = () => {
    const now = new Date();
    if (settings.reportFrequency === 'Daily') {
      const tomorrow = new Date(now);
      tomorrow.setDate(now.getDate() + 1);
      tomorrow.setHours(6, 0, 0, 0);
      return tomorrow.toLocaleString();
    } else if (settings.reportFrequency === 'Weekly') {
      const nextMon = new Date(now);
      nextMon.setDate(now.getDate() + ((1 + 7 - now.getDay()) % 7 || 7));
      nextMon.setHours(6, 0, 0, 0);
      return nextMon.toLocaleString();
    } else {
      const nextMonth = new Date(now.getFullYear(), now.getMonth() + 1, 1, 6, 0, 0, 0);
      return nextMonth.toLocaleString();
    }
  };

  const handleUpdateEmailConfig = (e: React.FormEvent) => {
    e.preventDefault();
    if (!canManageReports) return;
    setIsSyncing(true);
    setTimeout(() => {
      setIsSyncing(false);
      alert(`Automated reporting protocol updated for ${settings.reportEmail}.`);
    }, 800);
  };

  const triggerTestSync = () => {
    if (!settings.reportEmail) {
      alert("Configure recipient email first.");
      return;
    }
    setIsSyncing(true);
    setTimeout(() => {
      const timestamp = new Date().toLocaleString();
      setLastSentAt(timestamp);
      localStorage.setItem('cgt_last_report_sent', timestamp);
      setIsSyncing(false);
      alert(`Manual Sync Successful: Audit package dispatched to ${settings.reportEmail}.`);
    }, 2000);
  };

  const handleInstantSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!instantEmail || selectedAttachments.length === 0) return;
    setIsSendingInstant(true);
    
    setTimeout(() => {
      setIsSendingInstant(false);
      alert(`Report Package Successfully Dispatched.`);
    }, 2000);
  };

  const toggleAttachment = (id: string) => {
    if (selectedAttachments.includes(id)) {
      setSelectedAttachments(selectedAttachments.filter(a => a !== id));
    } else {
      setSelectedAttachments([...selectedAttachments, id]);
    }
  };

  const exportToCSV = () => {
    if (!canManageReports) {
      alert("Unauthorized: Export privileges restricted.");
      return;
    }
    if (filtered.length === 0) {
      alert("No data available to export.");
      return;
    }

    const headers = ['Token ID', 'Employee Name', 'Employee ID', 'Meal Type', 'Date', 'Time', 'Service Type', 'Status'];
    const rows = filtered.map(t => [
      t.id,
      t.employeeName,
      t.employeeId,
      t.mealType,
      new Date(t.timestamp).toLocaleDateString(),
      new Date(t.timestamp).toLocaleTimeString(),
      'FREE_SERVICE',
      'Verified'
    ]);

    const csvContent = [
      headers.join(','),
      ...rows.map(row => row.join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `Service_Audit_${startDate}_to_${endDate}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500 pb-20">
      <div className="flex flex-col gap-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <h2 className="text-3xl font-black text-gray-900 tracking-tight">Audit Logs & Intelligence</h2>
            <p className="text-gray-500 font-medium">Free service consumption tracking and reporting.</p>
          </div>
          
          <div className="flex bg-slate-100 p-1.5 rounded-2xl shadow-inner">
            <button 
              onClick={() => setActiveSubTab('HISTORY')}
              className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${activeSubTab === 'HISTORY' ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-500 hover:text-slate-900'}`}
            >
              <HistoryIcon size={14} />
              Ledger History
            </button>
            <button 
              onClick={() => setActiveSubTab('EMAIL_REPORTS')}
              className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${activeSubTab === 'EMAIL_REPORTS' ? 'bg-white text-emerald-600 shadow-sm' : 'text-slate-500 hover:text-slate-900'}`}
            >
              <MailPlus size={14} />
              Email Reports
            </button>
            <button 
              onClick={() => setActiveSubTab('AUTOMATION')}
              className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${activeSubTab === 'AUTOMATION' ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-500 hover:text-slate-900'}`}
            >
              <CalendarCheck size={14} />
              Automation
            </button>
          </div>
        </div>
      </div>

      {activeSubTab === 'HISTORY' && (
        <div className="space-y-6 animate-in slide-in-from-bottom-4 duration-500">
          <div className="flex flex-col xl:flex-row gap-6 justify-between items-start xl:items-center">
            <div className="flex flex-wrap items-center gap-4 w-full xl:w-auto">
              <div className="relative flex-1 min-w-[300px]">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
                <input 
                  type="text" 
                  placeholder="Filter logs by name, ID, or token..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-12 pr-4 py-4 bg-white border border-gray-200 rounded-2xl text-sm font-bold focus:ring-4 focus:ring-indigo-500/10 outline-none transition-all shadow-sm"
                />
              </div>
              
              <div className="flex items-center gap-3 bg-white border border-gray-200 p-2.5 rounded-2xl shadow-sm">
                <input 
                  type="date" 
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  className="text-xs font-black text-gray-700 outline-none cursor-pointer bg-transparent"
                />
                <ArrowRight size={14} className="text-gray-300" />
                <input 
                  type="date" 
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                  className="text-xs font-black text-gray-700 outline-none cursor-pointer bg-transparent"
                />
              </div>
            </div>

            <div className="flex gap-3 w-full xl:w-auto">
              {canManageReports ? (
                <>
                  <button 
                    onClick={exportToCSV}
                    className="flex-1 xl:flex-none flex items-center justify-center gap-3 bg-indigo-600 text-white px-8 py-4 rounded-2xl hover:bg-indigo-700 transition-all font-black uppercase tracking-widest text-xs shadow-xl shadow-indigo-100"
                  >
                    <Download size={18} />
                    Export CSV
                  </button>
                </>
              ) : (
                <div className="flex items-center gap-2 px-6 py-4 bg-amber-50 text-amber-600 text-[10px] font-black uppercase tracking-widest rounded-2xl border border-amber-100 shadow-sm">
                  <Lock size={14} /> Restricted View
                </div>
              )}
            </div>
          </div>

          <div className="p-5 bg-indigo-50/50 border border-indigo-100/50 rounded-3xl flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-indigo-600 text-white rounded-xl flex items-center justify-center shadow-lg">
                <PieChart size={18} />
              </div>
              <p className="text-[11px] font-black text-indigo-900 uppercase tracking-widest">
                Service Volume: {filtered.length} matching units
              </p>
            </div>
            <div className="flex gap-8">
              <div className="text-right">
                <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Service Type</p>
                <p className="text-sm font-black text-emerald-600">COMPLIMENTARY</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-[3rem] border border-gray-200 overflow-hidden shadow-sm">
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead className="bg-gray-50 text-gray-400 text-[10px] font-black uppercase tracking-[0.2em]">
                  <tr>
                    <th className="px-10 py-6">Transaction Ref</th>
                    <th className="px-10 py-6">Identity</th>
                    <th className="px-10 py-6">Meal</th>
                    <th className="px-10 py-6">Timestamp</th>
                    <th className="px-10 py-6 text-right">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {filtered.length > 0 ? filtered.map((tx) => (
                    <tr key={tx.id} className="hover:bg-slate-50 transition-colors group">
                      <td className="px-10 py-6">
                        <span className="font-mono text-xs font-black text-slate-900">
                          {tx.id}
                        </span>
                      </td>
                      <td className="px-10 py-6">
                        <div className="flex items-center gap-4">
                          <div className="w-10 h-10 bg-indigo-50 text-indigo-600 rounded-xl flex items-center justify-center font-black">
                            {tx.employeeName.charAt(0)}
                          </div>
                          <div>
                            <p className="text-sm font-black text-gray-900 leading-none mb-1">{tx.employeeName}</p>
                            <p className="text-[10px] text-gray-400 uppercase font-black tracking-widest">{tx.employeeId}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-10 py-6">
                        <span className="px-3 py-1.5 bg-white border border-gray-200 text-[10px] font-black text-slate-600 rounded-xl uppercase tracking-widest shadow-sm">
                          {tx.mealType}
                        </span>
                      </td>
                      <td className="px-10 py-6">
                        <div className="text-xs font-bold">
                          <p className="text-slate-900">{new Date(tx.timestamp).toLocaleDateString()}</p>
                          <p className="text-slate-400 text-[10px]">{new Date(tx.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</p>
                        </div>
                      </td>
                      <td className="px-10 py-6 text-right">
                        <div className="flex items-center justify-end gap-2 text-emerald-500">
                          <CheckCircle2 size={16} />
                          <span className="text-[10px] font-black uppercase tracking-widest">Authorized</span>
                        </div>
                      </td>
                    </tr>
                  )) : (
                    <tr>
                      <td colSpan={5} className="px-10 py-24 text-center bg-gray-50/20">
                        <div className="flex flex-col items-center max-w-xs mx-auto opacity-40">
                           <HistoryIcon size={48} className="text-gray-300 mb-4" />
                           <p className="font-black text-gray-900 uppercase tracking-widest text-sm">No matched logs</p>
                        </div>
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {activeSubTab === 'EMAIL_REPORTS' && (
        <div className="max-w-6xl mx-auto animate-in slide-in-from-right-4 duration-500">
          <div className="bg-white rounded-[3rem] border border-gray-200 shadow-xl overflow-hidden flex flex-col xl:flex-row min-h-[600px]">
            <div className="flex-1 p-10 lg:p-14 space-y-10 border-b xl:border-b-0 xl:border-r border-gray-100">
              <div className="flex items-center gap-6">
                <div className="w-16 h-16 bg-emerald-600 text-white rounded-3xl flex items-center justify-center shadow-xl shadow-emerald-100">
                  <MailPlus size={32} />
                </div>
                <div>
                  <h3 className="text-2xl font-black text-gray-900 tracking-tight">On-Demand Dispatch</h3>
                  <p className="text-sm font-bold text-emerald-600/70 uppercase tracking-widest mt-1">Manual Service Audit Distribution</p>
                </div>
              </div>

              <form onSubmit={handleInstantSend} className="space-y-8">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="space-y-3">
                    <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.4em] px-2">Recipient Email</label>
                    <div className="relative group">
                      <Mail className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-emerald-500 transition-all" size={20} />
                      <input 
                        type="email" 
                        required
                        value={instantEmail}
                        onChange={(e) => setInstantEmail(e.target.value)}
                        placeholder="finance@cgt.com"
                        className="w-full pl-16 pr-6 py-5 bg-slate-50 border border-slate-200 rounded-2xl text-sm font-bold outline-none focus:ring-4 focus:ring-emerald-500/10 transition-all"
                      />
                    </div>
                  </div>
                  <div className="space-y-3">
                    <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.4em] px-2">File Format</label>
                    <div className="relative">
                      <FileCode className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                      <select 
                        value={fileFormat}
                        onChange={(e) => setFileFormat(e.target.value as any)}
                        className="w-full pl-16 pr-6 py-5 bg-slate-50 border border-slate-200 rounded-2xl text-sm font-bold outline-none focus:ring-4 focus:ring-emerald-500/10 appearance-none cursor-pointer"
                      >
                        <option value="CSV">Comma Separated (CSV)</option>
                        <option value="PDF">Secure Document (PDF)</option>
                        <option value="JSON">Data Interchange (JSON)</option>
                      </select>
                    </div>
                  </div>
                </div>

                <div className="space-y-3">
                  <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.4em] px-2">Email Subject Line</label>
                  <div className="relative group">
                    <FileText className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-emerald-500 transition-all" size={20} />
                    <input 
                      type="text" 
                      required
                      value={reportSubject}
                      onChange={(e) => setReportSubject(e.target.value)}
                      className="w-full pl-16 pr-6 py-5 bg-slate-50 border border-slate-200 rounded-2xl text-sm font-bold outline-none focus:ring-4 focus:ring-emerald-500/10 transition-all"
                    />
                  </div>
                </div>

                <div className="space-y-4">
                  <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.4em] px-2">Select Audit Attachments</label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {[
                      { id: 'LOGS', label: 'Transaction Logs', icon: <FileSpreadsheet size={16} /> },
                      { id: 'SUMMARY', label: 'Volume Summary', icon: <PieChart size={16} /> },
                      { id: 'EMPLOYEE', label: 'Employee Matrix', icon: <UserIcon size={16} /> },
                      { id: 'ANALYTICS', label: 'Shift Analytics', icon: <Zap size={16} /> },
                    ].map((item) => (
                      <button
                        key={item.id}
                        type="button"
                        onClick={() => toggleAttachment(item.id)}
                        className={`flex items-center gap-3 p-4 rounded-2xl border transition-all text-left ${
                          selectedAttachments.includes(item.id)
                          ? 'bg-emerald-50 border-emerald-200 text-emerald-700 shadow-sm'
                          : 'bg-white border-slate-200 text-slate-400 hover:border-emerald-100 hover:bg-emerald-50/30'
                        }`}
                      >
                        <div className={`p-2 rounded-xl ${selectedAttachments.includes(item.id) ? 'bg-emerald-600 text-white' : 'bg-slate-50 text-slate-300'}`}>
                          {item.icon}
                        </div>
                        <span className="text-[10px] font-black uppercase tracking-widest">{item.label}</span>
                        {selectedAttachments.includes(item.id) && <CheckCircle2 size={14} className="ml-auto" />}
                      </button>
                    ))}
                  </div>
                </div>

                <button 
                  type="submit"
                  disabled={!canManageReports || isSendingInstant || selectedAttachments.length === 0}
                  className="w-full py-6 bg-emerald-600 text-white rounded-[2rem] font-black uppercase tracking-widest text-xs shadow-2xl shadow-emerald-100 hover:bg-emerald-700 disabled:opacity-50 transition-all flex items-center justify-center gap-4 group mt-4"
                >
                  {isSendingInstant ? <RefreshCw className="animate-spin" size={20} /> : <Send size={18} className="group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />}
                  {isSendingInstant ? 'Transmitting Data Clusters...' : 'Dispatch Audit Package'}
                </button>
              </form>
            </div>

            <div className="w-full xl:w-[400px] bg-slate-900 text-white p-10 lg:p-14 flex flex-col">
              <div className="flex items-center justify-between mb-10">
                <h4 className="text-[10px] font-black uppercase tracking-[0.4em] text-slate-500">Dispatch Preview</h4>
                <div className="flex gap-1.5">
                  <div className="w-2 h-2 rounded-full bg-slate-700"></div>
                  <div className="w-2 h-2 rounded-full bg-slate-700"></div>
                  <div className="w-2 h-2 rounded-full bg-emerald-500"></div>
                </div>
              </div>

              <div className="space-y-8 flex-1">
                <div className="space-y-4">
                  <p className="text-[9px] font-black text-slate-600 uppercase tracking-widest">Metadata</p>
                  <div className="space-y-3 bg-white/5 p-6 rounded-3xl border border-white/5 shadow-inner">
                    <div className="flex justify-between items-center text-xs">
                      <span className="text-slate-500 font-bold uppercase tracking-tighter">Recipient:</span>
                      <span className="text-emerald-400 font-black truncate max-w-[150px]">{instantEmail || 'Not defined'}</span>
                    </div>
                    <div className="flex justify-between items-center text-xs">
                      <span className="text-slate-500 font-bold uppercase tracking-tighter">Service:</span>
                      <span className="text-white font-black">Free Service Only</span>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <p className="text-[9px] font-black text-slate-600 uppercase tracking-widest">Package Contents</p>
                  <div className="space-y-2">
                    {selectedAttachments.length > 0 ? selectedAttachments.map(id => (
                      <div key={id} className="flex items-center gap-3 p-4 bg-white/5 rounded-2xl border border-white/5 group hover:border-emerald-500/30 transition-all">
                        <FileStack size={16} className="text-emerald-500" />
                        <span className="text-[10px] font-black uppercase tracking-widest">{id}_REPORT.{fileFormat.toLowerCase()}</span>
                        <ArrowUpRight size={12} className="ml-auto opacity-20" />
                      </div>
                    )) : (
                      <div className="py-10 text-center border-2 border-dashed border-white/5 rounded-3xl">
                        <p className="text-[9px] font-black text-slate-700 uppercase tracking-widest">No attachments selected</p>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {activeSubTab === 'AUTOMATION' && (
        <div className="max-w-5xl mx-auto animate-in slide-in-from-right-4 duration-500 pb-12">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 bg-white rounded-[3rem] border border-gray-200 shadow-xl overflow-hidden flex flex-col">
              <div className="p-10 border-b border-gray-100 bg-indigo-50/30">
                <div className="flex items-center gap-6">
                  <div className="w-16 h-16 bg-indigo-600 text-white rounded-3xl flex items-center justify-center shadow-xl shadow-indigo-100">
                    <Settings2 size={32} />
                  </div>
                  <div>
                    <h3 className="text-2xl font-black text-gray-900 tracking-tight">Audit Automation</h3>
                    <p className="text-sm font-bold text-indigo-600/70 uppercase tracking-widest mt-1">Deploy recursive service dispatches</p>
                  </div>
                </div>
              </div>

              <form onSubmit={handleUpdateEmailConfig} className="p-10 space-y-10 flex-1">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="space-y-3">
                    <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.4em] px-2">Primary Recipient</label>
                    <div className="relative group">
                      <Mail className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-indigo-600 transition-all" size={20} />
                      <input 
                        type="email" 
                        disabled={!canManageReports}
                        required
                        value={settings.reportEmail}
                        onChange={(e) => setSettings({...settings, reportEmail: e.target.value})}
                        placeholder="audit-auto@cgt.com"
                        className="w-full pl-16 pr-6 py-5 bg-slate-50 border border-slate-200 rounded-2xl text-sm font-bold outline-none focus:ring-4 focus:ring-indigo-500/10 transition-all disabled:opacity-50"
                      />
                    </div>
                  </div>

                  <div className="space-y-3">
                    <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.4em] px-2">Dispatch Cycle</label>
                    <div className="relative">
                      <Clock className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                      <select 
                        disabled={!canManageReports}
                        value={settings.reportFrequency}
                        onChange={(e) => setSettings({...settings, reportFrequency: e.target.value as any})}
                        className="w-full pl-16 pr-6 py-5 bg-slate-50 border border-slate-200 rounded-2xl font-black text-xs uppercase tracking-widest outline-none appearance-none cursor-pointer focus:ring-4 focus:ring-indigo-500/10"
                      >
                        <option value="Daily">Daily Volume Summary</option>
                        <option value="Weekly">Weekly Compilation</option>
                        <option value="Monthly">Monthly Ledger</option>
                      </select>
                    </div>
                  </div>
                </div>

                <div className="p-8 bg-slate-50 rounded-[2.5rem] border border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-6">
                  <div className="flex-1 space-y-2 text-center sm:text-left">
                    <h4 className="text-lg font-black text-slate-900 uppercase tracking-tight">Automation Status</h4>
                    <p className="text-[10px] font-bold text-slate-400 leading-relaxed uppercase">
                      Scheduled broadcasts focus on authorized unit volume under the free service model.
                    </p>
                  </div>
                  
                  <button 
                    type="button"
                    disabled={!canManageReports}
                    onClick={() => setSettings({...settings, enableAutoEmail: !settings.enableAutoEmail})}
                    className={`flex items-center gap-4 px-8 py-5 rounded-3xl font-black uppercase tracking-widest text-[10px] transition-all border shadow-lg ${
                      settings.enableAutoEmail 
                      ? 'bg-indigo-600 text-white border-indigo-500 shadow-indigo-100' 
                      : 'bg-white text-slate-400 border-slate-200'
                    }`}
                  >
                    {settings.enableAutoEmail ? <BellRing size={16} className="animate-bounce" /> : <Clock size={16} />}
                    {settings.enableAutoEmail ? 'Active' : 'Disabled'}
                  </button>
                </div>

                <div className="flex gap-4">
                  <button 
                    type="submit"
                    className="flex-1 py-6 bg-slate-900 text-white rounded-[2rem] font-black uppercase tracking-widest text-xs shadow-2xl hover:bg-slate-800 transition-all flex items-center justify-center gap-3"
                  >
                    <Save size={18} />
                    Save Protocol
                  </button>
                  <button 
                    type="button"
                    onClick={triggerTestSync}
                    className="flex-1 py-6 bg-white border border-slate-200 text-indigo-600 rounded-[2rem] font-black uppercase tracking-widest text-xs shadow-xl hover:bg-indigo-50 transition-all flex items-center justify-center gap-3"
                  >
                    {isSyncing ? <RefreshCw className="animate-spin" size={18} /> : <Zap size={18} />}
                    {isSyncing ? 'Transmitting...' : 'Trigger Sync'}
                  </button>
                </div>
              </form>
            </div>

            <div className="bg-slate-900 rounded-[3rem] p-10 flex flex-col gap-8 shadow-2xl relative overflow-hidden">
               <div className="absolute top-0 left-0 w-full h-2 bg-indigo-500"></div>
               <div className="flex items-center gap-4">
                  <Activity size={24} className="text-indigo-500" />
                  <h3 className="text-xl font-black text-white uppercase tracking-tighter leading-none">Status Monitor</h3>
               </div>

               <div className="space-y-6">
                 <div className="space-y-3">
                   <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Service Model</p>
                   <div className="p-6 bg-white/5 rounded-3xl border border-white/5 flex items-center justify-between">
                     <span className="text-sm font-black text-emerald-400">FREE_DISTRIBUTION</span>
                     <ShieldCheck size={16} className="text-emerald-500" />
                   </div>
                 </div>

                 <div className="space-y-3">
                   <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Last Dispatched</p>
                   <div className="p-6 bg-white/5 rounded-3xl border border-white/5 flex items-center justify-between">
                     <span className="text-sm font-black text-indigo-100">{lastSentAt}</span>
                     <CheckCircle2 size={16} className={lastSentAt === 'Never Dispatched' ? 'text-slate-700' : 'text-emerald-500'} />
                   </div>
                 </div>
               </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Reports;
