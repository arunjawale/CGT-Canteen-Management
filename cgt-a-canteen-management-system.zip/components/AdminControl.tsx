
import React, { useState } from 'react';
import { User, UserRole } from '../types';
import { 
  ShieldAlert, 
  Plus, 
  X, 
  Trash2, 
  ShieldCheck, 
  Key, 
  Activity,
  UserCog
} from 'lucide-react';

interface Props {
  currentUser: User;
  users: User[];
  setUsers: (users: User[]) => void;
}

const AdminControl: React.FC<Props> = ({ currentUser, users, setUsers }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  
  // Only display Super Admin and HR Admin accounts here
  const adminUsers = users.filter(u => 
    u.role === UserRole.SUPER_ADMIN || u.role === UserRole.HR_ADMIN
  );

  const handleDelete = (id: string) => {
    if (id === currentUser.id) {
      alert("Self-termination of authorization is restricted.");
      return;
    }
    if (confirm("Revoke this administrative identity? This cannot be undone.")) {
      setUsers(users.filter(u => u.id !== id));
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-black text-gray-900 uppercase tracking-tighter">Admin Control Console</h2>
          <p className="text-gray-500 font-medium">Manage top-tier administrative authorizations.</p>
        </div>
        <button 
          onClick={() => setIsModalOpen(true)}
          className="flex items-center gap-2 bg-indigo-600 text-white px-8 py-4 rounded-2xl hover:bg-indigo-700 transition-all font-black uppercase tracking-widest text-xs shadow-xl shadow-indigo-200"
        >
          <Plus size={20} />
          Add Admin Identity
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {adminUsers.map(user => (
          <div key={user.id} className="bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-sm relative group">
            <div className="flex items-center justify-between mb-6">
              <div className={`p-4 rounded-2xl ${user.role === UserRole.SUPER_ADMIN ? 'bg-indigo-600 text-white' : 'bg-emerald-500 text-white'}`}>
                {user.role === UserRole.SUPER_ADMIN ? <ShieldCheck size={24} /> : <UserCog size={24} />}
              </div>
              <button 
                onClick={() => handleDelete(user.id)}
                className="p-2 text-slate-300 hover:text-red-500 transition-colors"
              >
                <Trash2 size={18} />
              </button>
            </div>
            <h3 className="text-lg font-black text-gray-900">{user.name}</h3>
            <p className="text-xs font-black text-indigo-500 uppercase tracking-widest mt-1">@{user.username}</p>
            
            <div className="mt-6 pt-6 border-t border-slate-50 flex items-center justify-between">
              <span className={`text-[10px] font-black uppercase tracking-[0.2em] px-3 py-1 rounded-full ${user.role === UserRole.SUPER_ADMIN ? 'bg-indigo-50 text-indigo-600' : 'bg-emerald-50 text-emerald-600'}`}>
                {user.role}
              </span>
              <div className="flex items-center gap-1.5 text-[10px] font-bold text-slate-300">
                <Activity size={12} /> VERIFIED
              </div>
            </div>
          </div>
        ))}
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-6 bg-slate-900/60 backdrop-blur-md animate-in fade-in duration-300">
          <div className="bg-white w-full max-w-md rounded-[2.5rem] shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200">
            <div className="px-10 py-8 border-b border-slate-50 flex items-center justify-between">
              <h3 className="text-xl font-black text-slate-900 tracking-tight">New Admin Identity</h3>
              <button onClick={() => setIsModalOpen(false)} className="text-slate-300 hover:text-slate-900 transition-colors">
                <X size={24} />
              </button>
            </div>
            <form className="p-10 space-y-6" onSubmit={(e) => {
              e.preventDefault();
              const formData = new FormData(e.currentTarget);
              const newUser: User = {
                id: 'ADM-' + Math.random().toString(36).substr(2, 5).toUpperCase(),
                name: formData.get('name') as string,
                username: (formData.get('username') as string).toLowerCase(),
                password: formData.get('password') as string,
                role: formData.get('role') as UserRole
              };
              setUsers([...users, newUser]);
              setIsModalOpen(false);
            }}>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Full Name</label>
                <input name="name" required className="w-full px-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl font-bold" />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Login ID</label>
                <input name="username" required className="w-full px-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl font-bold" />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Access Role</label>
                <select name="role" className="w-full px-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl font-bold appearance-none">
                  <option value={UserRole.SUPER_ADMIN}>Super Admin</option>
                  <option value={UserRole.HR_ADMIN}>HR Admin</option>
                </select>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Security PIN</label>
                <input type="password" name="password" required className="w-full px-6 py-4 bg-slate-900 text-white rounded-2xl font-mono text-center tracking-[0.4em]" />
              </div>
              <button type="submit" className="w-full py-5 bg-indigo-600 text-white rounded-2xl font-black uppercase tracking-widest shadow-xl shadow-indigo-100 mt-4">
                Confirm Provisioning
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminControl;
