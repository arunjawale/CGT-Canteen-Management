
import React, { useState, useRef, useMemo, useEffect } from 'react';
import { Employee, EmployeeStatus, MealType, User, UserRole } from '../types';
import { 
  Plus, 
  Search, 
  UserCheck, 
  UserX, 
  Edit2, 
  Trash2, 
  X,
  CreditCard,
  RefreshCw,
  ShieldCheck,
  Eye,
  Camera,
  Upload,
  User as UserIcon,
  FileSpreadsheet,
  Download,
  Info,
  AlertTriangle,
  ShieldAlert,
  Fingerprint,
  CheckSquare,
  Square,
  Zap,
  Activity,
  Cpu,
  Shield
} from 'lucide-react';
import LiquidProgress from './LiquidProgress';

interface Props {
  employees: Employee[];
  setEmployees: (employees: Employee[]) => void;
  currentUser: User;
}

const EmployeeMaster: React.FC<Props> = ({ employees, setEmployees, currentUser }) => {
  const getStored = (key: string, defaultValue: any) => {
    const saved = localStorage.getItem(key);
    if (saved === null) return defaultValue;
    try {
      return JSON.parse(saved);
    } catch {
      return defaultValue;
    }
  };

  const [searchTerm, setSearchTerm] = useState(() => getStored('cgt_employees_search', ''));
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isBulkModalOpen, setIsBulkModalOpen] = useState(false);
  const [deleteConfirmation, setDeleteConfirmation] = useState<Employee | null>(null);
  const [bulkDeleteConfirmation, setBulkDeleteConfirmation] = useState(false);
  const [editingEmployee, setEditingEmployee] = useState<Employee | null>(null);
  const [previewPhoto, setPreviewPhoto] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  
  const bulkFileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    localStorage.setItem('cgt_employees_search', JSON.stringify(searchTerm));
  }, [searchTerm]);

  const isIT = currentUser.role === UserRole.IT_SUPER_USER;
  const isAdminOrHR = currentUser.role === UserRole.SUPER_ADMIN || currentUser.role === UserRole.HR_ADMIN;
  
  const canEdit = isIT || isAdminOrHR;
  const canAddOrDelete = isIT || isAdminOrHR;

  // Validation: 3-12 alphanumeric characters. Permissive to handle common employee ID formats.
  const validateEmployeeId = (id: string): { isValid: boolean, id: string } => {
    const cleaned = id.trim().toUpperCase();
    const isAlphanumericOnly = /^[A-Z0-9]+$/.test(cleaned);
    const isCorrectLength = cleaned.length >= 3 && cleaned.length <= 12;

    return { 
      isValid: isAlphanumericOnly && isCorrectLength,
      id: cleaned
    };
  };

  const filteredEmployees = useMemo(() => employees.filter(e => 
    e.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    e.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
    e.cardId.toLowerCase().includes(searchTerm.toLowerCase())
  ), [employees, searchTerm]);

  const toggleSelectAll = () => {
    if (selectedIds.size === filteredEmployees.length && filteredEmployees.length > 0) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(filteredEmployees.map(e => e.id)));
    }
  };

  const toggleSelectId = (id: string) => {
    const next = new Set(selectedIds);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    setSelectedIds(next);
  };

  const handleDeleteTrigger = (emp: Employee) => {
    if (!canAddOrDelete) return;
    setDeleteConfirmation(emp);
  };

  const confirmDelete = () => {
    if (deleteConfirmation) {
      setEmployees(employees.filter(e => e.id !== deleteConfirmation.id));
      const nextSelected = new Set(selectedIds);
      nextSelected.delete(deleteConfirmation.id);
      setSelectedIds(nextSelected);
      setDeleteConfirmation(null);
    }
  };

  const confirmBulkDelete = () => {
    const nextEmployees = employees.filter(e => !selectedIds.has(e.id));
    setEmployees(nextEmployees);
    setSelectedIds(new Set());
    setBulkDeleteConfirmation(false);
  };

  const downloadCSVTemplate = () => {
    const headers = ['ID', 'Name', 'Department', 'CardID', 'Eligibility'];
    const example = ['E101', 'Rahul Sharma', 'Operations', 'QR_001', 'Breakfast|Lunch|Snacks|Dinner'];
    const csvContent = [headers.join(','), example.join(',')].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'cgt_master_template.csv';
    a.click();
  };

  // Robust CSV Line Parser for handling quoted fields
  const parseCSVLine = (line: string): string[] => {
    const result = [];
    let current = '';
    let inQuotes = false;
    for (let i = 0; i < line.length; i++) {
      const char = line[i];
      if (char === '"') inQuotes = !inQuotes;
      else if (char === ',' && !inQuotes) {
        result.push(current.trim());
        current = '';
      } else {
        current += char;
      }
    }
    result.push(current.trim());
    return result;
  };

  const handleBulkUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsProcessing(true);
    setUploadProgress(0);
    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const text = event.target?.result as string;
        const lines = text.split(/\r?\n/).filter(line => line.trim() !== "");
        if (lines.length < 2) throw new Error("File is empty or missing data rows.");

        let currentEmployees = [...employees];
        let createdCount = 0;
        let updatedCount = 0;
        let validationErrors = 0;
        let totalProcessed = 0;

        const validMeals = Object.values(MealType);
        const totalRows = lines.length - 1;

        // Process lines with slight delay for UI responsiveness
        for (let i = 1; i < lines.length; i++) {
          const line = lines[i].trim();
          if (!line) continue;
          
          const values = parseCSVLine(line);
          const rawId = values[0];
          const name = values[1];
          const dept = values[2] || 'General';
          const cardId = values[3];
          const eligibilityRaw = values[4];

          // Basic check for mandatory fields
          if (!rawId || !name || !cardId) {
            validationErrors++;
            continue;
          }

          const { isValid, id } = validateEmployeeId(rawId);
          if (!isValid) {
            validationErrors++;
            continue;
          }

          // Parse Eligibility (Pipe separated or 'all')
          let finalEligibility: MealType[] = [];
          if (!eligibilityRaw || eligibilityRaw.toLowerCase() === 'all') {
            finalEligibility = [...validMeals];
          } else {
            const parsed = eligibilityRaw.split('|').map(m => m.trim().toLowerCase());
            finalEligibility = validMeals.filter(m => 
              parsed.includes(m.toLowerCase())
            );
            // Default to all if parsed result is empty but column was provided
            if (finalEligibility.length === 0) finalEligibility = [...validMeals];
          }

          const existingIndex = currentEmployees.findIndex(e => e.id === id);
          
          const empData: Employee = {
            id,
            name,
            department: dept,
            shift: 'Rotating', // Default to rotating for bulk imports
            cardId: cardId.toUpperCase(),
            status: EmployeeStatus.ACTIVE,
            eligibility: finalEligibility
          };

          if (existingIndex > -1) {
            currentEmployees[existingIndex] = { ...currentEmployees[existingIndex], ...empData };
            updatedCount++;
          } else {
            currentEmployees.push(empData);
            createdCount++;
          }

          totalProcessed++;

          // Update progress every 10 rows
          if (i % 10 === 0 || i === totalRows) {
            setUploadProgress(Math.round((i / totalRows) * 100));
            await new Promise(resolve => setTimeout(resolve, 5));
          }
        }

        setEmployees(currentEmployees);
        setTimeout(() => {
          alert(`Master Data Sync Complete:\n\nNew Nodes: ${createdCount}\nUpdated Nodes: ${updatedCount}\nFailed Rows: ${validationErrors}\n\nTotal Processed: ${totalProcessed}`);
        }, 500);
      } catch (err) { 
        alert(`Bulk Upload Error: ${err instanceof Error ? err.message : 'Invalid file format'}`); 
      } finally {
        setIsProcessing(false); 
        setIsBulkModalOpen(false); 
        setUploadProgress(0);
        setSelectedIds(new Set()); // Reset selection after mass update
        if (bulkFileInputRef.current) bulkFileInputRef.current.value = '';
      }
    };
    reader.readAsText(file);
  };

  const openEnrollModal = (emp: Employee | null = null) => {
    setEditingEmployee(emp);
    setPreviewPhoto(emp?.photoUrl || null);
    setIsModalOpen(true);
  };

  return (
    <div className="space-y-6 pb-20 relative">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-black text-gray-900 tracking-tight">Identity Master</h2>
          <p className="text-gray-500 font-medium">Verified registry of personnel authorized for canteen access.</p>
        </div>
        <div className="flex flex-wrap gap-3">
          {selectedIds.size > 0 && canAddOrDelete && (
            <button 
              onClick={() => setBulkDeleteConfirmation(true)} 
              className="flex items-center gap-2 bg-rose-50 text-rose-600 border border-rose-200 px-6 py-4 rounded-2xl font-black uppercase tracking-widest text-[10px] shadow-sm animate-in zoom-in duration-300"
            >
              <Trash2 size={16} /> Purge Selected ({selectedIds.size})
            </button>
          )}
          {canAddOrDelete && (
            <>
              <button onClick={() => setIsBulkModalOpen(true)} className="flex items-center gap-2 bg-white text-indigo-600 border border-indigo-200 px-6 py-4 rounded-2xl font-black uppercase tracking-widest text-[10px] shadow-sm">
                <Upload size={16} /> Bulk Map (CSV)
              </button>
              <button onClick={() => openEnrollModal(null)} className="flex items-center gap-2 bg-indigo-600 text-white px-8 py-4 rounded-2xl font-black uppercase tracking-widest text-[10px] shadow-xl">
                <Plus size={18} /> Add Entry
              </button>
            </>
          )}
        </div>
      </div>

      <div className="bg-white rounded-[2.5rem] border border-gray-200 overflow-hidden shadow-sm">
        <div className="p-8 border-b border-gray-100 bg-gray-50/30 flex flex-col md:flex-row gap-6 justify-between">
          <div className="relative flex-1 max-w-xl">
            <Search className="absolute left-6 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
            <input 
              type="text" 
              placeholder="Query node by name, UID, or card..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-16 pr-6 py-4 bg-white border border-gray-200 rounded-[1.5rem] text-sm font-bold focus:ring-4 focus:ring-indigo-500/10 outline-none transition-all shadow-sm"
            />
          </div>
          <div className={`px-6 py-3 rounded-2xl flex items-center gap-2 text-[10px] font-black uppercase tracking-widest ${employees.every(e => validateEmployeeId(e.id).isValid) ? 'bg-emerald-50 text-emerald-600 border border-emerald-100' : 'bg-amber-50 text-amber-600 border border-amber-100'}`}>
            <Shield size={14} /> Registry Status: {employees.every(e => validateEmployeeId(e.id).isValid) ? 'Secured' : 'Legacy Nodes Detected'}
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-gray-50 text-gray-400 text-[10px] font-black uppercase tracking-[0.2em]">
              <tr>
                <th className="px-6 py-6 w-10">
                  <button onClick={toggleSelectAll} className="p-2 text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors">
                    {selectedIds.size === filteredEmployees.length && filteredEmployees.length > 0 ? <CheckSquare size={20} /> : <Square size={20} className="text-gray-300" />}
                  </button>
                </th>
                <th className="px-4 py-6">Personnel</th>
                <th className="px-10 py-6">Status / Security</th>
                <th className="px-10 py-6">Card UID</th>
                <th className="px-10 py-6">Meal Access</th>
                <th className="px-10 py-6 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {filteredEmployees.length > 0 ? filteredEmployees.map((emp) => {
                const { isValid } = validateEmployeeId(emp.id);
                return (
                  <tr key={emp.id} className={`hover:bg-slate-50/80 transition-colors group ${selectedIds.has(emp.id) ? 'bg-indigo-50/40' : ''}`}>
                    <td className="px-6 py-6">
                      <button onClick={() => toggleSelectId(emp.id)} className="p-2 text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors">
                        {selectedIds.has(emp.id) ? <CheckSquare size={20} /> : <Square size={20} className="text-gray-200" />}
                      </button>
                    </td>
                    <td className="px-4 py-6">
                      <div className="flex items-center gap-5">
                        <div className="w-12 h-12 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-black text-lg border border-indigo-100 shadow-inner overflow-hidden">
                          {emp.photoUrl ? <img src={emp.photoUrl} className="w-full h-full object-cover" /> : emp.name.charAt(0)}
                        </div>
                        <div>
                          <p className="text-sm font-black text-gray-900 leading-none mb-1">{emp.name}</p>
                          <p className={`text-[10px] font-bold uppercase tracking-widest ${isValid ? 'text-gray-400' : 'text-rose-500 font-black'}`}>
                            {emp.id} {!isValid && '⚠️ LEGACY'}
                          </p>
                        </div>
                      </div>
                    </td>
                    <td className="px-10 py-6">
                      <div className="flex flex-col gap-2">
                        <span className={`inline-flex w-fit px-4 py-1.5 rounded-full text-[9px] font-black uppercase tracking-[0.15em] border ${
                          emp.status === EmployeeStatus.ACTIVE ? 'bg-emerald-500 text-white border-emerald-400' : 'bg-rose-500 text-white border-rose-400'
                        }`}>
                          {emp.status}
                        </span>
                      </div>
                    </td>
                    <td className="px-10 py-6">
                      <div className="flex items-center gap-2.5 text-xs font-mono font-black text-slate-500 bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-100 w-fit">
                        <CreditCard size={14} className="text-slate-300" /> {emp.cardId}
                      </div>
                    </td>
                    <td className="px-10 py-6">
                      <div className="flex flex-wrap gap-2 max-w-[200px]">
                        {emp.eligibility.map(m => (
                          <span key={m} className="px-2 py-1 bg-white border border-gray-200 text-slate-600 text-[8px] font-black uppercase tracking-tighter rounded-lg">
                            {m}
                          </span>
                        ))}
                      </div>
                    </td>
                    <td className="px-10 py-6 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <button onClick={() => openEnrollModal(emp)} disabled={!canEdit} className="p-3 rounded-2xl text-slate-400 hover:text-indigo-600 transition-all"><Edit2 size={18} /></button>
                        <button onClick={() => handleDeleteTrigger(emp)} disabled={!canAddOrDelete} className="p-3 rounded-2xl text-slate-300 hover:text-rose-600 transition-all"><Trash2 size={18} /></button>
                      </div>
                    </td>
                  </tr>
                );
              }) : (
                <tr>
                  <td colSpan={6} className="px-10 py-32 text-center bg-gray-50/20">
                     <div className="flex flex-col items-center gap-4 opacity-30"><UserIcon size={64} /><p className="font-black text-gray-900 uppercase tracking-widest text-sm">Cluster data not found</p></div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {isBulkModalOpen && (
        <div className="fixed inset-0 z-[120] flex items-center justify-center p-6 bg-slate-900/60 backdrop-blur-md animate-in fade-in duration-300">
           <div className="bg-white w-full max-w-xl rounded-[3.5rem] shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200">
            <div className="px-12 py-10 border-b border-gray-100 flex items-center justify-between bg-gray-50/50">
              <h3 className="text-3xl font-black text-gray-900 tracking-tight">Bulk Identity Mapping</h3>
              <button onClick={() => setIsBulkModalOpen(false)} className="text-gray-400 hover:text-gray-900 p-3 hover:bg-slate-100 rounded-2xl"><X size={32} /></button>
            </div>
            
            <div className="p-12 space-y-10">
              {isProcessing ? (
                <div className="py-10 flex flex-col items-center justify-center text-center gap-8">
                  <LiquidProgress progress={uploadProgress} size={180} />
                  <div className="space-y-2">
                    <h4 className="text-xl font-black text-slate-900 uppercase tracking-tighter">Processing Registry Update</h4>
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.4em] animate-pulse">Mapping Identity Clusters...</p>
                  </div>
                </div>
              ) : (
                <>
                  <div className="p-8 bg-indigo-50 border border-indigo-100 rounded-3xl space-y-6">
                    <div className="flex items-start gap-4">
                      <div className="p-3 bg-indigo-600 text-white rounded-2xl"><FileSpreadsheet size={24} /></div>
                      <div>
                        <h4 className="text-lg font-black text-indigo-900 leading-tight">CSV Deployment Rules</h4>
                        <p className="text-xs font-medium text-indigo-600/70 mt-1">Columns: ID, Name, Department, CardID, Eligibility</p>
                      </div>
                    </div>
                    <ul className="space-y-3 text-[10px] font-black text-indigo-900/60 uppercase tracking-widest list-disc pl-4">
                      <li>ID must be alphanumeric (3-12 characters)</li>
                      <li>Existing IDs will be updated (Upsert mode)</li>
                      <li>Eligibility format: Breakfast|Lunch|Snacks|Dinner</li>
                    </ul>
                  </div>

                  <div className="flex flex-col gap-4">
                    <input 
                      ref={bulkFileInputRef}
                      type="file" 
                      accept=".csv" 
                      onChange={handleBulkUpload}
                      className="hidden"
                    />
                    <button 
                      onClick={() => bulkFileInputRef.current?.click()}
                      className="w-full py-6 bg-indigo-600 text-white rounded-[2rem] font-black uppercase tracking-widest text-xs shadow-2xl shadow-indigo-100 hover:bg-indigo-700 transition-all flex items-center justify-center gap-4 group"
                    >
                      <Upload size={18} className="group-hover:-translate-y-1 transition-transform" />
                      Select Data Source
                    </button>
                    <button 
                      onClick={downloadCSVTemplate}
                      className="w-full py-6 bg-white border border-indigo-200 text-indigo-600 rounded-[2rem] font-black uppercase tracking-widest text-xs hover:bg-indigo-50 transition-all flex items-center justify-center gap-4"
                    >
                      <Download size={18} />
                      Fetch CSV Template
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      )}

      {isModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-slate-900/60 backdrop-blur-md animate-in fade-in duration-300">
          <div className="bg-white w-full max-w-2xl rounded-[3.5rem] shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200">
            <div className="px-12 py-10 border-b border-gray-100 flex items-center justify-between bg-gray-50/50">
              <h3 className="text-3xl font-black text-gray-900 tracking-tight">{editingEmployee ? 'Identity Patching' : 'Identity Enrollment'}</h3>
              <button onClick={() => setIsModalOpen(false)} className="text-gray-400 hover:text-gray-900 p-3 hover:bg-slate-100 rounded-2xl"><X size={32} /></button>
            </div>
            <form className="p-12 space-y-8" onSubmit={(e) => {
              e.preventDefault();
              const formData = new FormData(e.currentTarget);
              const rawId = (formData.get('id') as string) || (editingEmployee?.id || '');
              const { isValid, id } = validateEmployeeId(rawId);
              if (!isValid) { alert("Security Error: Identity ID must be 3-12 alphanumeric characters (e.g. E101)."); return; }
              const newEmp: Employee = {
                id,
                name: formData.get('name') as string,
                department: formData.get('department') as string,
                shift: 'Rotating', 
                cardId: (formData.get('cardId') as string).toUpperCase(),
                status: EmployeeStatus.ACTIVE,
                eligibility: Array.from(formData.getAll('eligibility')) as MealType[],
                photoUrl: previewPhoto || undefined
              };
              if (editingEmployee) {
                setEmployees(employees.map(emp => emp.id === editingEmployee.id ? newEmp : emp));
              } else {
                if (employees.some(e => e.id === newEmp.id)) { alert("Identity conflict: UID already mapped."); return; }
                setEmployees([...employees, newEmp]);
              }
              setIsModalOpen(false);
            }}>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-3">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Identity ID (3-12 Alphanumeric)</label>
                  <input name="id" defaultValue={editingEmployee?.id} required placeholder="e.g. E101" className="w-full px-6 py-5 bg-slate-50 border border-slate-200 rounded-2xl font-black text-lg outline-none uppercase" />
                </div>
                <div className="space-y-3">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Access Token (Card/QR)</label>
                  <input name="cardId" defaultValue={editingEmployee?.cardId} required className="w-full px-6 py-5 bg-slate-50 border border-slate-200 rounded-2xl font-mono font-black text-lg outline-none uppercase" />
                </div>
                <div className="col-span-1 md:col-span-2 space-y-3">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Full Name</label>
                  <input name="name" defaultValue={editingEmployee?.name} required className="w-full px-6 py-5 bg-slate-50 border border-slate-200 rounded-2xl font-black text-lg outline-none" />
                </div>
                <div className="col-span-1 md:col-span-2 space-y-3">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Department</label>
                  <input name="department" defaultValue={editingEmployee?.department || 'General'} required className="w-full px-6 py-5 bg-slate-50 border border-slate-200 rounded-2xl font-black text-lg outline-none" />
                </div>
                <div className="col-span-1 md:col-span-2 space-y-3">
                   <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Meal Access Eligibility</label>
                   <div className="flex flex-wrap gap-4 p-4 bg-slate-50 border border-slate-200 rounded-2xl">
                     {Object.values(MealType).map(meal => (
                       <label key={meal} className="flex items-center gap-2 cursor-pointer group">
                         <input 
                           type="checkbox" 
                           name="eligibility" 
                           value={meal} 
                           defaultChecked={editingEmployee?.eligibility.includes(meal) || !editingEmployee}
                           className="w-5 h-5 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
                         />
                         <span className="text-sm font-bold text-slate-700 group-hover:text-indigo-600">{meal}</span>
                       </label>
                     ))}
                   </div>
                </div>
              </div>
              <div className="pt-8 flex gap-4">
                <button type="button" onClick={() => setIsModalOpen(false)} className="flex-1 py-6 bg-slate-100 text-slate-500 font-black uppercase rounded-[1.5rem] text-xs">Abort</button>
                <button type="submit" className="flex-2 py-6 bg-indigo-600 text-white font-black uppercase rounded-[1.5rem] text-xs shadow-xl">Confirm Protocol</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {deleteConfirmation && (
        <div className="fixed inset-0 z-[150] flex items-center justify-center p-6 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-300">
          <div className="bg-white w-full max-w-md rounded-[2.5rem] p-10 text-center border-2 border-rose-100 animate-in zoom-in-95">
              <div className="w-24 h-24 bg-rose-50 rounded-[2rem] flex items-center justify-center mb-8 mx-auto"><AlertTriangle className="w-12 h-12 text-rose-500 animate-pulse" /></div>
              <h3 className="text-3xl font-black text-slate-900 mb-3 uppercase tracking-tighter">Revoke Access?</h3>
              <p className="text-slate-500 font-medium text-sm mb-10">Permanently purge identity profile of <span className="font-black text-rose-600">{deleteConfirmation.name}</span>.</p>
              <div className="flex flex-col gap-3">
                <button onClick={confirmDelete} className="w-full py-5 bg-rose-600 text-white rounded-2xl font-black uppercase text-xs shadow-xl">Permanently Purge</button>
                <button onClick={() => setDeleteConfirmation(null)} className="w-full py-5 bg-white border border-rose-100 text-rose-600 rounded-2xl font-black uppercase text-xs">Abort Protocol</button>
              </div>
          </div>
        </div>
      )}

      {bulkDeleteConfirmation && (
        <div className="fixed inset-0 z-[150] flex items-center justify-center p-6 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-300">
          <div className="bg-white w-full max-w-md rounded-[2.5rem] p-10 text-center border-2 border-rose-100 animate-in zoom-in-95">
              <div className="w-24 h-24 bg-rose-50 rounded-[2rem] flex items-center justify-center mb-8 mx-auto"><ShieldAlert className="w-12 h-12 text-rose-500" /></div>
              <h3 className="text-3xl font-black text-slate-900 mb-3 uppercase tracking-tighter">Bulk Purge?</h3>
              <p className="text-slate-500 font-medium text-sm mb-10">You are about to delete <span className="font-black text-rose-600">{selectedIds.size}</span> identities from the master registry.</p>
              <div className="flex flex-col gap-3">
                <button onClick={confirmBulkDelete} className="w-full py-5 bg-rose-600 text-white rounded-2xl font-black uppercase text-xs shadow-xl">Execute Purge</button>
                <button onClick={() => setBulkDeleteConfirmation(false)} className="w-full py-5 bg-white border border-rose-100 text-rose-600 rounded-2xl font-black uppercase text-xs">Abort</button>
              </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default EmployeeMaster;
