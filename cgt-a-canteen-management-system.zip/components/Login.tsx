
import React, { useState, useEffect } from 'react';
import { User, UserRole } from '../types';
import { 
  LogIn, 
  ShieldCheck, 
  AlertCircle, 
  Loader2, 
  Key, 
  X, 
  CheckCircle2, 
  Wrench, 
  UserCog, 
  ArrowRight,
  ShieldAlert,
  Info,
  Terminal,
  Zap,
  Activity,
  Lock,
  Shield,
  Briefcase,
  UserMinus,
  ChevronLeft,
  User as UserIcon,
  Fingerprint
} from 'lucide-react';

interface Props {
  onLogin: (user: User) => void;
  users: User[];
  appName: string;
  onRequestReset: (username: string) => void;
  onRegisterIT?: (user: User) => void;
  onMasterReset?: (password: string) => boolean;
}

type LoginStage = 'IDENTIFY' | 'AUTHENTICATE' | 'PROFILE_LOCK';

const Login: React.FC<Props> = ({ onLogin, users, appName, onRequestReset, onRegisterIT, onMasterReset }) => {
  const [portalMode, setPortalMode] = useState<'ADMIN' | 'IT'>('ADMIN');
  const [stage, setStage] = useState<LoginStage>('IDENTIFY');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [savedUser, setSavedUser] = useState<{username: string, name: string, role: string} | null>(null);
  const [isITRegOpen, setIsITRegOpen] = useState(false);

  // Load saved identity on mount
  useEffect(() => {
    const saved = localStorage.getItem('cgt_remembered_credentials');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        const userInDb = users.find(u => u.username === parsed.username);
        if (userInDb) {
          // Check if saved identity matches current portal roles
          const isITUser = userInDb.role === UserRole.IT_SUPER_USER;
          const isManagementUser = [UserRole.HR_ADMIN, UserRole.SUPER_ADMIN, UserRole.CANTEEN_STAFF].includes(userInDb.role);

          if ((portalMode === 'IT' && isITUser) || (portalMode === 'ADMIN' && isManagementUser)) {
            setSavedUser({
              username: userInDb.username,
              name: userInDb.name,
              role: userInDb.role
            });
            setUsername(userInDb.username);
            setStage('PROFILE_LOCK');
          }
        }
      } catch (e) { console.error("Identity parse error", e); }
    }
  }, [users, portalMode]);

  const handleNextStage = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setError('');
    const user = users.find(u => u.username.toLowerCase() === username.toLowerCase());
    
    if (!user) {
      setError('IDENTIFIER REJECTED: Identity node not found in registry.');
      return;
    }

    // Role-Portal Matching Logic
    if (portalMode === 'IT' && user.role !== UserRole.IT_SUPER_USER) {
      setError('SECURITY VIOLATION: This node lacks IT Support clearance.');
      return;
    }

    if (portalMode === 'ADMIN' && ![UserRole.HR_ADMIN, UserRole.SUPER_ADMIN, UserRole.CANTEEN_STAFF].includes(user.role)) {
      setError('ACCESS DENIED: Unauthorized for Management Portal.');
      return;
    }

    setStage('AUTHENTICATE');
  };

  const handleSwitchIdentity = () => {
    setStage('IDENTIFY');
    setUsername('');
    setPassword('');
    setSavedUser(null);
    setError('');
  };

  const handleForgetIdentity = () => {
    localStorage.removeItem('cgt_remembered_credentials');
    handleSwitchIdentity();
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');
    
    // Simulate network delay for authorization security feel
    setTimeout(() => {
      const user = users.find(u => u.username.toLowerCase() === username.toLowerCase() && u.password === password);
      
      if (user) {
        // Double verification of role at final step
        if (portalMode === 'IT' && user.role !== UserRole.IT_SUPER_USER) {
          setError('PROTOCOL VIOLATION: IT authorization required.');
          setIsLoading(false);
          return;
        }
        if (portalMode === 'ADMIN' && ![UserRole.HR_ADMIN, UserRole.SUPER_ADMIN, UserRole.CANTEEN_STAFF].includes(user.role)) {
          setError('AUTHORIZATION REFUSED: Insufficient management tier.');
          setIsLoading(false);
          return;
        }
        
        // Remember credentials if success
        localStorage.setItem('cgt_remembered_credentials', JSON.stringify({ username: user.username }));
        onLogin(user);
      } else {
        setError('AUTHORIZATION FAILED: Invalid Security Key.');
        setIsLoading(false);
      }
    }, 800);
  };

  return (
    <div className={`min-h-[100dvh] flex flex-col items-center justify-center p-rem-2 md:p-rem-4 transition-colors duration-700 ${portalMode === 'ADMIN' ? 'bg-[#f1f5f9]' : 'bg-slate-950'}`}>
      <div className={`w-full max-w-md rounded-[2.5rem] md:rounded-[3.5rem] shadow-2xl overflow-hidden border backdrop-blur-sm animate-in fade-in zoom-in duration-500 ${portalMode === 'ADMIN' ? 'bg-white border-white/40' : 'bg-slate-900 border-white/10'}`}>
        
        {/* Dynamic Header */}
        <div className={`${portalMode === 'ADMIN' ? 'bg-indigo-600' : 'bg-slate-800'} p-rem-2 md:p-rem-3 text-white text-center relative overflow-hidden transition-colors duration-500`}>
          <div className="absolute top-0 right-0 w-48 h-48 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/2 blur-3xl"></div>
          <div className="relative z-10 flex flex-col items-center">
            {stage === 'PROFILE_LOCK' && savedUser ? (
              <div className="animate-in fade-in zoom-in duration-500">
                <div className="w-20 h-20 md:w-24 md:h-24 bg-white/10 backdrop-blur-xl rounded-[1.5rem] md:rounded-[2rem] flex items-center justify-center mb-6 shadow-2xl border border-white/20 relative mx-auto">
                  <UserIcon size={44} className="text-white" />
                  <div className="absolute -bottom-1 -right-1 w-8 h-8 bg-emerald-500 rounded-xl border-4 border-indigo-600 flex items-center justify-center"><ShieldCheck size={14} /></div>
                </div>
                <h2 className="text-clamp-xl font-black uppercase tracking-tight leading-none">{savedUser.name}</h2>
                <p className="text-indigo-200 text-[10px] font-black uppercase tracking-[0.3em] mt-3 bg-white/5 py-1 px-4 rounded-full border border-white/10 inline-block">@{savedUser.username}</p>
              </div>
            ) : (
              <>
                <div className="w-16 h-16 md:w-20 md:h-20 bg-white/10 backdrop-blur-xl rounded-[1.25rem] md:rounded-[1.75rem] flex items-center justify-center mb-6 shadow-xl border border-white/20 mx-auto">
                  {portalMode === 'ADMIN' ? <ShieldCheck size={40} /> : <Wrench size={40} className="text-indigo-400" />}
                </div>
                <h1 className="text-clamp-lg font-black uppercase tracking-tighter leading-tight">{appName}</h1>
                <p className="text-indigo-100/80 font-bold mt-2 text-[10px] uppercase tracking-[0.2em] flex items-center justify-center gap-2">
                  <Shield size={14} className="opacity-60" />
                  {portalMode === 'ADMIN' ? 'Management Gateway' : 'Support Node Entrance'}
                </p>
              </>
            )}
          </div>
        </div>
        
        {/* Interaction Area */}
        <div className="p-rem-2 md:p-rem-3 space-y-6">
          {error && (
            <div className="flex items-start gap-3 p-4 bg-red-500/10 text-red-400 rounded-2xl border border-red-500/20 text-xs md:text-sm font-bold animate-in slide-in-from-top-4 duration-300">
              <AlertCircle size={20} className="shrink-0 mt-0.5" />
              <p>{error}</p>
            </div>
          )}

          {stage === 'IDENTIFY' && (
            <div className="flex p-1.5 bg-black/5 rounded-2xl">
              <button 
                onClick={() => { setPortalMode('ADMIN'); setError(''); }}
                className={`flex-1 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all flex items-center justify-center gap-2 ${portalMode === 'ADMIN' ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-500'}`}
              >
                <Briefcase size={14} /> Management
              </button>
              <button 
                onClick={() => { setPortalMode('IT'); setError(''); }}
                className={`flex-1 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all flex items-center justify-center gap-2 ${portalMode === 'IT' ? 'bg-indigo-600 text-white shadow-lg' : 'text-slate-500'}`}
              >
                <Lock size={14} /> IT Support
              </button>
            </div>
          )}

          {stage === 'IDENTIFY' && (
            <form onSubmit={handleNextStage} className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
              <div className="space-y-3">
                <label className={`text-[10px] font-black uppercase tracking-[0.2em] px-1 ${portalMode === 'ADMIN' ? 'text-slate-400' : 'text-slate-500'}`}>Identity Identifier</label>
                <input 
                  type="text" 
                  autoFocus 
                  required 
                  value={username} 
                  onChange={(e) => setUsername(e.target.value)} 
                  placeholder="Enter Username" 
                  className={`w-full px-6 py-4 md:py-5 border rounded-2xl outline-none transition-all font-bold ${portalMode === 'ADMIN' ? 'bg-slate-50 border-slate-200 text-slate-700 focus:ring-4 focus:ring-indigo-500/10' : 'bg-slate-800 border-slate-700 text-white focus:ring-4 focus:ring-indigo-500/20'}`} 
                />
              </div>
              <button type="submit" className="w-full py-4 md:py-5 bg-indigo-600 text-white rounded-2xl font-black uppercase tracking-widest transition-all flex items-center justify-center gap-3 hover:bg-indigo-700 shadow-xl group">
                Next Step <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
              </button>
            </form>
          )}

          {(stage === 'AUTHENTICATE' || stage === 'PROFILE_LOCK') && (
            <form onSubmit={handleLogin} className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
              <div className="space-y-3">
                <div className="flex items-center justify-between px-1">
                  <label className={`text-[10px] font-black uppercase tracking-[0.2em] ${portalMode === 'ADMIN' ? 'text-slate-400' : 'text-slate-500'}`}>Security Key</label>
                  <button type="button" className="text-[10px] font-black text-indigo-500 uppercase tracking-widest hover:text-indigo-400">Recovery?</button>
                </div>
                <input 
                  type="password" 
                  autoFocus 
                  required 
                  value={password} 
                  onChange={(e) => setPassword(e.target.value)} 
                  placeholder="••••••••" 
                  className={`w-full px-6 py-4 md:py-5 border rounded-2xl outline-none transition-all font-bold ${portalMode === 'ADMIN' ? 'bg-slate-50 border-slate-200 text-slate-700 focus:ring-4 focus:ring-indigo-500/10' : 'bg-slate-800 border-slate-700 text-white focus:ring-4 focus:ring-indigo-500/20'}`} 
                />
              </div>
              <div className="flex flex-col gap-4">
                <button type="submit" disabled={isLoading} className="w-full py-4 md:py-5 bg-indigo-600 text-white rounded-2xl font-black uppercase tracking-widest transition-all flex items-center justify-center gap-3 hover:bg-indigo-700 shadow-xl disabled:opacity-50">
                  {isLoading ? <Loader2 size={24} className="animate-spin" /> : <ShieldCheck size={20} />}
                  {isLoading ? 'Authorizing...' : 'Log In'}
                </button>
                <div className="flex items-center gap-3 pt-2">
                  <button type="button" onClick={handleSwitchIdentity} className="flex-1 py-3 text-[9px] font-black text-slate-400 uppercase tracking-widest flex items-center justify-center gap-2 border border-slate-100 rounded-xl hover:text-indigo-600 transition-colors"><ChevronLeft size={14} /> Switch Account</button>
                  {stage === 'PROFILE_LOCK' && <button type="button" onClick={handleForgetIdentity} title="Forget Identity" className="p-3 text-rose-400 border border-rose-50 rounded-xl bg-rose-50/20 hover:bg-rose-50 hover:text-rose-600 transition-all"><UserMinus size={16} /></button>}
                </div>
              </div>
            </form>
          )}

          {portalMode === 'IT' && stage === 'IDENTIFY' && (
            <button type="button" onClick={() => setIsITRegOpen(true)} className="w-full mt-2 text-[10px] font-black text-slate-500 uppercase tracking-widest hover:text-indigo-400 transition-colors flex items-center justify-center gap-2">
              <UserCog size={12} /> Provision Support Node
            </button>
          )}
        </div>
      </div>

      {/* IT Provisioning Modal */}
      {isITRegOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-slate-950/90 backdrop-blur-xl animate-in fade-in duration-300">
           <div className="bg-slate-900 w-full max-w-lg rounded-[2.5rem] md:rounded-[3.5rem] shadow-2xl overflow-hidden border border-white/10 animate-in zoom-in-95 duration-200">
            <div className="px-10 md:px-12 py-8 border-b border-white/5 flex items-center justify-between">
              <h3 className="text-lg font-black text-white tracking-tight uppercase">Support Enrollment</h3>
              <button onClick={() => setIsITRegOpen(false)} className="text-slate-500 hover:text-white transition-colors p-2"><X size={24} /></button>
            </div>
            <form className="p-10 space-y-6" onSubmit={(e) => {
              e.preventDefault();
              const f = new FormData(e.currentTarget);
              if (f.get('sysKey') === 'MASTER_SUPPORT_KEY_2025') {
                onRegisterIT?.({ 
                  id: 'IT-' + Math.random().toString(36).substr(2, 5).toUpperCase(), 
                  username: f.get('user') as string, 
                  password: f.get('pass') as string, 
                  name: f.get('name') as string, 
                  role: UserRole.IT_SUPER_USER 
                });
                setIsITRegOpen(false);
                alert("IT Support node provisioned.");
              } else alert("Invalid System Master Token");
            }}>
              <input name="sysKey" required type="password" placeholder="System Master Token" className="w-full px-6 py-4 bg-slate-800 border border-slate-700 rounded-2xl text-white outline-none focus:ring-2 focus:ring-indigo-500" />
              <input name="name" required placeholder="Legal Name" className="w-full px-6 py-4 bg-slate-800 border border-slate-700 rounded-2xl text-white outline-none focus:ring-2 focus:ring-indigo-500" />
              <input name="user" required placeholder="Node ID (Username)" className="w-full px-6 py-4 bg-slate-800 border border-slate-700 rounded-2xl text-white outline-none focus:ring-2 focus:ring-indigo-500" />
              <input name="pass" required type="password" placeholder="Set Key (PIN)" className="w-full px-6 py-4 bg-slate-800 border border-slate-700 rounded-2xl text-white outline-none focus:ring-2 focus:ring-indigo-500" />
              <button type="submit" className="w-full bg-indigo-600 text-white py-4 rounded-2xl font-black uppercase tracking-widest shadow-xl hover:bg-indigo-700 transition-all">Enroll Node</button>
            </form>
          </div>
        </div>
      )}

      <style>{`
        .p-rem-1 { padding: 1rem; }
        .p-rem-2 { padding: 2rem; }
        .p-rem-3 { padding: 3rem; }
        .p-rem-4 { padding: 4rem; }
        .text-clamp-lg { font-size: clamp(1.125rem, 4vw, 1.5rem); }
        .text-clamp-xl { font-size: clamp(1.25rem, 5vw, 1.875rem); }
      `}</style>
    </div>
  );
};

export default Login;
