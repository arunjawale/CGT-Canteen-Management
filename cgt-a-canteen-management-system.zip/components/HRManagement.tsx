
import React, { useState } from 'react';
import { User, UserRole, Employee } from '../types';
import { 
  Briefcase, 
  Plus, 
  X, 
  Trash2, 
  Users, 
  Link as LinkIcon,
  Activity,
  Terminal,
  UserCheck
} from 'lucide-react';

interface Props {
  currentUser: User;
  users: User[];
  setUsers: (users: User[]) => void;
  employees: Employee[];
}

const HRManagement: React.FC<Props> = ({ currentUser, users, setUsers, employees }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  
  // Only display Canteen Staff and Employee login accounts here
  const hrUsers = users.filter(u => 
    u.role === UserRole.CANTEEN_STAFF || u.role === UserRole.EMPLOYEE
  );

  const handleDelete = (id: string) => {
    if (confirm("Revoke this identity's system access?")) {
      setUsers(users.filter(u => u.id !== id));
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-black text-gray-900 uppercase tracking-tighter">HR Operations Console</h2>
          <p className="text-gray-500 font-medium">Provision system access for canteen staff and employees.</p>
        </div>
        <button 
          onClick={() => setIsModalOpen(true)}
          className="flex items-center gap-2 bg-emerald-600 text-white px-8 py-4 rounded-2xl hover:bg-emerald-700 transition-all font-black uppercase tracking-widest text-xs shadow-xl shadow-emerald-200"
        >
          <Plus size={20} />
          New Staff Credential
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {hrUsers.map(user => (
          <div key={user.id} className="bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-sm relative group">
            <div className="flex items-center justify-between mb-6">
              <div className={`p-4 rounded-2xl ${user.role === UserRole.CANTEEN_STAFF ? 'bg-amber-500 text-white' : 'bg-indigo-400 text-white'}`}>
                {user.role === UserRole.CANTEEN_STAFF ? <Terminal size={24} /> : <Users size={24} />}
              </div>
              <button 
                onClick={() => handleDelete(user.id)}
                className="p-2 text-slate-300 hover:text-red-500 transition-colors"
              >
                <Trash2 size={18} />
              </button>
            </div>
            <h3 className="text-lg font-black text-gray-900">{user.name}</h3>
            <p className="text-xs font-black text-emerald-500 uppercase tracking-widest mt-1">@{user.username}</p>
            
            <div className="mt-4 flex flex-col gap-2">
              {user.employeeId && (
                <div className="flex items-center gap-2 text-[10px] font-black text-slate-400 uppercase tracking-widest">
                  <LinkIcon size={12} className="text-indigo-400" /> Linked ID: {user.employeeId}
                </div>
              )}
            </div>

            <div className="mt-6 pt-6 border-t border-slate-50 flex items-center justify-between">
              <span className={`text-[10px] font-black uppercase tracking-[0.2em] px-3 py-1 rounded-full ${user.role === UserRole.CANTEEN_STAFF ? 'bg-amber-50 text-amber-600' : 'bg-indigo-50 text-indigo-600'}`}>
                {user.role}
              </span>
              <div className="flex items-center gap-1.5 text-[10px] font-bold text-slate-300">
                <UserCheck size={12} /> ACTIVE
              </div>
            </div>
          </div>
        ))}
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-6 bg-slate-900/60 backdrop-blur-md animate-in fade-in duration-300">
          <div className="bg-white w-full max-w-md rounded-[3.5rem] shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200">
            <div className="px-10 py-8 border-b border-slate-50 flex items-center justify-between">
              <h3 className="text-xl font-black text-slate-900 tracking-tight">Staff Access Provision</h3>
              <button onClick={() => setIsModalOpen(false)} className="text-slate-300 hover:text-slate-900 transition-colors">
                <X size={24} />
              </button>
            </div>
            <form className="p-10 space-y-6" onSubmit={(e) => {
              e.preventDefault();
              const formData = new FormData(e.currentTarget);
              const newUser: User = {
                id: 'HR-' + Math.random().toString(36).substr(2, 5).toUpperCase(),
                name: formData.get('name') as string,
                username: (formData.get('username') as string).toLowerCase(),
                password: formData.get('password') as string,
                role: formData.get('role') as UserRole,
                employeeId: formData.get('employeeId') as string || undefined
              };
              setUsers([...users, newUser]);
              setIsModalOpen(false);
            }}>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Staff Name</label>
                <input name="name" required className="w-full px-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl font-bold" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Username</label>
                  <input name="username" required className="w-full px-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl font-bold" />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Staff Tier</label>
                  <select name="role" className="w-full px-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl font-bold appearance-none">
                    <option value={UserRole.EMPLOYEE}>Standard Employee</option>
                    <option value={UserRole.CANTEEN_STAFF}>Canteen Staff</option>
                  </select>
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Linked Employee Record</label>
                <select name="employeeId" className="w-full px-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl font-bold appearance-none">
                  <option value="">No Physical Link</option>
                  {employees.map(emp => (
                    <option key={emp.id} value={emp.id}>{emp.name} ({emp.id})</option>
                  ))}
                </select>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Security PIN</label>
                <input type="password" name="password" required className="w-full px-6 py-4 bg-emerald-50 border border-emerald-100 text-emerald-700 rounded-2xl font-mono text-center tracking-[0.4em]" />
              </div>
              <button type="submit" className="w-full py-5 bg-emerald-600 text-white rounded-2xl font-black uppercase tracking-widest shadow-xl shadow-emerald-100 mt-4">
                Authorize Personnel
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default HRManagement;
