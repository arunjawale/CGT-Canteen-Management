
import React from 'react';

interface Props {
  progress: number; // 0 to 100
  size?: number;
}

const LiquidProgress: React.FC<Props> = ({ progress, size = 200 }) => {
  // Calculate top offset for liquid (100% is empty, 0% is full)
  const fillLevel = 100 - progress;

  return (
    <div className="relative flex items-center justify-center animate-in fade-in zoom-in duration-1000">
      {/* Outer Glow / Depth */}
      <div 
        className="absolute rounded-full bg-indigo-500/10 blur-[60px] animate-pulse"
        style={{ width: size + 40, height: size + 40 }}
      />

      {/* Main Container (The Glass Sphere) */}
      <div 
        className="relative overflow-hidden rounded-full border-[6px] border-white shadow-[0_20px_50px_rgba(0,0,0,0.1),inset_0_0_20px_rgba(255,255,255,0.5)] bg-slate-50/30 backdrop-blur-md"
        style={{ width: size, height: size }}
      >
        {/* Refraction Reflection (Top Highlight) */}
        <div className="absolute top-[10%] left-[15%] w-[30%] h-[15%] bg-white/40 rounded-full blur-md rotate-[-35deg] z-30" />

        {/* The Liquid Container */}
        <div 
          className="absolute inset-0 z-10 transition-all duration-1000 ease-in-out"
          style={{ transform: `translateY(${fillLevel}%)` }}
        >
          {/* Wave 1 (Deepest) */}
          <div className="absolute top-0 left-[-50%] w-[200%] h-[200%] bg-indigo-700/40 rounded-[38%] animate-wave-slow opacity-60" />
          
          {/* Wave 2 (Mid) */}
          <div className="absolute top-0 left-[-55%] w-[200%] h-[200%] bg-indigo-500/50 rounded-[40%] animate-wave-mid opacity-80" />
          
          {/* Wave 3 (Surface) */}
          <div className="absolute top-0 left-[-52%] w-[200%] h-[200%] bg-gradient-to-b from-blue-400 to-indigo-600 rounded-[42%] animate-wave-fast" />
        </div>

        {/* Percentage Overlay */}
        <div className="absolute inset-0 flex flex-col items-center justify-center z-20">
          <span className="text-5xl font-black text-slate-900 tracking-tighter drop-shadow-sm select-none">
            {progress}%
          </span>
          <div className="bg-white/40 backdrop-blur-sm px-3 py-1 rounded-full border border-white/40 mt-1">
             <span className="text-[8px] font-black uppercase tracking-[0.3em] text-indigo-900 leading-none">Identity Sync</span>
          </div>
        </div>
      </div>

      <style>{`
        @keyframes wave-move {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        .animate-wave-slow {
          animation: wave-move 12s linear infinite;
        }
        .animate-wave-mid {
          animation: wave-move 8s linear infinite;
        }
        .animate-wave-fast {
          animation: wave-move 5s linear infinite;
        }
      `}</style>
    </div>
  );
};

export default LiquidProgress;
