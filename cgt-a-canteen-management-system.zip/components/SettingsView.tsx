
import React, { useState, useRef, useEffect } from 'react';
import { AppSettings, User, UserRole, Employee, Transaction, MealConfig, MealType, EmployeeStatus } from '../types';
import { 
  Monitor, 
  Palette, 
  Check,
  ShieldCheck,
  Lock,
  Volume2,
  Mail,
  Zap,
  Eye,
  RefreshCw,
  Trash2,
  Download,
  Terminal,
  Activity,
  AlertTriangle,
  History,
  ChevronRight,
  Server,
  X,
  Bot,
  MessageSquare,
  Cpu,
  BrainCircuit,
  Database,
  HeartPulse,
  Wrench,
  Stethoscope,
  ShieldAlert,
  Save,
  Info,
  Clock,
  MousePointer2,
  Timer,
  Upload,
  ScanLine,
  Printer,
  Power
} from 'lucide-react';
import { getMaintenanceAdvice, analyzeSystemHealth } from '../services/gemini';

interface Props {
  settings: AppSettings;
  setSettings: (s: AppSettings) => void;
  currentUser: User;
  onResetApp: () => void;
  schemaVersion: number;
  setSchemaVersion: (v: number) => void;
  appVersion: number;
  masterData: {
    employees: Employee[];
    transactions: Transaction[];
    mealConfigs: MealConfig[];
    users: User[];
  };
  setEmployees: (e: Employee[]) => void;
  setTransactions: (t: Transaction[]) => void;
  setMealConfigs: (m: MealConfig[]) => void;
  setUsers: (u: User[]) => void;
}

const SettingsView: React.FC<Props> = ({ 
  settings, 
  setSettings, 
  currentUser, 
  onResetApp, 
  schemaVersion, 
  setSchemaVersion,
  appVersion,
  masterData,
  setEmployees,
  setTransactions,
  setMealConfigs,
  setUsers
}) => {
  const [activeTab, setActiveTab] = useState<'Branding' | 'StationMode' | 'Operations' | 'Health' | 'Migration' | 'Support'>('StationMode');
  const [isScanningHealth, setIsScanningHealth] = useState(false);
  const [healthScore, setHealthScore] = useState<number | null>(null);
  const [aiDiagnosis, setAiDiagnosis] = useState<string | null>(null);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const isIT = currentUser.role === UserRole.IT_SUPER_USER;

  const checkSystemHealth = async () => {
    setIsScanningHealth(true);
    await new Promise(resolve => setTimeout(resolve, 2000));
    setHealthScore(masterData.employees.length > 0 ? 98 : 100);
    setIsScanningHealth(false);
  };

  const handleExportRegistry = () => {
    const backup = { version: appVersion, schema: schemaVersion, timestamp: new Date().toISOString(), data: masterData, settings: settings };
    const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `cgt_node_registry_${new Date().getTime()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleImportRegistry = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const backup = JSON.parse(event.target?.result as string);
        if (!backup.data || !backup.settings) throw new Error("Invalid Format");
        if (confirm("Overwrite all local data with imported registry?")) {
          setEmployees(backup.data.employees || []);
          setTransactions(backup.data.transactions || []);
          setMealConfigs(backup.data.mealConfigs || []);
          setUsers(backup.data.users || []);
          setSettings(backup.settings);
          if (backup.schema) setSchemaVersion(backup.schema);
          alert("Node Registry successfully restored.");
        }
      } catch (err) { alert("Import Failed"); }
    };
    reader.readAsText(file);
  };

  return (
    <div className="w-full max-w-[1440px] mx-auto space-y-10 animate-in fade-in duration-700">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 px-4">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <Zap className="text-indigo-600" size={18} />
            <span className="text-[10px] font-black uppercase tracking-[0.2em] text-indigo-600">Core Node v{appVersion}.2</span>
          </div>
          <h2 className="text-clamp-3xl font-black text-gray-900 tracking-tight leading-none">Global Config</h2>
        </div>
        {!isIT && (
          <div className="flex items-center gap-2 px-6 py-3 bg-amber-50 text-amber-600 text-[10px] font-black uppercase tracking-widest rounded-2xl border border-amber-100 shadow-sm">
            <Lock size={14} /> Restricted Support
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-[280px_1fr] gap-8 px-4">
        <div className="space-y-2">
          {[
            { id: 'StationMode', icon: <ScanLine size={18} />, label: 'Station Mode' },
            { id: 'Branding', icon: <Palette size={18} />, label: 'Branding' },
            { id: 'Operations', icon: <Volume2 size={18} />, label: 'Sound' },
            { id: 'Health', icon: <HeartPulse size={18} />, label: 'Health' },
            { id: 'Migration', icon: <Server size={18} />, label: 'Migration' },
            { id: 'Support', icon: <Mail size={18} />, label: 'Support' }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`w-full flex items-center gap-4 px-6 py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all ${
                activeTab === tab.id ? 'bg-indigo-600 text-white shadow-xl translate-x-2' : 'text-slate-400 hover:bg-white hover:text-slate-900'
              }`}
            >
              {tab.icon}
              {tab.label}
            </button>
          ))}
          <div className="mt-8 pt-8 border-t border-slate-200">
            <button onClick={() => confirm("Reset Node?") && onResetApp()} className="w-full flex items-center gap-4 px-6 py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest text-slate-400 hover:bg-rose-50 hover:text-rose-600 transition-all">
              <Trash2 size={16} /> Hard Reset
            </button>
          </div>
        </div>

        <div className="w-full">
          <div className="bg-white rounded-[2.5rem] md:rounded-[3.5rem] border border-gray-100 shadow-xl overflow-hidden relative min-h-[600px] transition-all">
            <div className="p-8 md:p-14 space-y-12">
              
              {activeTab === 'StationMode' && (
                <div className="space-y-10 animate-in slide-in-from-right-4 duration-300">
                  <div className="flex items-center gap-4">
                    <div className="p-4 bg-indigo-600 text-white rounded-[2rem] shadow-xl"><ScanLine size={32} /></div>
                    <div>
                       <h3 className="text-2xl font-black text-slate-900">Station Mode Protocol</h3>
                       <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-1">Managed Scanner Behavior</p>
                    </div>
                  </div>

                  <div className="space-y-8 p-6 md:p-10 bg-slate-50 rounded-[2.5rem] border border-slate-100 shadow-inner">
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 pb-6 border-b border-slate-200/50">
                       <div className="flex items-center gap-3">
                          <Monitor size={24} className="text-indigo-600" />
                          <div>
                            <label className="text-xs font-black text-slate-900 uppercase tracking-widest">Keep Screen Awake</label>
                            <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest mt-1">Prevents display sleep during active session</p>
                          </div>
                       </div>
                       <button 
                        onClick={() => setSettings({...settings, keepScreenAwake: !settings.keepScreenAwake})}
                        disabled={!isIT}
                        className={`relative inline-flex h-8 w-16 items-center rounded-full transition-all focus:outline-none focus:ring-4 focus:ring-indigo-500/10 shadow-inner ${
                          settings.keepScreenAwake ? 'bg-indigo-600' : 'bg-slate-200'
                        } ${!isIT ? 'cursor-not-allowed' : 'cursor-pointer'}`}
                       >
                         <span
                           className={`inline-block h-6 w-6 transform rounded-full bg-white transition-all shadow-md ${
                             settings.keepScreenAwake ? 'translate-x-9' : 'translate-x-1'
                           } flex items-center justify-center`}
                         >
                           {settings.keepScreenAwake ? <Check size={12} className="text-indigo-600" /> : <X size={12} className="text-slate-300" />}
                         </span>
                       </button>
                    </div>

                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 pb-6 border-b border-slate-200/50">
                       <div className="flex items-center gap-3">
                          <Printer size={24} className="text-indigo-600" />
                          <div>
                            <label className="text-xs font-black text-slate-900 uppercase tracking-widest">Auto-Print Vouchers</label>
                            <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest mt-1">Triggers browser print dialog on scan</p>
                          </div>
                       </div>
                       <button 
                        onClick={() => setSettings({...settings, enablePrinting: !settings.enablePrinting})}
                        disabled={!isIT}
                        className={`relative inline-flex h-8 w-16 items-center rounded-full transition-all focus:outline-none focus:ring-4 focus:ring-indigo-500/10 shadow-inner ${
                          settings.enablePrinting ? 'bg-indigo-600' : 'bg-slate-200'
                        } ${!isIT ? 'cursor-not-allowed' : 'cursor-pointer'}`}
                       >
                         <span
                           className={`inline-block h-6 w-6 transform rounded-full bg-white transition-all shadow-md ${
                             settings.enablePrinting ? 'translate-x-9' : 'translate-x-1'
                           } flex items-center justify-center`}
                         >
                           {settings.enablePrinting ? <Check size={12} className="text-indigo-600" /> : <X size={12} className="text-slate-300" />}
                         </span>
                       </button>
                    </div>

                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 pb-6 border-b border-slate-200/50">
                       <div className="flex items-center gap-3">
                          <Timer size={24} className="text-indigo-600" />
                          <div>
                            <label className="text-xs font-black text-slate-900 uppercase tracking-widest">Persistence Logic</label>
                            <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest mt-1">Behavior after successful scan</p>
                          </div>
                       </div>
                       <div className="flex bg-white p-1.5 rounded-2xl border border-slate-200 shadow-sm self-start md:self-auto">
                          <button 
                            onClick={() => setSettings({...settings, manualPunchReset: false})}
                            className={`px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${!settings.manualPunchReset ? 'bg-indigo-600 text-white shadow-lg' : 'text-slate-400'}`}
                          >
                            Auto-Return
                          </button>
                          <button 
                            onClick={() => setSettings({...settings, manualPunchReset: true})}
                            className={`px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${settings.manualPunchReset ? 'bg-indigo-600 text-white shadow-lg' : 'text-slate-400'}`}
                          >
                            Persistent
                          </button>
                       </div>
                    </div>

                    <div className="space-y-8">
                      {settings.manualPunchReset ? (
                        <div className="space-y-4 animate-in fade-in duration-500">
                          <div className="flex justify-between items-center px-2">
                            <span className="text-[10px] font-black text-indigo-600 uppercase tracking-widest">Station Persistence (1-24 Hours)</span>
                            <span className="px-5 py-2 bg-indigo-600 text-white rounded-xl text-lg font-black font-mono shadow-lg">{settings.manualResetTimeoutHours}h</span>
                          </div>
                          <input 
                            type="range" min="1" max="24" step="1"
                            disabled={!isIT}
                            value={settings.manualResetTimeoutHours} 
                            onChange={(e) => setSettings({ ...settings, manualResetTimeoutHours: parseInt(e.target.value) })} 
                            className="w-full h-4 bg-indigo-100 rounded-full appearance-none cursor-pointer accent-indigo-600" 
                          />
                          <div className="flex justify-between text-[10px] font-black text-slate-400 uppercase tracking-tighter">
                            <span>1 Hour Persistence</span>
                            <span>24 Hour Full Persistence</span>
                          </div>
                        </div>
                      ) : (
                        <div className="space-y-4 animate-in fade-in duration-500">
                          <div className="flex justify-between items-center px-2">
                            <span className="text-[10px] font-black text-indigo-600 uppercase tracking-widest">Auto-Return Delay (1-5 Seconds)</span>
                            <span className="px-5 py-2 bg-indigo-600 text-white rounded-xl text-lg font-black font-mono shadow-lg">{settings.punchScreenTimeout}s</span>
                          </div>
                          <input 
                            type="range" min="1" max="5" step="1"
                            disabled={!isIT}
                            value={settings.punchScreenTimeout} 
                            onChange={(e) => setSettings({ ...settings, punchScreenTimeout: parseInt(e.target.value) })} 
                            className="w-full h-4 bg-indigo-100 rounded-full appearance-none cursor-pointer accent-indigo-600" 
                          />
                          <div className="flex justify-between text-[10px] font-black text-slate-400 uppercase tracking-tighter">
                            <span>High Speed (1s)</span>
                            <span>Standard (5s)</span>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'Branding' && (
                <div className="space-y-10 animate-in slide-in-from-right-4 duration-300">
                  <h3 className="text-2xl font-black text-slate-900 flex items-center gap-4">
                    <div className="p-3 bg-indigo-50 text-indigo-600 rounded-2xl"><Palette size={24} /></div>
                    Node Identity
                  </h3>
                  <div className="space-y-4">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">App Name Identifier</label>
                    <input type="text" disabled={!isIT} value={settings.appName} onChange={(e) => setSettings({ ...settings, appName: e.target.value })} className="w-full px-8 py-5 bg-slate-50 border border-slate-200 rounded-[1.5rem] font-bold outline-none focus:ring-4 focus:ring-indigo-500/10 transition-all" />
                  </div>
                </div>
              )}

              {activeTab === 'Operations' && (
                <div className="space-y-10 animate-in slide-in-from-right-4 duration-300">
                   <h3 className="text-2xl font-black text-slate-900 flex items-center gap-4">
                    <div className="p-3 bg-indigo-50 text-indigo-600 rounded-2xl"><Volume2 size={24} /></div>
                    Sound & Volume Control
                  </h3>
                  <div className="space-y-6 p-8 bg-slate-50 rounded-[2.5rem] border border-slate-100 shadow-inner">
                    <div className="flex items-center gap-3 mb-2">
                       <Volume2 size={18} className="text-indigo-600" />
                       <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Audio Feedback Level</label>
                    </div>
                    <input type="range" min="0" max="100" disabled={!isIT} value={settings.terminalVolume} onChange={(e) => setSettings({ ...settings, terminalVolume: parseInt(e.target.value) })} className="w-full h-2 bg-indigo-100 rounded-lg appearance-none cursor-pointer accent-indigo-600" />
                    <div className="flex justify-between items-center">
                      <span className="text-[10px] font-black text-slate-400 uppercase">Mute</span>
                      <span className="text-xs font-black text-slate-900">{settings.terminalVolume}%</span>
                      <span className="text-[10px] font-black text-slate-400 uppercase">Max</span>
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'Health' && (
                <div className="space-y-10 animate-in slide-in-from-right-4 duration-500">
                  <div className="flex flex-col md:flex-row justify-between items-start gap-8">
                    <div className="space-y-2">
                      <h3 className="text-3xl font-black text-slate-900 flex items-center gap-4"><div className="p-3 bg-rose-50 text-rose-600 rounded-2xl"><HeartPulse size={28} /></div>Node Integrity</h3>
                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest italic">Automated system diagnostics.</p>
                    </div>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <button onClick={checkSystemHealth} disabled={isScanningHealth} className="p-10 bg-white border border-slate-200 rounded-[3rem] text-left hover:border-indigo-600 transition-all shadow-sm">
                      <Stethoscope size={32} className="text-indigo-600 mb-6" />
                      <h4 className="text-xl font-black text-slate-900">Run Node Scan</h4>
                    </button>
                    <button onClick={() => alert("Synchronized")} disabled={!isIT} className="p-10 bg-white border border-slate-200 rounded-[3rem] text-left hover:border-emerald-600 transition-all shadow-sm">
                      <Wrench size={32} className="text-emerald-600 mb-6" />
                      <h4 className="text-xl font-black text-slate-900">Execute Patch</h4>
                    </button>
                  </div>
                </div>
              )}

              {activeTab === 'Migration' && (
                <div className="space-y-10 animate-in slide-in-from-right-4 duration-500">
                   <h3 className="text-2xl font-black text-slate-900 flex items-center gap-4">
                    <div className="p-3 bg-indigo-50 text-indigo-600 rounded-2xl"><Server size={24} /></div>
                    Registry Migration Hub
                  </h3>
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
                    <div className="space-y-8 p-10 bg-slate-50 rounded-[3rem] border border-slate-100 shadow-inner">
                      <h4 className="text-xl font-black text-slate-900">Backup & Restore</h4>
                      <div className="flex flex-col gap-4">
                        <button onClick={handleExportRegistry} className="w-full py-5 bg-indigo-600 text-white rounded-2xl font-black uppercase tracking-widest text-[10px] shadow-lg shadow-indigo-100 transition-all flex items-center justify-center gap-3"><Download size={18} /> Export Registry</button>
                        <div className="relative">
                          <input type="file" ref={fileInputRef} onChange={handleImportRegistry} className="hidden" accept=".json" />
                          <button onClick={() => fileInputRef.current?.click()} className="w-full py-5 bg-white border border-indigo-200 text-indigo-600 rounded-2xl font-black uppercase tracking-widest text-[10px] transition-all flex items-center justify-center gap-3"><Monitor size={18} /> Import JSON</button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'Support' && (
                <div className="space-y-10 animate-in slide-in-from-right-4 duration-300">
                  <h3 className="text-2xl font-black text-slate-900 flex items-center gap-4"><div className="p-3 bg-emerald-50 text-emerald-600 rounded-2xl"><Mail size={24} /></div>Support Gateway</h3>
                  <div className="space-y-4">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Gateway Email</label>
                    <input type="email" disabled={!isIT} value={settings.supportEmail} onChange={(e) => setSettings({ ...settings, supportEmail: e.target.value })} className="w-full px-8 py-5 bg-slate-50 border border-slate-200 rounded-[1.5rem] font-bold outline-none" />
                  </div>
                </div>
              )}

            </div>
            
            <div className="p-8 md:p-10 bg-slate-50 flex items-center justify-between border-t border-slate-100">
              <div className="flex items-center gap-8">
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse shadow-[0_0_12px_#10b981]"></div>
                  <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Protocol Stable</p>
                </div>
              </div>
              {isIT && (
                <button onClick={() => alert("Registry Committed")} className="px-10 py-5 bg-indigo-600 text-white font-black uppercase rounded-2xl hover:bg-indigo-700 transition-all flex items-center justify-center gap-3 shadow-2xl text-[10px] tracking-widest">
                  <Save size={18} /> Commit Changes
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
      <style>{`
        .text-clamp-3xl { font-size: clamp(1.875rem, 5vw, 2.25rem); }
      `}</style>
    </div>
  );
};

export default SettingsView;