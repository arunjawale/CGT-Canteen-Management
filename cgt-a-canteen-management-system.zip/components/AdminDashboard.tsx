
import React, { useState, useMemo, useEffect } from 'react';
import { Employee, Transaction, MealConfig, MealType } from '../types';
import { 
  Users, 
  ArrowUpRight, 
  ArrowDownRight, 
  Utensils, 
  CreditCard, 
  TrendingUp,
  Search,
  ExternalLink,
  Sparkles,
  Clock,
  ChevronRight,
  Activity,
  Zap,
  RefreshCw,
  LayoutGrid,
  PieChart as PieChartIcon,
  Flame,
  Calendar,
  Layers,
  ShieldCheck as ShieldCheckIcon,
  Briefcase,
  ShieldAlert,
  History
} from 'lucide-react';
import { 
  Tooltip, 
  ResponsiveContainer, 
  Cell,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  PieChart,
  Pie,
  Legend
} from 'recharts';
import { getMealInsights } from '../services/gemini';
import { CURRENT_SCHEMA_VERSION } from '../constants';

interface DashboardProps {
  employees: Employee[];
  transactions: Transaction[];
  meals: MealConfig[];
  integrityScore?: number;
}

const MEAL_COLORS: Record<string, string> = {
  [MealType.BREAKFAST]: '#f59e0b', // Amber
  [MealType.LUNCH]: '#3b82f6',     // Blue
  [MealType.SNACKS]: '#10b981',    // Emerald
  [MealType.DINNER]: '#8b5cf6',    // Violet
};

const AdminDashboard: React.FC<DashboardProps> = ({ employees, transactions, meals, integrityScore = 100 }) => {
  const getStored = (key: string, defaultValue: any) => {
    const saved = localStorage.getItem(key);
    if (saved === null) return defaultValue;
    try {
      return JSON.parse(saved);
    } catch {
      return defaultValue;
    }
  };

  const [aiQuery, setAiQuery] = useState(() => getStored('cgt_dashboard_ai_query', ''));
  const [aiResult, setAiResult] = useState<{ text: string; sources: string[] } | null>(() => getStored('cgt_dashboard_ai_result', null));
  const [loadingAi, setLoadingAi] = useState(false);

  useEffect(() => {
    localStorage.setItem('cgt_dashboard_ai_query', JSON.stringify(aiQuery));
  }, [aiQuery]);

  useEffect(() => {
    localStorage.setItem('cgt_dashboard_ai_result', JSON.stringify(aiResult));
  }, [aiResult]);

  const today = new Date();
  const todayTransactions = useMemo(() => transactions.filter(t => {
    const d = new Date(t.timestamp);
    return d.getDate() === today.getDate() && 
           d.getMonth() === today.getMonth() && 
           d.getFullYear() === today.getFullYear();
  }), [transactions]);

  const trafficData = useMemo(() => {
    const hours = Array.from({ length: 24 }, (_, i) => ({
      hour: `${i}:00`,
      count: todayTransactions.filter(t => new Date(t.timestamp).getHours() === i).length
    }));
    return hours.filter(h => h.count > 0 || (parseInt(h.hour) > 7 && parseInt(h.hour) < 22));
  }, [todayTransactions]);

  const chartData = useMemo(() => Object.values(MealType).map(type => ({
    name: type,
    value: todayTransactions.filter(t => t.mealType === type).length,
  })).filter(d => d.value > 0), [todayTransactions]);

  const handleAiInsight = async () => {
    if (!aiQuery.trim()) return;
    setLoadingAi(true);
    const res = await getMealInsights(aiQuery);
    setAiResult(res);
    setLoadingAi(false);
  };

  const recentActivity = todayTransactions.slice(0, 6);

  return (
    <div className="space-y-8 animate-in fade-in duration-700 pb-16">
      <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-8 bg-white p-8 rounded-[3rem] border border-slate-100 shadow-sm">
        <div className="flex items-center gap-6">
          <div className="p-5 bg-indigo-600 rounded-[2rem] text-white shadow-2xl shadow-indigo-100">
            <LayoutGrid size={32} />
          </div>
          <div>
            <h2 className="text-4xl font-black text-slate-900 tracking-tighter leading-none">Operations Command</h2>
            <div className="flex items-center gap-3 mt-3">
              <span className="px-3 py-1 bg-emerald-500/10 text-emerald-600 rounded-lg text-[10px] font-black uppercase tracking-widest border border-emerald-500/10">
                Free Service Only
              </span>
              <p className="text-slate-400 font-bold text-xs uppercase tracking-widest">
                Uplink Active • Registry {`v${CURRENT_SCHEMA_VERSION}.2`}
              </p>
            </div>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-6">
          <div className="bg-slate-900 px-8 py-4 rounded-[1.5rem] border border-white/10 text-right flex items-center gap-6">
             <div className="text-right border-r border-white/10 pr-6">
                <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1 leading-none">Integrity Monitor</p>
                <p className={`text-2xl font-black font-mono tracking-tighter ${integrityScore < 90 ? 'text-amber-400' : 'text-emerald-400'}`}>{`${integrityScore}%`}</p>
             </div>
             <div>
                <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1 leading-none">Local Time</p>
                <p className="text-2xl font-black text-white font-mono tracking-tighter">
                  {today.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </p>
             </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <AdvancedStatCard 
          label="Active Personnel" 
          value={employees.filter(e => e.status === 'Active').length.toString()} 
          sub={`Total Roster: ${employees.length}`}
          icon={<Users size={24} />} 
          color="indigo"
          trend="+4.2%"
          trendUp={true}
        />
        <AdvancedStatCard 
          label="Total Servings" 
          value={todayTransactions.length.toString()} 
          sub={`${todayTransactions.length} Authorized Units`}
          icon={<Utensils size={24} />} 
          color="emerald"
          trend="+12%"
          trendUp={true}
        />
        <AdvancedStatCard 
          label="Service Utilization" 
          value={employees.length > 0 ? `${Math.round((todayTransactions.length / employees.length) * 100)}%` : '0%'} 
          sub="Daily Footfall Metric"
          icon={<Activity size={24} />} 
          color="amber"
          trend="Stable"
          trendUp={true}
        />
        <AdvancedStatCard 
          label="Registry Health" 
          value={`${integrityScore}%`} 
          sub={integrityScore < 100 ? `${employees.length - Math.round(employees.length * integrityScore / 100)} Outdated Nodes` : 'All Security Checks Passed'}
          icon={integrityScore < 100 ? <ShieldAlert size={24} /> : <ShieldCheckIcon size={24} />} 
          color={integrityScore < 90 ? "rose" : "indigo"}
          trend={integrityScore === 100 ? "Secured" : "Auditing"}
          trendUp={integrityScore > 90}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 bg-white p-10 rounded-[3rem] border border-slate-100 shadow-sm relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-50/50 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2 pointer-events-none"></div>
          <div className="flex items-center justify-between mb-10 relative z-10">
            <div>
              <h3 className="text-xl font-black text-slate-900 uppercase tracking-tighter">Traffic Intensity Monitor</h3>
              <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mt-1">Real-time hourly consumption trend</p>
            </div>
          </div>
          <div className="h-80 relative z-10">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={trafficData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorCount" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="hour" axisLine={false} tickLine={false} tick={{ fill: '#94a3b8', fontSize: 10, fontWeight: 900 }} />
                <YAxis axisLine={false} tickLine={false} tick={{ fill: '#94a3b8', fontSize: 10, fontWeight: 900 }} />
                <Tooltip contentStyle={{ borderRadius: '24px', border: 'none', boxShadow: '0 25px 50px -12px rgba(0,0,0,0.2)', padding: '20px' }} />
                <Area type="monotone" dataKey="count" stroke="#6366f1" strokeWidth={4} fillOpacity={1} fill="url(#colorCount)" animationDuration={2000} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-slate-950 text-white p-10 rounded-[3rem] shadow-2xl flex flex-col relative overflow-hidden">
          <div className="flex items-center justify-between mb-8 relative z-10">
            <div className="flex items-center gap-3">
              <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
              <h3 className="text-lg font-black uppercase tracking-tighter">Live Access Ledger</h3>
            </div>
            <Activity size={18} className="text-slate-600" />
          </div>
          <div className="space-y-6 flex-1 overflow-y-auto no-scrollbar relative z-10">
            {recentActivity.length > 0 ? recentActivity.map((tx) => (
              <div key={tx.id} className="flex items-center gap-5 group p-4 rounded-[1.5rem] hover:bg-white/5 transition-all">
                <div className="w-14 h-14 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center font-black">{tx.employeeName.charAt(0)}</div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-black text-white truncate uppercase tracking-tight">{tx.employeeName}</p>
                  <p className="text-[9px] font-bold text-slate-500 uppercase tracking-[0.2em] mt-1">{`${tx.mealType}`} • {new Date(tx.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</p>
                </div>
              </div>
            )) : (
              <div className="h-full flex flex-col items-center justify-center opacity-20 py-20">
                <RefreshCw size={48} className="animate-spin" />
                <p className="text-xs font-black uppercase tracking-widest mt-4">Waiting for sync...</p>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white p-10 rounded-[3rem] border border-slate-100 shadow-sm flex flex-col group">
          <div className="flex items-center gap-4 mb-8">
            <div className="p-3 bg-indigo-50 text-indigo-600 rounded-2xl group-hover:bg-indigo-600 group-hover:text-white transition-all">
              <PieChartIcon size={24} />
            </div>
            <h3 className="text-2xl font-black text-slate-900 uppercase tracking-tighter">Meal Distribution</h3>
          </div>
          <div className="h-80 mb-6 relative">
             {chartData.length > 0 ? (
               <ResponsiveContainer width="100%" height="100%">
                 <PieChart>
                    <Pie
                      data={chartData}
                      cx="50%"
                      cy="50%"
                      innerRadius={80}
                      outerRadius={110}
                      paddingAngle={8}
                      dataKey="value"
                      animationDuration={1500}
                    >
                      {chartData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={MEAL_COLORS[entry.name as string] || '#cbd5e1'} />
                      ))}
                    </Pie>
                    <Tooltip 
                      contentStyle={{ borderRadius: '24px', border: 'none', boxShadow: '0 25px 50px -12px rgba(0,0,0,0.2)', padding: '20px' }}
                    />
                    <Legend 
                      verticalAlign="bottom" 
                      height={36}
                      formatter={(value) => <span className="text-xs font-black uppercase tracking-widest text-slate-500 px-2">{value}</span>}
                    />
                 </PieChart>
               </ResponsiveContainer>
             ) : (
               <div className="h-full flex flex-col items-center justify-center text-slate-300 opacity-40">
                  <Utensils size={64} />
                  <p className="text-xs font-black uppercase tracking-widest mt-4">Zero Consumption Detected Today</p>
               </div>
             )}
          </div>
          <div className="mt-auto pt-6 border-t border-slate-50 flex items-center justify-between">
             <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Node: MEAL_ANALYTICS_V2</p>
             <div className="flex gap-2">
                {Object.keys(MEAL_COLORS).map(meal => (
                  <div key={meal} className="w-2 h-2 rounded-full" style={{ backgroundColor: MEAL_COLORS[meal] }}></div>
                ))}
             </div>
          </div>
        </div>

        <div className="bg-gradient-to-br from-indigo-700 via-indigo-900 to-slate-950 text-white p-10 rounded-[3rem] shadow-2xl flex flex-col relative overflow-hidden group">
          <div className="flex items-center gap-4 mb-8 relative z-10">
            <div className="p-4 bg-white/10 rounded-[1.5rem] backdrop-blur-2xl border border-white/10"><Sparkles size={32} className="text-amber-300 animate-pulse" /></div>
            <div>
              <h3 className="font-black text-2xl uppercase tracking-tighter leading-none">Canteen Insight AI</h3>
              <p className="text-indigo-300 text-[10px] font-black uppercase tracking-[0.3em] mt-2">Neural Hub Active</p>
            </div>
          </div>
          <div className="space-y-6 flex-1 relative z-10">
            <div className="relative">
              <input type="text" value={aiQuery} onChange={(e) => setAiQuery(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && handleAiInsight()} placeholder="Query node optimization..." className="w-full bg-black/30 border border-white/10 rounded-[1.5rem] py-5 pl-7 pr-16 text-sm font-bold outline-none placeholder:text-indigo-300/40" />
              <button onClick={handleAiInsight} disabled={loadingAi} className="absolute right-3 top-3 p-3 bg-indigo-500 hover:bg-white hover:text-indigo-900 transition-all rounded-xl shadow-lg">
                {loadingAi ? <RefreshCw size={20} className="animate-spin" /> : <Search size={20} />}
              </button>
            </div>
            {aiResult ? (
              <div className="bg-white/5 rounded-[2rem] p-8 border border-white/10 animate-in slide-in-from-bottom-8 overflow-y-auto no-scrollbar max-h-[18rem]">
                <p className="text-sm font-medium leading-relaxed italic text-indigo-50">{`"${aiResult.text}"`}</p>
                {aiResult.sources && aiResult.sources.length > 0 && (
                  <div className="mt-6 pt-6 border-t border-white/10">
                    <p className="text-[10px] font-black uppercase tracking-widest text-indigo-400 mb-3">Grounding Sources:</p>
                    <div className="flex flex-wrap gap-2">
                      {aiResult.sources.map((source, idx) => (
                        <a key={idx} href={source} target="_blank" rel="noopener noreferrer" className="text-[10px] bg-white/5 hover:bg-white/20 px-3 py-1.5 rounded-lg flex items-center gap-2 transition-colors text-white font-bold border border-white/5">
                          <ExternalLink size={10} /> {`Node ${idx + 1}`}
                        </a>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="flex-1 flex flex-col items-center justify-center text-indigo-300/20 text-center space-y-4">
                 <Bot size={80} strokeWidth={1} />
                 <p className="text-xs font-black uppercase tracking-[0.2em]">Awaiting Cluster Query</p>
              </div>
            )}
          </div>
        </div>
      </div>
      <style>{`.no-scrollbar::-webkit-scrollbar { display: none; }`}</style>
    </div>
  );
};

const AdvancedStatCard: React.FC<{ 
  label: string; 
  value: string; 
  sub: string;
  icon: React.ReactNode; 
  color: 'indigo' | 'emerald' | 'amber' | 'rose';
  trend: string;
  trendUp: boolean;
}> = ({ label, value, sub, icon, color, trend, trendUp }) => {
  const theme = {
    indigo: { bg: 'bg-indigo-50', text: 'text-indigo-600' },
    emerald: { bg: 'bg-emerald-50', text: 'text-emerald-600' },
    amber: { bg: 'bg-amber-50', text: 'text-amber-600' },
    rose: { bg: 'bg-rose-50', text: 'text-rose-600' },
  }[color];

  return (
    <div className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm hover:shadow-2xl hover:-translate-y-2 transition-all duration-500 group relative overflow-hidden">
      <div className="flex items-start justify-between mb-8">
        <div className={`p-4 ${theme.bg} ${theme.text} rounded-[1.5rem] group-hover:scale-110 transition-transform shadow-inner`}>{icon}</div>
        <div className={`flex items-center gap-1.5 px-4 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-widest ${trendUp ? 'bg-emerald-50 text-emerald-600' : 'bg-rose-50 text-rose-600'}`}>
          {trendUp ? <ArrowUpRight size={12} /> : <ArrowDownRight size={12} />}
          {trend}
        </div>
      </div>
      <div className="space-y-2 relative z-10">
        <p className="text-slate-400 text-[10px] font-black uppercase tracking-[0.2em] leading-none mb-1">{label}</p>
        <p className="text-4xl font-black text-slate-900 tracking-tighter leading-none">{value}</p>
        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wide truncate mt-2">{sub}</p>
      </div>
    </div>
  );
};

const Bot = ({ size, strokeWidth }: { size: number, strokeWidth: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round">
    <rect x="3" y="11" width="18" height="10" rx="2" />
    <circle cx="12" cy="5" r="2" />
    <path d="M12 7v4" />
    <line x1="8" y1="16" x2="8" y2="16" />
    <line x1="16" y1="16" x2="16" y2="16" />
  </svg>
);

export default AdminDashboard;
