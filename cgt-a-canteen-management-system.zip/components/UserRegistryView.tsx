
import React, { useState } from 'react';
import { User, UserRole, Employee } from '../types';
import { 
  Plus, 
  X, 
  Trash2, 
  UserCheck, 
  Link as LinkIcon,
  ShieldCheck,
  UserCog,
  Fingerprint,
  Lock
} from 'lucide-react';

interface Props {
  title: string;
  description: string;
  icon: React.ReactNode;
  themeColor: 'indigo' | 'emerald' | 'amber' | 'slate';
  filterRoles: UserRole[];
  currentUser: User;
  users: User[];
  setUsers: (users: User[]) => void;
  employees?: Employee[];
}

const UserRegistryView: React.FC<Props> = ({ 
  title, 
  description, 
  icon, 
  themeColor, 
  filterRoles, 
  currentUser, 
  users, 
  setUsers,
  employees = []
}) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  
  // Security Logic
  const isIT = currentUser.role === UserRole.IT_SUPER_USER;
  const isSuper = currentUser.role === UserRole.SUPER_ADMIN;
  const isHR = currentUser.role === UserRole.HR_ADMIN;

  // Granular Access
  const canManageRegistry = isIT || 
                           (isSuper && !filterRoles.includes(UserRole.IT_SUPER_USER)) ||
                           (isHR && filterRoles.every(r => r === UserRole.CANTEEN_STAFF || r === UserRole.EMPLOYEE));

  const filteredUsers = users.filter(u => filterRoles.includes(u.role));

  const handleDelete = (id: string) => {
    if (!canManageRegistry) {
      alert("Unauthorized: Access level insufficient for registry modification.");
      return;
    }
    if (id === currentUser.id) {
      alert("Self-termination of authorization is restricted.");
      return;
    }
    if (confirm(`Revoke access for this ${filterRoles.join('/')} identity?`)) {
      setUsers(users.filter(u => u.id !== id));
    }
  };

  const getThemeClasses = () => {
    switch(themeColor) {
      case 'emerald': return { bg: 'bg-emerald-600', text: 'text-emerald-600', border: 'border-emerald-100', shadow: 'shadow-emerald-200', light: 'bg-emerald-50' };
      case 'amber': return { bg: 'bg-amber-600', text: 'text-amber-600', border: 'border-amber-100', shadow: 'shadow-amber-200', light: 'bg-amber-50' };
      case 'slate': return { bg: 'bg-slate-900', text: 'text-slate-900', border: 'border-slate-200', shadow: 'shadow-slate-200', light: 'bg-slate-50' };
      default: return { bg: 'bg-indigo-600', text: 'text-indigo-600', border: 'border-indigo-100', shadow: 'shadow-indigo-200', light: 'bg-indigo-50' };
    }
  };

  const theme = getThemeClasses();

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-3 mb-1">
            <span className={theme.text}>{icon}</span>
            <h2 className="text-2xl font-black text-gray-900 uppercase tracking-tighter">{title}</h2>
          </div>
          <p className="text-gray-500 font-medium">{description}</p>
        </div>
        
        {canManageRegistry ? (
          <button 
            onClick={() => setIsModalOpen(true)}
            className={`flex items-center gap-2 ${theme.bg} text-white px-8 py-4 rounded-2xl transition-all font-black uppercase tracking-widest text-xs shadow-xl ${theme.shadow}`}
          >
            <Plus size={20} />
            Provision Identity
          </button>
        ) : (
          <div className="flex items-center gap-2 px-6 py-3 bg-amber-50 text-amber-600 text-[10px] font-black uppercase tracking-widest rounded-xl border border-amber-100 shadow-sm">
            <Lock size={14} /> Restricted to Registry Admins
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredUsers.map((user) => (
          <div key={user.id} className="bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-sm relative group hover:shadow-md transition-all">
            <div className="flex items-center justify-between mb-6">
              <div className={`p-4 rounded-2xl ${theme.bg} text-white`}>
                {user.role === UserRole.SUPER_ADMIN ? <ShieldCheck size={24} /> : 
                 user.role === UserRole.HR_ADMIN ? <UserCog size={24} /> : 
                 <Fingerprint size={24} />}
              </div>
              {canManageRegistry && (
                <button 
                  onClick={() => handleDelete(user.id)}
                  className="p-2 text-slate-300 hover:text-red-500 transition-colors"
                >
                  <Trash2 size={18} />
                </button>
              )}
            </div>
            <h3 className="text-lg font-black text-gray-900">{user.name}</h3>
            <p className={`text-xs font-black ${theme.text} uppercase tracking-widest mt-1`}>@{user.username}</p>
            
            {user.employeeId && (
              <div className="mt-4 flex items-center gap-2 text-[10px] font-black text-slate-400 uppercase tracking-widest">
                <LinkIcon size={12} className={theme.text} /> Node Link: {user.employeeId}
              </div>
            )}

            <div className="mt-6 pt-6 border-t border-slate-50 flex items-center justify-between">
              <span className={`text-[10px] font-black uppercase tracking-[0.2em] px-3 py-1 rounded-full ${theme.light} ${theme.text}`}>
                {user.role}
              </span>
              <div className="flex items-center gap-1.5 text-[10px] font-bold text-slate-300">
                <UserCheck size={12} /> VERIFIED
              </div>
            </div>
          </div>
        ))}
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-slate-900/60 backdrop-blur-md animate-in fade-in duration-300">
          <div className="bg-white w-full max-w-md rounded-[3rem] shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200">
            <div className="px-10 py-8 border-b border-slate-50 flex items-center justify-between">
              <h3 className="text-xl font-black text-slate-900 tracking-tight">Enroll {title.split(' ')[0]}</h3>
              <button onClick={() => setIsModalOpen(false)} className="text-slate-300 hover:text-slate-900 transition-colors">
                <X size={24} />
              </button>
            </div>
            <form className="p-10 space-y-6" onSubmit={(e) => {
              e.preventDefault();
              const formData = new FormData(e.currentTarget);
              const newUser: User = {
                id: 'U-' + Math.random().toString(36).substr(2, 5).toUpperCase(),
                name: formData.get('name') as string,
                username: (formData.get('username') as string).toLowerCase(),
                password: (formData.get('password') as string) || 'password123',
                role: formData.get('role') as UserRole,
                employeeId: formData.get('employeeId') as string || undefined
              };
              setUsers([...users, newUser]);
              setIsModalOpen(false);
            }}>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Display Name</label>
                <input name="name" required placeholder="Full Name" className="w-full px-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl font-bold outline-none focus:ring-2 focus:ring-indigo-500" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Identity Identifier</label>
                  <input name="username" required placeholder="Identity Identifier" className="w-full px-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl font-bold outline-none focus:ring-2 focus:ring-indigo-500" />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Access Role</label>
                  <select name="role" className="w-full px-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl font-bold appearance-none outline-none focus:ring-2 focus:ring-indigo-500">
                    {filterRoles.map(role => (
                      <option key={role} value={role}>{role}</option>
                    ))}
                  </select>
                </div>
              </div>
              {filterRoles.includes(UserRole.EMPLOYEE) && (
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Physical Node Linkage</label>
                  <select name="employeeId" className="w-full px-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl font-bold appearance-none outline-none focus:ring-2 focus:ring-indigo-500">
                    <option value="">No Physical Node Link</option>
                    {employees.map(emp => (
                      <option key={emp.id} value={emp.id}>{emp.name} ({emp.id})</option>
                    ))}
                  </select>
                </div>
              )}
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Provision Security Key</label>
                <input type="password" name="password" required placeholder="Security Key" className={`w-full px-6 py-4 ${theme.light} border ${theme.border} ${theme.text} rounded-2xl font-mono text-center tracking-[0.4em] outline-none focus:ring-2 focus:ring-indigo-500`} />
              </div>
              <button type="submit" className={`w-full py-5 ${theme.bg} text-white rounded-2xl font-black uppercase tracking-widest shadow-xl ${theme.shadow} mt-4 hover:opacity-90 transition-opacity`}>
                Authorize Identity
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default UserRegistryView;
