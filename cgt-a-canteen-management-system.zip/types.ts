
export enum MealType {
  BREAKFAST = 'Breakfast',
  LUNCH = 'Lunch',
  SNACKS = 'Snacks',
  DINNER = 'Dinner'
}

export enum EmployeeStatus {
  ACTIVE = 'Active',
  BLOCKED = 'Blocked'
}

export enum UserRole {
  HR_ADMIN = 'HR Admin',
  CANTEEN_STAFF = 'Canteen Staff',
  SUPER_ADMIN = 'Super Admin',
  EMPLOYEE = 'Employee',
  IT_SUPER_USER = 'IT Super User'
}

export interface User {
  id: string;
  username: string;
  password?: string;
  role: UserRole;
  name: string;
  employeeId?: string; // Links to Employee.id
}

export interface PasswordResetRequest {
  id: string;
  username: string;
  requestedAt: string;
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
}

export interface Employee {
  id: string;
  name: string;
  department: string;
  shift: 'General' | 'Night' | 'Evening' | 'Rotating';
  cardId: string;
  status: EmployeeStatus;
  eligibility: MealType[];
  photoUrl?: string; // Base64 or URL for profile picture
}

export interface MealConfig {
  id: MealType;
  name: string;
  startTime: string; // HH:mm
  endTime: string;   // HH:mm
  price: number;
  isFree: boolean;
  isActive: boolean;
  gracePeriod: number; // minutes before/after window
  flexibleForRotating: boolean; // Allows rotating shift workers to punch outside standard hours
}

export interface Transaction {
  id: string;
  employeeId: string;
  employeeName: string;
  mealType: MealType;
  timestamp: string;
  isPaid: boolean;
  amount: number;
  status: 'SUCCESS' | 'FAILED';
}

export interface AppSettings {
  appName: string;
  themeColor: string;
  language: 'English' | 'Hindi';
  notices: string;
  currencySymbol: string;
  reportFrequency: 'Daily' | 'Weekly' | 'Monthly';
  reportEmail: string; // Destination for automated reports
  enableAutoEmail: boolean; // Toggle for automated reporting
  autoLockTimeout: number; // minutes
  enableSoundEffects: boolean;
  terminalVolume: number; // 0-100
  backupSchedule: 'Never' | 'Daily' | 'Weekly';
  supportEmail: string;
  punchScreenTimeout: number; // Seconds to show success screen
  manualPunchReset: boolean; // If true, success screen stays on (Long Persistence) until manual exit or long timeout
  manualResetTimeoutHours: number; // Configurable range 1-24 hours
  enablePrinting: boolean; // Toggle for automatic voucher printing
  keepScreenAwake: boolean; // Toggle for preventing screen sleep (Wake Lock)
}